import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { createPesapalOrder, queryPaymentStatus, processIPNNotification, createSubscriptionPayment } from "./pesapal";
import { insertSoilReadingSchema, insertAiRecommendationSchema, insertMarketListingSchema, insertAnimalSchema, insertAnimalHealthRecordSchema, insertIrrigationEventSchema, insertNotificationSchema, insertSoilDeviceSchema, insertPaymentSchema, insertSubscriptionSchema } from "@shared/schema";
import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

// Helper function to generate API keys for devices
function generateApiKey(): string {
  return `agro_${Math.random().toString(36).substr(2, 16)}_${Date.now().toString(36)}`;
}

// Middleware to check trial and subscription status
async function checkTrialStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = 1; // Current user ID (should come from session/auth)
    const trialStatus = await storage.checkUserTrialStatus(userId);
    
    // If trial expired and no active subscription, redirect to subscription page
    if (!trialStatus.isTrialActive && trialStatus.requiresSubscription) {
      const activeSubscription = await storage.getUserSubscription(userId);
      if (!activeSubscription || activeSubscription.status !== "active") {
        return res.status(402).json({ 
          message: "Trial expired. Subscription required.",
          redirectTo: "/subscription",
          trialEndDate: trialStatus.trialEndDate
        });
      }
    }
    
    // If trial expired but no subscription requirement set yet, set it
    if (!trialStatus.isTrialActive && !trialStatus.requiresSubscription) {
      await storage.updateUserSubscriptionRequired(userId, true);
    }
    
    next();
  } catch (error) {
    console.error("Trial status check failed:", error);
    next(); // Continue without blocking if check fails
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user (simplified for demo)
  app.get("/api/user", async (req, res) => {
    try {
      const user = await storage.getUser(1); // Default user
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get user trial status
  app.get("/api/user/trial-status", async (req, res) => {
    try {
      const trialStatus = await storage.checkUserTrialStatus(1);
      const activeSubscription = await storage.getUserSubscription(1);
      
      res.json({
        ...trialStatus,
        hasActiveSubscription: activeSubscription?.status === "active",
        subscriptionType: activeSubscription?.planType,
        daysRemaining: trialStatus.isTrialActive 
          ? Math.ceil((trialStatus.trialEndDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
          : 0
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trial status" });
    }
  });

  // Update user profile
  app.put("/api/user/profile", async (req, res) => {
    try {
      const { username, email, fullName, phone, location } = req.body;
      
      // For now, we'll just return success - in real app would update database
      const updatedUser = {
        id: 1,
        username: username || "john_farmer",
        email: email || "john@example.com",
        fullName: fullName || "",
        phone: phone || "",
        location: location || "",
      };
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Soil monitoring endpoints (protected by trial status)
  app.get("/api/soil/readings", checkTrialStatus, async (req, res) => {
    try {
      const { fieldId } = req.query;
      const readings = await storage.getSoilReadings(1, fieldId as string);
      res.json(readings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch soil readings" });
    }
  });

  app.get("/api/soil/latest/:fieldId", checkTrialStatus, async (req, res) => {
    try {
      const { fieldId } = req.params;
      const reading = await storage.getLatestSoilReading(1, fieldId);
      if (!reading) {
        return res.status(404).json({ message: "No readings found for this field" });
      }
      res.json(reading);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch latest soil reading" });
    }
  });

  app.post("/api/soil/readings", async (req, res) => {
    try {
      const validatedData = insertSoilReadingSchema.parse(req.body);
      const reading = await storage.createSoilReading(validatedData);
      res.status(201).json(reading);
    } catch (error) {
      res.status(400).json({ message: "Invalid soil reading data" });
    }
  });

  // AI recommendations
  app.get("/api/recommendations", checkTrialStatus, async (req, res) => {
    try {
      const { category } = req.query;
      const recommendations = await storage.getRecommendations(1, category as string);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recommendations" });
    }
  });

  app.put("/api/recommendations/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const recommendation = await storage.updateRecommendation(parseInt(id), req.body);
      if (!recommendation) {
        return res.status(404).json({ message: "Recommendation not found" });
      }
      res.json(recommendation);
    } catch (error) {
      res.status(500).json({ message: "Failed to update recommendation" });
    }
  });

  app.post("/api/recommendations/generate", async (req, res) => {
    try {
      const { fieldId, soilData } = req.body;
      
      if (!fieldId || !soilData) {
        return res.status(400).json({ message: "Field ID and soil data are required" });
      }

      // Generate AI recommendation using OpenAI
      const prompt = `As an agricultural expert, analyze this soil data and provide specific recommendations:
      
Soil Data:
- Nitrogen: ${soilData.nitrogen}%
- Phosphorus: ${soilData.phosphorus}%
- Potassium: ${soilData.potassium}%
- Calcium: ${soilData.calcium}%
- Moisture: ${soilData.moisture}%
- pH: ${soilData.ph}
- Conductivity: ${soilData.conductivity} mS/cm
- Temperature: ${soilData.temperature}°C

Please provide a JSON response with recommendations for fertilizer application, irrigation needs, and general soil management. Format:
{
  "fertilizer": "specific fertilizer recommendation with amounts",
  "irrigation": "irrigation timing and amount recommendation",
  "general": "general soil management advice",
  "priority": "low|medium|high|critical"
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const aiResponse = JSON.parse(response.choices[0].message.content || "{}");
      
      // Create recommendation records
      const recommendations = [];
      
      if (aiResponse.fertilizer) {
        const fertilizerRec = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: aiResponse.fertilizer,
          category: "fertilizer",
          priority: aiResponse.priority || "medium",
        });
        recommendations.push(fertilizerRec);
      }

      if (aiResponse.irrigation) {
        const irrigationRec = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: aiResponse.irrigation,
          category: "irrigation",
          priority: aiResponse.priority || "medium",
        });
        recommendations.push(irrigationRec);
      }

      if (aiResponse.general) {
        const generalRec = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: aiResponse.general,
          category: "general",
          priority: aiResponse.priority || "medium",
        });
        recommendations.push(generalRec);
      }

      res.json({ recommendations, aiResponse });
    } catch (error) {
      console.error("Error generating AI recommendation:", error);
      
      // Fallback to sample recommendations when OpenAI API is unavailable
      try {
        const { fieldId, soilData } = req.body;
        
        // Generate fallback recommendations based on soil data thresholds
        const fallbackRecommendations = [];
        
        // Fertilizer recommendations based on NPK levels
        let fertilizerRec = "";
        if (soilData.nitrogen < 50) {
          fertilizerRec = "Apply nitrogen-rich fertilizer (20-10-10) at 150kg/hectare to boost nitrogen levels for better crop growth.";
        } else if (soilData.phosphorus < 25) {
          fertilizerRec = "Apply phosphorus fertilizer (10-20-10) at 100kg/hectare to improve root development and flowering.";
        } else if (soilData.potassium < 60) {
          fertilizerRec = "Apply potassium fertilizer (15-15-20) at 120kg/hectare to enhance disease resistance and fruit quality.";
        } else {
          fertilizerRec = "Current NPK levels are adequate. Continue with maintenance fertilization every 6-8 weeks.";
        }
        
        // Irrigation recommendations based on moisture
        let irrigationRec = "";
        if (soilData.moisture < 30) {
          irrigationRec = "Soil moisture is low. Increase irrigation frequency to 2-3 times per week, applying 25-30mm per session.";
        } else if (soilData.moisture > 60) {
          irrigationRec = "Soil moisture is high. Reduce irrigation frequency to prevent waterlogging and root rot.";
        } else {
          irrigationRec = "Soil moisture levels are optimal. Continue current irrigation schedule of 2 times per week.";
        }
        
        // General recommendations based on pH and overall conditions
        let generalRec = "";
        if (soilData.ph < 6.0) {
          generalRec = "Soil is acidic. Apply lime at 500kg/hectare to raise pH and improve nutrient availability.";
        } else if (soilData.ph > 7.5) {
          generalRec = "Soil is alkaline. Apply sulfur at 200kg/hectare to lower pH and improve nutrient uptake.";
        } else {
          generalRec = "Soil pH is in optimal range. Focus on maintaining organic matter through compost application.";
        }
        
        // Determine priority based on critical thresholds
        let priority = "medium";
        if (soilData.moisture < 25 || soilData.ph < 5.5 || soilData.ph > 8.0) {
          priority = "critical";
        } else if (soilData.nitrogen < 40 || soilData.phosphorus < 20 || soilData.potassium < 50) {
          priority = "high";
        }
        
        // Create recommendation records
        const fertilizerRecord = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: fertilizerRec,
          category: "fertilizer",
          priority: priority,
        });
        fallbackRecommendations.push(fertilizerRecord);
        
        const irrigationRecord = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: irrigationRec,
          category: "irrigation",
          priority: priority,
        });
        fallbackRecommendations.push(irrigationRecord);
        
        const generalRecord = await storage.createRecommendation({
          userId: 1,
          fieldId,
          recommendation: generalRec,
          category: "general",
          priority: priority,
        });
        fallbackRecommendations.push(generalRecord);
        
        res.json({ 
          recommendations: fallbackRecommendations, 
          aiResponse: {
            fertilizer: fertilizerRec,
            irrigation: irrigationRec,
            general: generalRec,
            priority: priority
          },
          fallback: true 
        });
      } catch (fallbackError) {
        console.error("Fallback recommendation generation failed:", fallbackError);
        res.status(500).json({ 
          message: "Failed to generate AI recommendation", 
          error: fallbackError instanceof Error ? fallbackError.message : "Unknown error"
        });
      }
    }
  });

  // Irrigation control
  app.post("/api/irrigation/start", async (req, res) => {
    try {
      const validatedData = insertIrrigationEventSchema.parse(req.body);
      const event = await storage.createIrrigationEvent(validatedData);
      
      // Create notification
      await storage.createNotification({
        userId: 1,
        title: "Irrigation Started",
        message: `Irrigation started for ${validatedData.fieldId}`,
        type: "info",
        category: "soil",
      });

      res.status(201).json(event);
    } catch (error) {
      console.error("Error starting irrigation:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: "Invalid irrigation data", error: error.message });
      } else {
        res.status(400).json({ message: "Invalid irrigation data" });
      }
    }
  });

  app.get("/api/irrigation/events", async (req, res) => {
    try {
      const { fieldId } = req.query;
      const events = await storage.getIrrigationEvents(1, fieldId as string);
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch irrigation events" });
    }
  });

  // Market endpoints
  app.get("/api/market/listings", async (req, res) => {
    try {
      const { location, category } = req.query;
      const listings = await storage.getMarketListings(location as string, category as string);
      res.json(listings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch market listings" });
    }
  });

  app.get("/api/market/prices", async (req, res) => {
    try {
      const { productName, location } = req.query;
      const prices = await storage.getMarketPrices(productName as string, location as string);
      res.json(prices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch market prices" });
    }
  });

  app.get("/api/market/my-listings", async (req, res) => {
    try {
      const listings = await storage.getUserListings(1);
      res.json(listings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user listings" });
    }
  });

  app.post("/api/market/listings", async (req, res) => {
    try {
      const validatedData = insertMarketListingSchema.parse(req.body);
      const listing = await storage.createMarketListing(validatedData);
      res.status(201).json(listing);
    } catch (error) {
      res.status(400).json({ message: "Invalid listing data" });
    }
  });

  app.put("/api/market/listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMarketListingSchema.partial().parse(req.body);
      const listing = await storage.updateMarketListing(id, validatedData);
      
      if (!listing) {
        return res.status(404).json({ message: "Listing not found" });
      }
      
      res.json(listing);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: "Invalid listing data", error: error.message });
      } else {
        res.status(400).json({ message: "Invalid listing data" });
      }
    }
  });

  app.delete("/api/market/listings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const listing = await storage.updateMarketListing(id, { status: "inactive" });
      
      if (!listing) {
        return res.status(404).json({ message: "Listing not found" });
      }
      
      res.json({ message: "Listing deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete listing" });
    }
  });

  // Animal management endpoints
  app.get("/api/animals", async (req, res) => {
    try {
      const animals = await storage.getAnimals(1);
      res.json(animals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch animals" });
    }
  });

  app.get("/api/animals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const animal = await storage.getAnimal(id);
      if (!animal) {
        return res.status(404).json({ message: "Animal not found" });
      }
      res.json(animal);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch animal" });
    }
  });

  app.post("/api/animals", async (req, res) => {
    try {
      const validatedData = insertAnimalSchema.parse(req.body);
      const animal = await storage.createAnimal(validatedData);
      res.status(201).json(animal);
    } catch (error) {
      res.status(400).json({ message: "Invalid animal data" });
    }
  });

  app.put("/api/animals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const animal = await storage.updateAnimal(id, updates);
      if (!animal) {
        return res.status(404).json({ message: "Animal not found" });
      }
      res.json(animal);
    } catch (error) {
      res.status(400).json({ message: "Invalid animal update data" });
    }
  });

  app.delete("/api/animals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { deletionReason, salePrice, buyerInfo, causeOfDeath, notes, deletedBy } = req.body;
      
      if (!deletionReason) {
        return res.status(400).json({ message: "Deletion reason is required" });
      }

      const success = await storage.deleteAnimal(id, {
        userId: 1, // Default user
        deletionReason,
        salePrice: salePrice || null,
        buyerInfo: buyerInfo || null,
        causeOfDeath: causeOfDeath || null,
        notes: notes || null,
        deletedBy: deletedBy || "System",
      });

      if (!success) {
        return res.status(404).json({ message: "Animal not found" });
      }

      res.json({ message: "Animal removed and archived for farm records" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete animal" });
    }
  });

  app.get("/api/animals/:id/health", async (req, res) => {
    try {
      const animalId = parseInt(req.params.id);
      const records = await storage.getAnimalHealthRecords(animalId);
      res.json(records);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch health records" });
    }
  });

  app.post("/api/animals/health", async (req, res) => {
    try {
      const validatedData = insertAnimalHealthRecordSchema.parse(req.body);
      const record = await storage.createAnimalHealthRecord(validatedData);
      res.status(201).json(record);
    } catch (error) {
      res.status(400).json({ message: "Invalid health record data" });
    }
  });

  app.get("/api/animals/deleted", async (req, res) => {
    try {
      const deletedAnimals = await storage.getDeletedAnimals(1); // Default user
      res.json(deletedAnimals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch deleted animals" });
    }
  });

  // Notifications
  app.get("/api/notifications", async (req, res) => {
    try {
      const { unread } = req.query;
      const notifications = await storage.getNotifications(1, unread === "true");
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Soil device management endpoints
  app.get("/api/soil/devices", async (req, res) => {
    try {
      const devices = await storage.getSoilDevices(1); // Default user
      res.json(devices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch soil devices" });
    }
  });

  app.get("/api/soil/devices/:deviceId", async (req, res) => {
    try {
      const { deviceId } = req.params;
      const device = await storage.getSoilDevice(deviceId);
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device" });
    }
  });

  app.post("/api/soil/devices", async (req, res) => {
    try {
      const validatedData = insertSoilDeviceSchema.parse({
        ...req.body,
        userId: 1, // Default user
        apiKey: generateApiKey(), // Generate unique API key
      });
      const device = await storage.createSoilDevice(validatedData);
      res.status(201).json(device);
    } catch (error) {
      console.error("Device creation error:", error);
      res.status(400).json({ message: "Invalid device data" });
    }
  });

  app.put("/api/soil/devices/:deviceId", async (req, res) => {
    try {
      const { deviceId } = req.params;
      const device = await storage.updateSoilDevice(deviceId, req.body);
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to update device" });
    }
  });

  app.delete("/api/soil/devices/:deviceId", async (req, res) => {
    try {
      const { deviceId } = req.params;
      const success = await storage.deleteSoilDevice(deviceId);
      if (!success) {
        return res.status(404).json({ message: "Device not found" });
      }
      res.json({ message: "Device deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete device" });
    }
  });

  // Real NPK device scanning endpoint
  app.post("/api/soil/devices/scan", async (req, res) => {
    try {
      const { qrData, fieldId } = req.body;
      
      if (!qrData) {
        return res.status(400).json({ message: "QR code data required" });
      }

      // Parse QR code data from real NPK device
      // Expected format: "NPK:DEVICE_ID:MODEL:FIRMWARE"
      const qrParts = qrData.split(':');
      if (qrParts.length < 4 || qrParts[0] !== 'NPK') {
        return res.status(400).json({ message: "Invalid NPK device QR code" });
      }

      const deviceInfo = {
        deviceId: qrParts[1],
        deviceName: qrParts[2] || "NPK Soil Sensor",
        fieldId: fieldId || "field_a",
        firmwareVersion: qrParts[3],
        batteryLevel: null, // Will be updated when device connects
        status: "pending_connection"
      };

      // Check if device already exists
      const existingDevice = await storage.getSoilDevice(deviceInfo.deviceId);
      if (existingDevice) {
        return res.status(409).json({ 
          message: "Device already registered",
          device: existingDevice 
        });
      }

      res.json(deviceInfo);
    } catch (error) {
      console.error("Device scan error:", error);
      res.status(500).json({ message: "Failed to scan device" });
    }
  })

  // Endpoint for manual NPK data entry from real devices
  app.post("/api/soil/readings/manual", async (req, res) => {
    try {
      const { deviceId, readings } = req.body;
      
      // Validate device exists
      const device = await storage.getSoilDevice(deviceId);
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }

      // Create soil reading from manual entry
      const soilReading = await storage.createSoilReading({
        userId: device.userId,
        fieldId: device.fieldId,
        nitrogen: readings.nitrogen,
        phosphorus: readings.phosphorus,
        potassium: readings.potassium,
        calcium: readings.calcium || 0,
        moisture: readings.moisture,
        ph: readings.ph,
        conductivity: readings.conductivity || 0,
        temperature: readings.temperature,
      });

      // Update device last seen
      await storage.updateSoilDevice(deviceId, { 
        lastSeen: new Date(),
        status: "active"
      });

      res.status(201).json(soilReading);
    } catch (error) {
      console.error("Manual reading error:", error);
      res.status(400).json({ message: "Failed to record manual reading" });
    }
  })

  // Endpoint for real-time device data reception
  app.post("/api/soil/readings/device", async (req, res) => {
    try {
      const { deviceId, apiKey, readings, batteryLevel } = req.body;
      
      // Validate device and API key
      const device = await storage.getSoilDevice(deviceId);
      if (!device || device.apiKey !== apiKey) {
        return res.status(401).json({ message: "Unauthorized device" });
      }

      // Create soil reading from device
      const soilReading = await storage.createSoilReading({
        userId: device.userId,
        fieldId: device.fieldId,
        nitrogen: readings.nitrogen,
        phosphorus: readings.phosphorus,
        potassium: readings.potassium,
        calcium: readings.calcium || 0,
        moisture: readings.moisture,
        ph: readings.ph,
        conductivity: readings.conductivity || 0,
        temperature: readings.temperature,
      });

      // Update device status and battery
      await storage.updateSoilDevice(deviceId, { 
        lastSeen: new Date(),
        batteryLevel,
        status: "active"
      });

      res.status(201).json(soilReading);
    } catch (error) {
      console.error("Device reading error:", error);
      res.status(400).json({ message: "Failed to record device reading" });
    }
  });

  // Dashboard summary endpoint
  app.get("/api/dashboard/summary", checkTrialStatus, async (req, res) => {
    try {
      // Get latest soil readings for main fields
      const fieldAReading = await storage.getLatestSoilReading(1, "field_a");
      const fieldBReading = await storage.getLatestSoilReading(1, "field_b");
      
      // Get animal counts
      const animals = await storage.getAnimals(1);
      const healthyAnimals = animals.filter(a => a.healthStatus === "healthy");
      
      // Get unread notifications
      const unreadNotifications = await storage.getNotifications(1, true);
      
      // Get recent recommendations
      const recommendations = await storage.getRecommendations(1);
      const latestRecommendation = recommendations[0];
      
      // Get user listings
      const userListings = await storage.getUserListings(1);
      const activeListings = userListings.filter(l => l.status === "active");

      const summary = {
        soil: {
          fieldA: fieldAReading,
          fieldB: fieldBReading,
        },
        animals: {
          total: animals.length,
          healthy: healthyAnimals.length,
        },
        market: {
          activeListings: activeListings.length,
          totalListings: userListings.length,
        },
        notifications: {
          unread: unreadNotifications.length,
          latest: unreadNotifications.slice(0, 3),
        },
        latestRecommendation,
      };

      res.json(summary);
    } catch (error) {
      console.error("Dashboard summary error:", error);
      res.status(500).json({ message: "Failed to fetch dashboard summary" });
    }
  });

  // Payment and Subscription endpoints
  
  // Create payment order with Pesapal
  app.post("/api/payments/create", async (req, res) => {
    try {
      const { amount, description } = req.body;
      const user = await storage.getUser(1); // Get current user
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Create payment order with Pesapal
      const orderResult = await createPesapalOrder({
        userId: user.id,
        amount: parseFloat(amount),
        description: description || "AgroSet Service Payment",
        currency: "UGX",
        email: user.email,
        phone: "+256701234567", // Default phone, should be from user profile
        firstName: user.firstName,
        lastName: user.lastName
      });

      if (!orderResult.success) {
        return res.status(400).json({ message: "Failed to create payment order" });
      }

      // Save payment record to database
      const payment = await storage.createPayment({
        userId: user.id,
        transactionId: orderResult.transactionId,
        merchantReference: orderResult.merchantReference,
        amount: amount.toString(),
        currency: "UGX",
        description: description || "AgroSet Service Payment",
        status: "PENDING"
      });

      res.json({
        paymentUrl: orderResult.paymentUrl,
        transactionId: payment.transactionId,
        merchantReference: payment.merchantReference
      });
    } catch (error) {
      console.error("Payment creation error:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  // Create subscription payment
  app.post("/api/payments/subscription", async (req, res) => {
    try {
      const { planType = "premium" } = req.body;
      const user = await storage.getUser(1);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user already has active subscription
      const existingSubscription = await storage.getUserSubscription(user.id);
      if (existingSubscription && existingSubscription.status === "active") {
        return res.status(409).json({ message: "Active subscription already exists" });
      }

      // Create subscription payment with Pesapal
      const subscriptionOrder = await createSubscriptionPayment({
        userId: user.id,
        planType,
        email: user.email,
        phone: "+256701234567",
        firstName: user.firstName,
        lastName: user.lastName
      });

      if (!subscriptionOrder.success) {
        return res.status(400).json({ message: "Failed to create subscription payment" });
      }

      // Save payment record
      const payment = await storage.createPayment({
        userId: user.id,
        transactionId: subscriptionOrder.transactionId,
        merchantReference: subscriptionOrder.merchantReference,
        amount: subscriptionOrder.amount || "10000",
        currency: "UGX",
        description: `AgroSet ${planType} Subscription`,
        status: "PENDING"
      });

      res.json({
        paymentUrl: subscriptionOrder.paymentUrl,
        transactionId: payment.transactionId,
        planType,
        amount: payment.amount
      });
    } catch (error) {
      console.error("Subscription creation error:", error);
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });

  // Payment callback from Pesapal
  app.get("/payment/callback", async (req, res) => {
    try {
      const { pesapal_transaction_tracking_id, pesapal_merchant_reference } = req.query;
      
      if (!pesapal_merchant_reference) {
        return res.status(400).json({ message: "Missing merchant reference" });
      }

      // Query payment status from Pesapal
      const statusResult = await queryPaymentStatus(
        pesapal_merchant_reference as string, 
        pesapal_transaction_tracking_id as string
      );

      if (statusResult.success) {
        // Update payment status in database
        await storage.updatePayment(pesapal_merchant_reference as string, {
          status: statusResult.status,
          pesapalTrackingId: pesapal_transaction_tracking_id as string
        });

        // If payment successful, create/activate subscription
        if (statusResult.status === "COMPLETED") {
          const payment = await storage.getPayment(pesapal_merchant_reference as string);
          if (payment && payment.description.includes("Subscription")) {
            const planType = payment.description.toLowerCase().includes("premium") 
              ? "premium" 
              : payment.description.toLowerCase().includes("enterprise")
              ? "enterprise"
              : "basic";
            
            const endDate = new Date();
            endDate.setMonth(endDate.getMonth() + 1); // 1 month subscription

            await storage.createSubscription({
              userId: payment.userId,
              planType,
              status: "active",
              endDate,
              paymentId: payment.id
            });

            // Mark user as no longer requiring subscription (trial completed)
            await storage.updateUserSubscriptionRequired(payment.userId, false);
          }
        }
      }

      // Redirect to appropriate page based on payment status and type
      const payment = await storage.getPayment(pesapal_merchant_reference as string);
      
      if (statusResult.status === "COMPLETED") {
        // For subscription payments, redirect to success page
        if (payment && payment.description.includes("Subscription")) {
          return res.redirect("/payment-success");
        }
        return res.redirect("/dashboard?payment=success");
      } else {
        return res.redirect("/subscription?payment=failed");
      }
    } catch (error) {
      console.error("Payment callback error:", error);
      res.redirect("/subscription?payment=error");
    }
  });

  // Get user payments
  app.get("/api/payments", async (req, res) => {
    try {
      const payments = await storage.getPayments(1); // Current user
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Get user subscription
  app.get("/api/subscription", async (req, res) => {
    try {
      const subscription = await storage.getUserSubscription(1); // Current user
      if (!subscription) {
        return res.status(404).json({ message: "No subscription found" });
      }
      res.json(subscription);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  // Admin Authentication Middleware
  const adminAuth = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || authHeader !== 'Basic YXRyZWF2ZXpAZ21haWwuY29tOkhhcmdyZWF2ZUA1MQ==') {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    next();
  };

  // Admin routes - System administration
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Check specific admin credentials
      if (email === 'atreavez@gmail.com' && password === 'Hargreave@51') {
        // Log admin login
        await storage.createAdminLog({
          adminEmail: email,
          action: 'LOGIN',
          targetType: 'system',
          targetId: null,
          description: 'Administrator logged into system',
          details: { timestamp: new Date(), loginSuccess: true },
          ipAddress: req.ip,
          userAgent: req.get('User-Agent') || null,
        });

        const authToken = Buffer.from(`${email}:${password}`).toString('base64');
        res.json({ 
          success: true, 
          token: authToken,
          admin: { email: email, name: 'System Administrator' }
        });
      } else {
        // Log failed login attempt
        await storage.createAdminLog({
          adminEmail: email || 'unknown',
          action: 'LOGIN_FAILED',
          targetType: 'system',
          targetId: null,
          description: 'Failed admin login attempt',
          details: { timestamp: new Date(), loginSuccess: false },
          ipAddress: req.ip,
          userAgent: req.get('User-Agent') || null,
        });
        
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Admin dashboard - system overview
  app.get("/api/admin/dashboard", adminAuth, async (req, res) => {
    try {
      const stats = await storage.getSystemStats();
      const recentLogs = await storage.getAdminLogs(10);
      
      res.json({ stats, recentLogs });
    } catch (error) {
      console.error("Admin dashboard error:", error);
      res.status(500).json({ message: "Failed to fetch admin dashboard" });
    }
  });

  // User management
  app.get("/api/admin/users", adminAuth, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Admin users error:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Update user status
  app.put("/api/admin/users/:userId", adminAuth, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const updates = req.body;
      
      const user = await storage.updateUserStatus(userId, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Log admin action
      await storage.createAdminLog({
        adminEmail: 'atreavez@gmail.com',
        action: 'USER_UPDATE',
        targetType: 'user',
        targetId: userId.toString(),
        description: `Updated user ${user.username}`,
        details: { updates },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || null,
      });

      res.json(user);
    } catch (error) {
      console.error("Admin user update error:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Payment management
  app.get("/api/admin/payments", adminAuth, async (req, res) => {
    try {
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      console.error("Admin payments error:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Subscription management
  app.get("/api/admin/subscriptions", adminAuth, async (req, res) => {
    try {
      const subscriptions = await storage.getAllSubscriptions();
      res.json(subscriptions);
    } catch (error) {
      console.error("Admin subscriptions error:", error);
      res.status(500).json({ message: "Failed to fetch subscriptions" });
    }
  });

  // System settings management
  app.get("/api/admin/settings", adminAuth, async (req, res) => {
    try {
      const category = req.query.category as string;
      const settings = await storage.getSystemSettings(category);
      res.json(settings);
    } catch (error) {
      console.error("Admin settings error:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Update system setting
  app.put("/api/admin/settings/:key", adminAuth, async (req, res) => {
    try {
      const key = req.params.key;
      const { value } = req.body;
      
      const setting = await storage.updateSystemSetting(key, value, 'atreavez@gmail.com');

      // Log admin action
      await storage.createAdminLog({
        adminEmail: 'atreavez@gmail.com',
        action: 'SETTING_UPDATE',
        targetType: 'system',
        targetId: key,
        description: `Updated system setting: ${key}`,
        details: { oldValue: setting.value, newValue: value },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || null,
      });

      res.json(setting);
    } catch (error) {
      console.error("Admin setting update error:", error);
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // Admin activity logs
  app.get("/api/admin/logs", adminAuth, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const logs = await storage.getAdminLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Admin logs error:", error);
      res.status(500).json({ message: "Failed to fetch logs" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
