import { 
  users, soilReadings, aiRecommendations, marketListings, animals, 
  animalHealthRecords, irrigationEvents, notifications, marketPrices, soilDevices, deletedAnimals, payments, subscriptions, adminLogs, systemSettings,
  type User, type InsertUser, type SoilReading, type InsertSoilReading,
  type AiRecommendation, type InsertAiRecommendation, type MarketListing, 
  type InsertMarketListing, type Animal, type InsertAnimal,
  type AnimalHealthRecord, type InsertAnimalHealthRecord,
  type IrrigationEvent, type InsertIrrigationEvent,
  type Notification, type InsertNotification,
  type MarketPrice, type InsertMarketPrice,
  type SoilDevice, type InsertSoilDevice,
  type DeletedAnimal, type InsertDeletedAnimal,
  type Payment, type InsertPayment,
  type Subscription, type InsertSubscription,
  type AdminLog, type InsertAdminLog,
  type SystemSetting, type InsertSystemSetting
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  checkUserTrialStatus(userId: number): Promise<{ isTrialActive: boolean; trialEndDate: Date; requiresSubscription: boolean }>;
  updateUserSubscriptionRequired(userId: number, required: boolean): Promise<User | undefined>;

  // Soil readings
  getSoilReadings(userId: number, fieldId?: string): Promise<SoilReading[]>;
  getLatestSoilReading(userId: number, fieldId: string): Promise<SoilReading | undefined>;
  createSoilReading(reading: InsertSoilReading): Promise<SoilReading>;

  // AI recommendations
  getRecommendations(userId: number, category?: string): Promise<AiRecommendation[]>;
  createRecommendation(recommendation: InsertAiRecommendation): Promise<AiRecommendation>;
  updateRecommendation(id: number, updates: Partial<AiRecommendation>): Promise<AiRecommendation | undefined>;

  // Market listings
  getMarketListings(location?: string, category?: string): Promise<MarketListing[]>;
  getUserListings(userId: number): Promise<MarketListing[]>;
  createMarketListing(listing: InsertMarketListing): Promise<MarketListing>;
  updateMarketListing(id: number, updates: Partial<MarketListing>): Promise<MarketListing | undefined>;

  // Animals
  getAnimals(userId: number): Promise<Animal[]>;
  getAnimal(id: number): Promise<Animal | undefined>;
  getAnimalByTag(tagId: string): Promise<Animal | undefined>;
  createAnimal(animal: InsertAnimal): Promise<Animal>;
  updateAnimal(id: number, updates: Partial<Animal>): Promise<Animal | undefined>;

  // Animal health records
  getAnimalHealthRecords(animalId: number): Promise<AnimalHealthRecord[]>;
  createAnimalHealthRecord(record: InsertAnimalHealthRecord): Promise<AnimalHealthRecord>;

  // Irrigation events
  getIrrigationEvents(userId: number, fieldId?: string): Promise<IrrigationEvent[]>;
  createIrrigationEvent(event: InsertIrrigationEvent): Promise<IrrigationEvent>;

  // Notifications
  getNotifications(userId: number, unreadOnly?: boolean): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<void>;

  // Market prices
  getMarketPrices(productName?: string, location?: string): Promise<MarketPrice[]>;
  createMarketPrice(price: InsertMarketPrice): Promise<MarketPrice>;

  // Soil devices
  getSoilDevices(userId: number): Promise<SoilDevice[]>;
  getSoilDevice(deviceId: string): Promise<SoilDevice | undefined>;
  createSoilDevice(device: InsertSoilDevice): Promise<SoilDevice>;
  updateSoilDevice(deviceId: string, updates: Partial<SoilDevice>): Promise<SoilDevice | undefined>;
  deleteSoilDevice(deviceId: string): Promise<boolean>;

  // Deleted animals for farm bookkeeping
  getDeletedAnimals(userId: number): Promise<DeletedAnimal[]>;
  createDeletedAnimal(deletedAnimal: InsertDeletedAnimal): Promise<DeletedAnimal>;
  deleteAnimal(animalId: number, deletionData: Omit<InsertDeletedAnimal, 'originalAnimalId' | 'tagId' | 'type' | 'breed' | 'gender' | 'birthDate' | 'weight' | 'healthStatus' | 'location' | 'registrationDate'>): Promise<boolean>;

  // Payments
  getPayments(userId: number): Promise<Payment[]>;
  getPayment(transactionId: string): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(transactionId: string, updates: Partial<Payment>): Promise<Payment | undefined>;

  // Subscriptions
  getUserSubscription(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined>;

  // Admin functions
  getAllUsers(): Promise<User[]>;
  getAllPayments(): Promise<Payment[]>;
  getAllSubscriptions(): Promise<Subscription[]>;
  getSystemStats(): Promise<{
    totalUsers: number;
    totalPayments: number;
    totalRevenue: number;
    activeSubscriptions: number;
    recentActivity: number;
  }>;
  updateUserStatus(userId: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Admin logs
  getAdminLogs(limit?: number): Promise<AdminLog[]>;
  createAdminLog(log: InsertAdminLog): Promise<AdminLog>;
  
  // System settings
  getSystemSettings(category?: string): Promise<SystemSetting[]>;
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  updateSystemSetting(key: string, value: string, updatedBy: string): Promise<SystemSetting>;
  createSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private soilReadings: Map<number, SoilReading> = new Map();
  private aiRecommendations: Map<number, AiRecommendation> = new Map();
  private marketListings: Map<number, MarketListing> = new Map();
  private animals: Map<number, Animal> = new Map();
  private animalHealthRecords: Map<number, AnimalHealthRecord> = new Map();
  private irrigationEvents: Map<number, IrrigationEvent> = new Map();
  private notifications: Map<number, Notification> = new Map();
  private marketPrices: Map<number, MarketPrice> = new Map();
  private soilDevices: Map<number, SoilDevice> = new Map();
  private deletedAnimals: Map<number, DeletedAnimal> = new Map();
  
  private currentUserId = 1;
  private currentSoilReadingId = 1;
  private currentRecommendationId = 1;
  private currentListingId = 1;
  private currentAnimalId = 1;
  private currentHealthRecordId = 1;
  private currentIrrigationEventId = 1;
  private currentNotificationId = 1;
  private currentMarketPriceId = 1;
  private currentDeviceId = 1;
  private currentDeletedAnimalId = 1;

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create default user
    const defaultUser: User = {
      id: 1,
      username: "john_farmer",
      email: "john@example.com",
      firstName: "John",
      lastName: "Farmer",
      location: "California, USA",
      farmSize: "25.5",
      createdAt: new Date(),
    };
    this.users.set(1, defaultUser);
    this.currentUserId = 2;

    // Seed initial data for demonstration
    this.seedSoilData();
    this.seedMarketData();
    this.seedAnimalData();
    this.seedNotifications();
  }

  private seedSoilData() {
    const now = new Date();
    const readings = [
      { nitrogen: "45.2", phosphorus: "23.1", potassium: "67.8", calcium: "89.4", moisture: "42.0", ph: "6.8", conductivity: "1.2", temperature: "24.5" },
      { nitrogen: "44.8", phosphorus: "22.9", potassium: "68.1", calcium: "88.7", moisture: "38.5", ph: "6.7", conductivity: "1.3", temperature: "25.1" },
      { nitrogen: "43.9", phosphorus: "22.4", potassium: "66.9", calcium: "87.2", moisture: "35.2", ph: "6.6", conductivity: "1.4", temperature: "25.8" },
    ];

    readings.forEach((reading, index) => {
      const soilReading: SoilReading = {
        id: this.currentSoilReadingId++,
        userId: 1,
        fieldId: "field_a",
        ...reading,
        timestamp: new Date(now.getTime() - (readings.length - index) * 24 * 60 * 60 * 1000),
      };
      this.soilReadings.set(soilReading.id, soilReading);
    });
  }

  private seedMarketData() {
    const listings: Omit<MarketListing, 'id' | 'createdAt'>[] = [
      {
        sellerId: 1,
        productName: "Organic Tomatoes",
        category: "Vegetables",
        quantity: "500",
        unit: "kg",
        pricePerUnit: "16800",
        location: "Kampala, Uganda",
        description: "Fresh organic tomatoes, harvested yesterday",
        photos: ["/api/placeholder/tomatoes1.jpg", "/api/placeholder/tomatoes2.jpg"],
        sellerName: "John Farmer",
        sellerPhone: "+256 701 234 567",
        sellerEmail: "john@example.com",
        latitude: "0.3476",
        longitude: "32.5825",
        status: "active",
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
      {
        sellerId: 1,
        productName: "Sweet Corn",
        category: "Grains",
        quantity: "200",
        unit: "kg",
        pricePerUnit: "10400",
        location: "Kampala, Uganda",
        description: "Fresh sweet corn from field B",
        photos: ["/api/placeholder/corn1.jpg", "/api/placeholder/corn2.jpg"],
        sellerName: "John Farmer",
        sellerPhone: "+256 701 234 567",
        sellerEmail: "john@example.com",
        latitude: "0.3476",
        longitude: "32.5825",
        status: "active",
        expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      },
    ];

    listings.forEach(listing => {
      const marketListing: MarketListing = {
        ...listing,
        id: this.currentListingId++,
        createdAt: new Date(),
      };
      this.marketListings.set(marketListing.id, marketListing);
    });
  }

  private seedAnimalData() {
    const animalData = [
      { tagId: "A001", type: "cow", breed: "Holstein", gender: "female", weight: "650.5", healthStatus: "healthy" },
      { tagId: "A002", type: "cow", breed: "Holstein", gender: "male", weight: "720.2", healthStatus: "healthy" },
      { tagId: "S001", type: "sheep", breed: "Merino", gender: "female", weight: "75.3", healthStatus: "healthy" },
    ];

    animalData.forEach(data => {
      const animal: Animal = {
        id: this.currentAnimalId++,
        userId: 1,
        ...data,
        birthDate: new Date(Date.now() - Math.random() * 3 * 365 * 24 * 60 * 60 * 1000),
        location: "Main Pasture",
        notes: "",
        createdAt: new Date(),
      };
      this.animals.set(animal.id, animal);
    });
  }

  private seedNotifications() {
    const notificationData = [
      {
        userId: 1,
        title: "Low Soil Moisture",
        message: "Field A moisture level is below optimal threshold (32%). Consider irrigation.",
        type: "warning",
        category: "soil",
        read: false,
      },
      {
        userId: 1,
        title: "Market Opportunity",
        message: "Tomato prices increased by 15% in your area. Consider listing your harvest.",
        type: "success",
        category: "market",
        read: false,
      },
    ];

    notificationData.forEach(data => {
      const notification: Notification = {
        ...data,
        id: this.currentNotificationId++,
        actionUrl: null,
        createdAt: new Date(),
      };
      this.notifications.set(notification.id, notification);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      id: this.currentUserId++,
      createdAt: new Date(),
      location: insertUser.location || null,
      farmSize: insertUser.farmSize || null,
    };
    this.users.set(user.id, user);
    return user;
  }

  // Soil reading methods
  async getSoilReadings(userId: number, fieldId?: string): Promise<SoilReading[]> {
    return Array.from(this.soilReadings.values())
      .filter(reading => reading.userId === userId && (!fieldId || reading.fieldId === fieldId))
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getLatestSoilReading(userId: number, fieldId: string): Promise<SoilReading | undefined> {
    const readings = await this.getSoilReadings(userId, fieldId);
    return readings[0];
  }

  async createSoilReading(insertReading: InsertSoilReading): Promise<SoilReading> {
    const reading: SoilReading = {
      ...insertReading,
      id: this.currentSoilReadingId++,
      timestamp: new Date(),
    };
    this.soilReadings.set(reading.id, reading);
    return reading;
  }

  // AI recommendation methods
  async getRecommendations(userId: number, category?: string): Promise<AiRecommendation[]> {
    return Array.from(this.aiRecommendations.values())
      .filter(rec => rec.userId === userId && (!category || rec.category === category))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createRecommendation(insertRec: InsertAiRecommendation): Promise<AiRecommendation> {
    const recommendation: AiRecommendation = {
      ...insertRec,
      id: this.currentRecommendationId++,
      createdAt: new Date(),
      implemented: insertRec.implemented || false,
    };
    this.aiRecommendations.set(recommendation.id, recommendation);
    return recommendation;
  }

  async updateRecommendation(id: number, updates: Partial<AiRecommendation>): Promise<AiRecommendation | undefined> {
    const recommendation = this.aiRecommendations.get(id);
    if (!recommendation) return undefined;
    
    const updated = { ...recommendation, ...updates };
    this.aiRecommendations.set(id, updated);
    return updated;
  }

  // Market listing methods
  async getMarketListings(location?: string, category?: string): Promise<MarketListing[]> {
    return Array.from(this.marketListings.values())
      .filter(listing => 
        listing.status === "active" && 
        (!location || listing.location.includes(location)) &&
        (!category || listing.category === category)
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUserListings(userId: number): Promise<MarketListing[]> {
    return Array.from(this.marketListings.values())
      .filter(listing => listing.sellerId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createMarketListing(insertListing: InsertMarketListing): Promise<MarketListing> {
    const listing: MarketListing = {
      ...insertListing,
      id: this.currentListingId++,
      createdAt: new Date(),
      description: insertListing.description || null,
      status: insertListing.status || "active",
      expiresAt: insertListing.expiresAt || null,
    };
    this.marketListings.set(listing.id, listing);
    return listing;
  }

  async updateMarketListing(id: number, updates: Partial<MarketListing>): Promise<MarketListing | undefined> {
    const listing = this.marketListings.get(id);
    if (!listing) return undefined;
    
    const updated = { ...listing, ...updates };
    this.marketListings.set(id, updated);
    return updated;
  }

  // Animal methods
  async getAnimals(userId: number): Promise<Animal[]> {
    return Array.from(this.animals.values())
      .filter(animal => animal.userId === userId)
      .sort((a, b) => a.tagId.localeCompare(b.tagId));
  }

  async getAnimal(id: number): Promise<Animal | undefined> {
    return this.animals.get(id);
  }

  async getAnimalByTag(tagId: string): Promise<Animal | undefined> {
    return Array.from(this.animals.values()).find(animal => animal.tagId === tagId);
  }

  async createAnimal(insertAnimal: InsertAnimal): Promise<Animal> {
    const animal: Animal = {
      ...insertAnimal,
      id: this.currentAnimalId++,
      createdAt: new Date(),
      breed: insertAnimal.breed || null,
      birthDate: insertAnimal.birthDate || null,
      weight: insertAnimal.weight || null,
      healthStatus: insertAnimal.healthStatus || "healthy",
      location: insertAnimal.location || null,
      notes: insertAnimal.notes || null,
    };
    this.animals.set(animal.id, animal);
    return animal;
  }

  async updateAnimal(id: number, updates: Partial<Animal>): Promise<Animal | undefined> {
    const animal = this.animals.get(id);
    if (!animal) return undefined;
    
    const updated = { ...animal, ...updates };
    this.animals.set(id, updated);
    return updated;
  }

  // Animal health record methods
  async getAnimalHealthRecords(animalId: number): Promise<AnimalHealthRecord[]> {
    return Array.from(this.animalHealthRecords.values())
      .filter(record => record.animalId === animalId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createAnimalHealthRecord(insertRecord: InsertAnimalHealthRecord): Promise<AnimalHealthRecord> {
    const record: AnimalHealthRecord = {
      ...insertRecord,
      id: this.currentHealthRecordId++,
      createdAt: new Date(),
      veterinarian: insertRecord.veterinarian || null,
      cost: insertRecord.cost || null,
      nextDueDate: insertRecord.nextDueDate || null,
    };
    this.animalHealthRecords.set(record.id, record);
    return record;
  }

  // Irrigation event methods
  async getIrrigationEvents(userId: number, fieldId?: string): Promise<IrrigationEvent[]> {
    return Array.from(this.irrigationEvents.values())
      .filter(event => event.userId === userId && (!fieldId || event.fieldId === fieldId))
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createIrrigationEvent(insertEvent: InsertIrrigationEvent): Promise<IrrigationEvent> {
    const event: IrrigationEvent = {
      ...insertEvent,
      id: this.currentIrrigationEventId++,
      timestamp: new Date(),
      duration: insertEvent.duration || null,
      waterAmount: insertEvent.waterAmount || null,
      triggeredBy: insertEvent.triggeredBy || null,
    };
    this.irrigationEvents.set(event.id, event);
    return event;
  }

  // Notification methods
  async getNotifications(userId: number, unreadOnly?: boolean): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => 
        notification.userId === userId && 
        (!unreadOnly || !notification.read)
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const notification: Notification = {
      ...insertNotification,
      id: this.currentNotificationId++,
      createdAt: new Date(),
      read: insertNotification.read || false,
      actionUrl: insertNotification.actionUrl || null,
    };
    this.notifications.set(notification.id, notification);
    return notification;
  }

  async markNotificationRead(id: number): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.read = true;
      this.notifications.set(id, notification);
    }
  }

  // Market price methods
  async getMarketPrices(productName?: string, location?: string): Promise<MarketPrice[]> {
    return Array.from(this.marketPrices.values())
      .filter(price => 
        (!productName || price.productName.toLowerCase().includes(productName.toLowerCase())) &&
        (!location || price.location.includes(location))
      )
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createMarketPrice(insertPrice: InsertMarketPrice): Promise<MarketPrice> {
    const price: MarketPrice = {
      ...insertPrice,
      id: this.currentMarketPriceId++,
      timestamp: new Date(),
      source: insertPrice.source || null,
    };
    this.marketPrices.set(price.id, price);
    return price;
  }

  // Soil device methods
  async getSoilDevices(userId: number): Promise<SoilDevice[]> {
    return Array.from(this.soilDevices.values())
      .filter(device => device.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getSoilDevice(deviceId: string): Promise<SoilDevice | undefined> {
    return Array.from(this.soilDevices.values())
      .find(device => device.deviceId === deviceId);
  }

  async createSoilDevice(insertDevice: InsertSoilDevice): Promise<SoilDevice> {
    const device: SoilDevice = {
      ...insertDevice,
      id: this.currentDeviceId++,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSeen: insertDevice.lastSeen || null,
      batteryLevel: insertDevice.batteryLevel || null,
      firmwareVersion: insertDevice.firmwareVersion || null,
      location: insertDevice.location || null,
    };
    this.soilDevices.set(device.id, device);
    return device;
  }

  async updateSoilDevice(deviceId: string, updates: Partial<SoilDevice>): Promise<SoilDevice | undefined> {
    const device = Array.from(this.soilDevices.values())
      .find(d => d.deviceId === deviceId);
    if (!device) return undefined;
    
    const updated = { ...device, ...updates, updatedAt: new Date() };
    this.soilDevices.set(device.id, updated);
    return updated;
  }

  async deleteSoilDevice(deviceId: string): Promise<boolean> {
    const device = Array.from(this.soilDevices.values())
      .find(d => d.deviceId === deviceId);
    if (!device) return false;
    
    this.soilDevices.delete(device.id);
    return true;
  }

  // Deleted animals methods for farm bookkeeping
  async getDeletedAnimals(userId: number): Promise<DeletedAnimal[]> {
    return Array.from(this.deletedAnimals.values())
      .filter(animal => animal.userId === userId)
      .sort((a, b) => b.deletionDate.getTime() - a.deletionDate.getTime());
  }

  async createDeletedAnimal(insertDeletedAnimal: InsertDeletedAnimal): Promise<DeletedAnimal> {
    const deletedAnimal: DeletedAnimal = {
      ...insertDeletedAnimal,
      id: this.currentDeletedAnimalId++,
      deletionDate: new Date(),
      salePrice: insertDeletedAnimal.salePrice || null,
      buyerInfo: insertDeletedAnimal.buyerInfo || null,
      causeOfDeath: insertDeletedAnimal.causeOfDeath || null,
      notes: insertDeletedAnimal.notes || null,
    };
    this.deletedAnimals.set(deletedAnimal.id, deletedAnimal);
    return deletedAnimal;
  }

  async deleteAnimal(animalId: number, deletionData: Omit<InsertDeletedAnimal, 'originalAnimalId' | 'tagId' | 'type' | 'breed' | 'gender' | 'birthDate' | 'weight' | 'healthStatus' | 'location' | 'registrationDate'>): Promise<boolean> {
    const animal = this.animals.get(animalId);
    if (!animal) return false;

    // Create record of deleted animal for farm bookkeeping
    await this.createDeletedAnimal({
      userId: animal.userId,
      originalAnimalId: animal.id,
      tagId: animal.tagId,
      type: animal.type,
      breed: animal.breed || null,
      gender: animal.gender,
      birthDate: animal.birthDate || null,
      weight: animal.weight || null,
      healthStatus: animal.healthStatus || null,
      location: animal.location || null,
      registrationDate: animal.registrationDate || null,
      ...deletionData,
    });

    // Remove animal from active animals
    this.animals.delete(animalId);
    
    // Remove associated health records
    const healthRecords = Array.from(this.animalHealthRecords.values())
      .filter(record => record.animalId === animalId);
    healthRecords.forEach(record => this.animalHealthRecords.delete(record.id));

    return true;
  }
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.seedDatabase();
  }

  private async seedDatabase() {
    try {
      // Check if user already exists
      const existingUser = await this.getUserByUsername("john_farmer");
      if (existingUser) return;

      // Create default user
      const user = await this.createUser({
        username: "john_farmer",
        email: "john@example.com",
        firstName: "John",
        lastName: "Farmer",
        location: "Kampala, Uganda",
        farmSize: "50",
      });

      // Seed soil data
      await this.seedSoilData(user.id);
      
      // Seed market data
      await this.seedMarketData(user.id);
      
      // Seed animal data
      await this.seedAnimalData(user.id);
      
      // Seed notifications
      await this.seedNotifications(user.id);
    } catch (error) {
      console.error("Error seeding database:", error);
    }
  }

  private async seedSoilData(userId: number) {
    const now = new Date();
    const readings = [
      { nitrogen: "45.2", phosphorus: "23.1", potassium: "67.8", calcium: "89.4", moisture: "42.0", ph: "6.8", conductivity: "1.2", temperature: "24.5" },
      { nitrogen: "44.8", phosphorus: "22.9", potassium: "68.1", calcium: "88.7", moisture: "38.5", ph: "6.7", conductivity: "1.3", temperature: "25.1" },
      { nitrogen: "43.9", phosphorus: "22.4", potassium: "66.9", calcium: "87.2", moisture: "35.2", ph: "6.6", conductivity: "1.4", temperature: "25.8" },
    ];

    for (let index = 0; index < readings.length; index++) {
      await this.createSoilReading({
        userId,
        fieldId: "field_a",
        ...readings[index],
      });
    }
  }

  private async seedMarketData(userId: number) {
    const listings = [
      {
        sellerId: userId,
        productName: "Organic Tomatoes",
        category: "Vegetables",
        quantity: "500",
        unit: "kg",
        pricePerUnit: "16800",
        location: "Kampala, Uganda",
        description: "Fresh organic tomatoes, harvested yesterday",
        photos: ["/api/placeholder/tomatoes1.jpg", "/api/placeholder/tomatoes2.jpg"],
        sellerName: "John Farmer",
        sellerPhone: "+256 701 234 567",
        sellerEmail: "john@example.com",
        latitude: "0.3476",
        longitude: "32.5825",
        status: "active",
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
      {
        sellerId: userId,
        productName: "Sweet Corn",
        category: "Grains",
        quantity: "200",
        unit: "kg",
        pricePerUnit: "10400",
        location: "Kampala, Uganda",
        description: "Fresh sweet corn from field B",
        photos: ["/api/placeholder/corn1.jpg", "/api/placeholder/corn2.jpg"],
        sellerName: "John Farmer",
        sellerPhone: "+256 701 234 567",
        sellerEmail: "john@example.com",
        latitude: "0.3476",
        longitude: "32.5825",
        status: "active",
        expiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      },
    ];

    for (const listing of listings) {
      await this.createMarketListing(listing);
    }
  }

  private async seedAnimalData(userId: number) {
    const animalData = [
      { tagId: "A001", type: "cow", breed: "Holstein", gender: "female", weight: "650.5", healthStatus: "healthy" },
      { tagId: "A002", type: "cow", breed: "Holstein", gender: "male", weight: "720.2", healthStatus: "healthy" },
      { tagId: "S001", type: "sheep", breed: "Merino", gender: "female", weight: "75.3", healthStatus: "healthy" },
    ];

    for (const data of animalData) {
      await this.createAnimal({
        userId,
        ...data,
        birthDate: new Date(Date.now() - Math.random() * 3 * 365 * 24 * 60 * 60 * 1000),
        location: "Main Pasture",
        notes: null,
      });
    }
  }

  private async seedNotifications(userId: number) {
    const notificationData = [
      {
        userId,
        title: "Low Soil Moisture",
        message: "Field A moisture level is below optimal threshold (32%). Consider irrigation.",
        type: "warning",
        category: "soil",
        read: false,
        actionUrl: null,
      },
      {
        userId,
        title: "Market Opportunity",
        message: "Tomato prices increased by 15% in your area. Consider listing your harvest.",
        type: "success",
        category: "market",
        read: false,
        actionUrl: null,
      },
    ];

    for (const notification of notificationData) {
      await this.createNotification(notification);
    }
  }
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async checkUserTrialStatus(userId: number): Promise<{ isTrialActive: boolean; trialEndDate: Date; requiresSubscription: boolean }> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const now = new Date();
    const trialEndDate = new Date(user.trialEndDate);
    const isTrialActive = now < trialEndDate;

    return {
      isTrialActive,
      trialEndDate,
      requiresSubscription: user.subscriptionRequired || false
    };
  }

  async updateUserSubscriptionRequired(userId: number, required: boolean): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ subscriptionRequired: required })
      .where(eq(users.id, userId))
      .returning();
    return user || undefined;
  }

  async getSoilReadings(userId: number, fieldId?: string): Promise<SoilReading[]> {
    if (fieldId) {
      return await db.select().from(soilReadings)
        .where(and(eq(soilReadings.userId, userId), eq(soilReadings.fieldId, fieldId)))
        .orderBy(desc(soilReadings.timestamp));
    }
    return await db.select().from(soilReadings)
      .where(eq(soilReadings.userId, userId))
      .orderBy(desc(soilReadings.timestamp));
  }

  async getLatestSoilReading(userId: number, fieldId: string): Promise<SoilReading | undefined> {
    const [reading] = await db.select().from(soilReadings)
      .where(and(eq(soilReadings.userId, userId), eq(soilReadings.fieldId, fieldId)))
      .orderBy(desc(soilReadings.timestamp))
      .limit(1);
    return reading || undefined;
  }

  async createSoilReading(insertReading: InsertSoilReading): Promise<SoilReading> {
    const [reading] = await db
      .insert(soilReadings)
      .values(insertReading)
      .returning();
    return reading;
  }

  async getRecommendations(userId: number, category?: string): Promise<AiRecommendation[]> {
    if (category) {
      return await db.select().from(aiRecommendations)
        .where(and(eq(aiRecommendations.userId, userId), eq(aiRecommendations.category, category)))
        .orderBy(desc(aiRecommendations.createdAt));
    }
    return await db.select().from(aiRecommendations)
      .where(eq(aiRecommendations.userId, userId))
      .orderBy(desc(aiRecommendations.createdAt));
  }

  async createRecommendation(insertRec: InsertAiRecommendation): Promise<AiRecommendation> {
    const [recommendation] = await db
      .insert(aiRecommendations)
      .values(insertRec)
      .returning();
    return recommendation;
  }

  async updateRecommendation(id: number, updates: Partial<AiRecommendation>): Promise<AiRecommendation | undefined> {
    const [updated] = await db
      .update(aiRecommendations)
      .set(updates)
      .where(eq(aiRecommendations.id, id))
      .returning();
    return updated || undefined;
  }

  async getMarketListings(location?: string, category?: string): Promise<MarketListing[]> {
    if (location && category) {
      return await db.select().from(marketListings)
        .where(and(eq(marketListings.location, location), eq(marketListings.category, category)))
        .orderBy(desc(marketListings.createdAt));
    } else if (location) {
      return await db.select().from(marketListings)
        .where(eq(marketListings.location, location))
        .orderBy(desc(marketListings.createdAt));
    } else if (category) {
      return await db.select().from(marketListings)
        .where(eq(marketListings.category, category))
        .orderBy(desc(marketListings.createdAt));
    }
    
    return await db.select().from(marketListings)
      .orderBy(desc(marketListings.createdAt));
  }

  async getUserListings(userId: number): Promise<MarketListing[]> {
    return await db.select().from(marketListings)
      .where(eq(marketListings.sellerId, userId))
      .orderBy(desc(marketListings.createdAt));
  }

  async createMarketListing(insertListing: InsertMarketListing): Promise<MarketListing> {
    const [listing] = await db
      .insert(marketListings)
      .values(insertListing)
      .returning();
    return listing;
  }

  async updateMarketListing(id: number, updates: Partial<MarketListing>): Promise<MarketListing | undefined> {
    const [updated] = await db
      .update(marketListings)
      .set(updates)
      .where(eq(marketListings.id, id))
      .returning();
    return updated || undefined;
  }

  async getAnimals(userId: number): Promise<Animal[]> {
    return await db.select().from(animals)
      .where(eq(animals.userId, userId))
      .orderBy(desc(animals.createdAt));
  }

  async getAnimal(id: number): Promise<Animal | undefined> {
    const [animal] = await db.select().from(animals).where(eq(animals.id, id));
    return animal || undefined;
  }

  async getAnimalByTag(tagId: string): Promise<Animal | undefined> {
    const [animal] = await db.select().from(animals).where(eq(animals.tagId, tagId));
    return animal || undefined;
  }

  async createAnimal(insertAnimal: InsertAnimal): Promise<Animal> {
    const [animal] = await db
      .insert(animals)
      .values(insertAnimal)
      .returning();
    return animal;
  }

  async updateAnimal(id: number, updates: Partial<Animal>): Promise<Animal | undefined> {
    const [updated] = await db
      .update(animals)
      .set(updates)
      .where(eq(animals.id, id))
      .returning();
    return updated || undefined;
  }

  async getAnimalHealthRecords(animalId: number): Promise<AnimalHealthRecord[]> {
    return await db.select().from(animalHealthRecords)
      .where(eq(animalHealthRecords.animalId, animalId))
      .orderBy(desc(animalHealthRecords.createdAt));
  }

  async createAnimalHealthRecord(insertRecord: InsertAnimalHealthRecord): Promise<AnimalHealthRecord> {
    const [record] = await db
      .insert(animalHealthRecords)
      .values(insertRecord)
      .returning();
    return record;
  }

  async getIrrigationEvents(userId: number, fieldId?: string): Promise<IrrigationEvent[]> {
    if (fieldId) {
      return await db.select().from(irrigationEvents)
        .where(and(eq(irrigationEvents.userId, userId), eq(irrigationEvents.fieldId, fieldId)))
        .orderBy(desc(irrigationEvents.timestamp));
    }
    return await db.select().from(irrigationEvents)
      .where(eq(irrigationEvents.userId, userId))
      .orderBy(desc(irrigationEvents.timestamp));
  }

  async createIrrigationEvent(insertEvent: InsertIrrigationEvent): Promise<IrrigationEvent> {
    const [event] = await db
      .insert(irrigationEvents)
      .values(insertEvent)
      .returning();
    return event;
  }

  async getNotifications(userId: number, unreadOnly?: boolean): Promise<Notification[]> {
    if (unreadOnly) {
      return await db.select().from(notifications)
        .where(and(eq(notifications.userId, userId), eq(notifications.read, false)))
        .orderBy(desc(notifications.createdAt));
    }
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values(insertNotification)
      .returning();
    return notification;
  }

  async markNotificationRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id));
  }

  async getMarketPrices(productName?: string, location?: string): Promise<MarketPrice[]> {
    if (productName && location) {
      return await db.select().from(marketPrices)
        .where(and(eq(marketPrices.productName, productName), eq(marketPrices.location, location)))
        .orderBy(desc(marketPrices.timestamp));
    } else if (productName) {
      return await db.select().from(marketPrices)
        .where(eq(marketPrices.productName, productName))
        .orderBy(desc(marketPrices.timestamp));
    } else if (location) {
      return await db.select().from(marketPrices)
        .where(eq(marketPrices.location, location))
        .orderBy(desc(marketPrices.timestamp));
    }
    
    return await db.select().from(marketPrices)
      .orderBy(desc(marketPrices.timestamp));
  }

  async createMarketPrice(insertPrice: InsertMarketPrice): Promise<MarketPrice> {
    const [price] = await db
      .insert(marketPrices)
      .values(insertPrice)
      .returning();
    return price;
  }

  async getSoilDevices(userId: number): Promise<SoilDevice[]> {
    return await db.select().from(soilDevices)
      .where(eq(soilDevices.userId, userId))
      .orderBy(desc(soilDevices.createdAt));
  }

  async getSoilDevice(deviceId: string): Promise<SoilDevice | undefined> {
    const [device] = await db.select().from(soilDevices)
      .where(eq(soilDevices.deviceId, deviceId));
    return device || undefined;
  }

  async createSoilDevice(insertDevice: InsertSoilDevice): Promise<SoilDevice> {
    const [device] = await db
      .insert(soilDevices)
      .values(insertDevice)
      .returning();
    return device;
  }

  async updateSoilDevice(deviceId: string, updates: Partial<SoilDevice>): Promise<SoilDevice | undefined> {
    const [updated] = await db
      .update(soilDevices)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(soilDevices.deviceId, deviceId))
      .returning();
    return updated || undefined;
  }

  async deleteSoilDevice(deviceId: string): Promise<boolean> {
    const result = await db
      .delete(soilDevices)
      .where(eq(soilDevices.deviceId, deviceId))
      .returning();
    return result.length > 0;
  }

  // Deleted animals methods for farm bookkeeping
  async getDeletedAnimals(userId: number): Promise<DeletedAnimal[]> {
    return await db.select().from(deletedAnimals)
      .where(eq(deletedAnimals.userId, userId))
      .orderBy(desc(deletedAnimals.deletionDate));
  }

  async createDeletedAnimal(insertDeletedAnimal: InsertDeletedAnimal): Promise<DeletedAnimal> {
    const [deletedAnimal] = await db
      .insert(deletedAnimals)
      .values(insertDeletedAnimal)
      .returning();
    return deletedAnimal;
  }

  async deleteAnimal(animalId: number, deletionData: Omit<InsertDeletedAnimal, 'originalAnimalId' | 'tagId' | 'type' | 'breed' | 'gender' | 'birthDate' | 'weight' | 'healthStatus' | 'location' | 'registrationDate'>): Promise<boolean> {
    // Get the animal data first
    const [animal] = await db.select().from(animals).where(eq(animals.id, animalId));
    if (!animal) return false;

    // Create record of deleted animal for farm bookkeeping
    await this.createDeletedAnimal({
      userId: animal.userId,
      originalAnimalId: animal.id,
      tagId: animal.tagId,
      type: animal.type,
      breed: animal.breed,
      gender: animal.gender,
      birthDate: animal.birthDate,
      weight: animal.weight,
      healthStatus: animal.healthStatus,
      location: animal.location,
      registrationDate: animal.registrationDate,
      ...deletionData,
    });

    // Delete associated health records
    await db.delete(animalHealthRecords).where(eq(animalHealthRecords.animalId, animalId));
    
    // Delete the animal
    const result = await db.delete(animals).where(eq(animals.id, animalId)).returning();
    return result.length > 0;
  }

  // Payment methods
  async getPayments(userId: number): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.createdAt));
  }

  async getPayment(transactionId: string): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments)
      .where(eq(payments.transactionId, transactionId));
    return payment;
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values(insertPayment)
      .returning();
    return payment;
  }

  async updatePayment(transactionId: string, updates: Partial<Payment>): Promise<Payment | undefined> {
    const [payment] = await db
      .update(payments)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(payments.transactionId, transactionId))
      .returning();
    return payment;
  }

  // Subscription methods
  async getUserSubscription(userId: number): Promise<Subscription | undefined> {
    const [subscription] = await db.select().from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .orderBy(desc(subscriptions.createdAt));
    return subscription;
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const [subscription] = await db
      .insert(subscriptions)
      .values(insertSubscription)
      .returning();
    return subscription;
  }

  async updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const [subscription] = await db
      .update(subscriptions)
      .set(updates)
      .where(eq(subscriptions.id, id))
      .returning();
    return subscription;
  }

  // Admin methods
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  async getAllSubscriptions(): Promise<Subscription[]> {
    return await db.select().from(subscriptions).orderBy(desc(subscriptions.createdAt));
  }

  async getSystemStats(): Promise<{
    totalUsers: number;
    totalPayments: number;
    totalRevenue: number;
    activeSubscriptions: number;
    recentActivity: number;
  }> {
    const [userCount] = await db.select({ count: users.id }).from(users);
    const [paymentCount] = await db.select({ count: payments.id }).from(payments);
    const allPayments = await db.select().from(payments).where(eq(payments.status, 'COMPLETED'));
    const [subscriptionCount] = await db.select({ count: subscriptions.id }).from(subscriptions).where(eq(subscriptions.status, 'active'));
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const [recentActivity] = await db.select({ count: notifications.id }).from(notifications);
    
    const totalRevenue = allPayments.reduce((sum, payment) => sum + Number(payment.amount), 0);

    return {
      totalUsers: userCount?.count || 0,
      totalPayments: paymentCount?.count || 0,
      totalRevenue,
      activeSubscriptions: subscriptionCount?.count || 0,
      recentActivity: recentActivity?.count || 0
    };
  }

  async updateUserStatus(userId: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
  
  // Admin logs
  async getAdminLogs(limit: number = 50): Promise<AdminLog[]> {
    return await db.select().from(adminLogs).orderBy(desc(adminLogs.timestamp)).limit(limit);
  }

  async createAdminLog(insertAdminLog: InsertAdminLog): Promise<AdminLog> {
    const [adminLog] = await db
      .insert(adminLogs)
      .values(insertAdminLog)
      .returning();
    return adminLog;
  }
  
  // System settings
  async getSystemSettings(category?: string): Promise<SystemSetting[]> {
    if (category) {
      return await db.select().from(systemSettings).where(eq(systemSettings.category, category));
    }
    return await db.select().from(systemSettings);
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting;
  }

  async updateSystemSetting(key: string, value: string, updatedBy: string): Promise<SystemSetting> {
    const existing = await this.getSystemSetting(key);
    if (existing) {
      const [setting] = await db
        .update(systemSettings)
        .set({ value, updatedBy, updatedAt: new Date() })
        .where(eq(systemSettings.key, key))
        .returning();
      return setting;
    } else {
      return await this.createSystemSetting({
        key,
        value,
        updatedBy,
        description: null,
        category: 'general'
      });
    }
  }

  async createSystemSetting(insertSystemSetting: InsertSystemSetting): Promise<SystemSetting> {
    const [setting] = await db
      .insert(systemSettings)
      .values(insertSystemSetting)
      .returning();
    return setting;
  }
}

export const storage = new DatabaseStorage();
