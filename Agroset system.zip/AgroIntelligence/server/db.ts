import { Pool, neonConfig } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";

// Configure for production environment (disable WebSocket completely)
if (process.env.NODE_ENV === 'production' || process.env.DISABLE_WEBSOCKET === 'true') {
  console.log('🔧 Production mode: Disabling WebSocket connections for Neon database');
  // Completely disable WebSocket in production and Docker environments
  neonConfig.webSocketConstructor = undefined;
  neonConfig.useSecureWebSocket = false;
  neonConfig.pipelineConnect = false;
  neonConfig.pipelineTLS = false;
  neonConfig.poolQueryViaFetch = true; // Force HTTP-only connections
} else {
  console.log('🔧 Development mode: Using WebSocket connections for Neon database');
  neonConfig.webSocketConstructor = ws;
}

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle({ client: pool, schema });