import crypto from 'crypto';
import axios from 'axios';

// Pesapal configuration from user's registration
const PESAPAL_CONFIG = {
  IPN_ID: '1a9676a5-6621-422c-8d48-db8dc027f4a6',
  CONSUMER_KEY: 'TDpigBOOhs+zAl8cwH2Fl82jJGyD8xev',
  CONSUMER_SECRET: '1KpqkfsMaihIcOlhnBoqBZ5ssmw=',
  BASE_URL: 'https://www.pesapal.com/API/PostPesapalDirectOrderV4',
  STATUS_URL: 'https://www.pesapal.com/api/querypaymentstatus'
};

// OAuth 1.0 signature generation for Pesapal
function generateOAuthSignature(
  httpMethod: string,
  baseUrl: string,
  params: Record<string, string>
): string {
  // Sort parameters
  const sortedParams = Object.keys(params)
    .sort()
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
    .join('&');

  // Create signature base string
  const signatureBaseString = `${httpMethod.toUpperCase()}&${encodeURIComponent(baseUrl)}&${encodeURIComponent(sortedParams)}`;

  // Create signing key
  const signingKey = `${encodeURIComponent(PESAPAL_CONFIG.CONSUMER_SECRET)}&`;

  // Generate HMAC-SHA1 signature
  const signature = crypto
    .createHmac('sha1', signingKey)
    .update(signatureBaseString)
    .digest('base64');

  return signature;
}

// Generate OAuth header for Pesapal API calls
function generateOAuthHeader(
  httpMethod: string,
  baseUrl: string,
  additionalParams: Record<string, string> = {}
): string {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const nonce = crypto.randomBytes(16).toString('hex');

  const oauthParams = {
    oauth_consumer_key: PESAPAL_CONFIG.CONSUMER_KEY,
    oauth_nonce: nonce,
    oauth_signature_method: 'HMAC-SHA1',
    oauth_timestamp: timestamp,
    oauth_version: '1.0',
    ...additionalParams
  };

  const signature = generateOAuthSignature(httpMethod, baseUrl, oauthParams);
  oauthParams.oauth_signature = signature;

  const authHeader = 'OAuth ' + Object.keys(oauthParams)
    .map(key => `${encodeURIComponent(key)}="${encodeURIComponent(oauthParams[key])}"`)
    .join(', ');

  return authHeader;
}

// Create Pesapal payment order
export async function createPesapalOrder(orderData: {
  userId: number;
  amount: number;
  description: string;
  currency?: string;
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
}) {
  const merchantReference = `AGS_${Date.now()}_${orderData.userId}`;
  
  const paymentData = {
    Amount: orderData.amount.toString(),
    Description: orderData.description,
    Type: 'MERCHANT',
    Reference: merchantReference,
    FirstName: orderData.firstName,
    LastName: orderData.lastName,
    Email: orderData.email,
    PhoneNumber: orderData.phone,
    Currency: orderData.currency || 'UGX',
    CallbackURL: `https://agroset.us/payment/callback?ref=${merchantReference}`,
    NotificationID: PESAPAL_CONFIG.IPN_ID
  };

  try {
    const authHeader = generateOAuthHeader('POST', PESAPAL_CONFIG.BASE_URL, paymentData);

    const response = await axios.post(PESAPAL_CONFIG.BASE_URL, null, {
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      params: paymentData
    });

    if (response.data) {
      // Parse the response to get the payment URL
      const responseText = response.data as string;
      
      return {
        success: true,
        paymentUrl: responseText,
        merchantReference,
        transactionId: merchantReference
      };
    }

    throw new Error('Invalid response from Pesapal');
  } catch (error) {
    console.error('Pesapal order creation failed:', error);
    throw new Error('Failed to create payment order');
  }
}

// Query payment status from Pesapal
export async function queryPaymentStatus(merchantReference: string, pesapalTrackingId?: string) {
  const queryParams = {
    pesapal_merchant_reference: merchantReference,
    pesapal_transaction_tracking_id: pesapalTrackingId || ''
  };

  try {
    const authHeader = generateOAuthHeader('POST', PESAPAL_CONFIG.STATUS_URL, queryParams);

    const response = await axios.post(PESAPAL_CONFIG.STATUS_URL, null, {
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      params: queryParams
    });

    if (response.data) {
      const statusData = response.data as string;
      
      // Parse Pesapal response format: pesapal_response_data=PENDING|COMPLETED|FAILED
      const status = statusData.split('=')[1] || 'UNKNOWN';
      
      return {
        success: true,
        status: status.toUpperCase(),
        merchantReference,
        pesapalTrackingId
      };
    }

    throw new Error('Invalid status response from Pesapal');
  } catch (error) {
    console.error('Pesapal status query failed:', error);
    throw new Error('Failed to query payment status');
  }
}

// Process IPN (Instant Payment Notification) from Pesapal
export function processIPNNotification(ipnData: {
  pesapal_transaction_tracking_id: string;
  pesapal_merchant_reference: string;
  pesapal_notification_type: string;
}) {
  return {
    trackingId: ipnData.pesapal_transaction_tracking_id,
    merchantReference: ipnData.pesapal_merchant_reference,
    notificationType: ipnData.pesapal_notification_type,
    timestamp: new Date()
  };
}

// Generate subscription payment order
export async function createSubscriptionPayment(subscriptionData: {
  userId: number;
  planType: string;
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
}) {
  const planPrices = {
    basic: 5000, // UGX 5,000 monthly
    premium: 10000, // UGX 10,000 monthly
    enterprise: 20000 // UGX 20,000 monthly
  };

  const amount = planPrices[subscriptionData.planType as keyof typeof planPrices] || planPrices.basic;

  return await createPesapalOrder({
    userId: subscriptionData.userId,
    amount,
    description: `AgroSet ${subscriptionData.planType.charAt(0).toUpperCase() + subscriptionData.planType.slice(1)} Subscription`,
    currency: 'UGX',
    email: subscriptionData.email,
    phone: subscriptionData.phone,
    firstName: subscriptionData.firstName,
    lastName: subscriptionData.lastName
  });
}