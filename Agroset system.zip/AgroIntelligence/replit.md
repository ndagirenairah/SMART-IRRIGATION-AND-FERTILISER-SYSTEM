# AgroSet - Smart Agriculture Management Platform

## Overview

AgroSet is a comprehensive full-stack web application designed for smart agriculture management. The platform provides farmers with real-time soil monitoring, AI-powered recommendations, marketplace functionality, and animal health tracking. Built with a modern tech stack including React, Express.js, and PostgreSQL with Drizzle ORM.

## Recent Changes (July 22, 2025)

✓ Successfully migrated from in-memory storage to PostgreSQL database with Drizzle ORM
✓ Implemented complete DatabaseStorage class with all CRUD operations
✓ Added proper database relationships and schema management
✓ Updated all pricing displays across the platform to use Uganda Shillings (UGX)
✓ Removed all USD references and replaced with UGX currency formatting
✓ Set up automatic database seeding with sample data for testing
✓ Enhanced visual design across entire platform with modern agricultural styling
✓ Implemented gradient backgrounds, glassmorphism effects, and improved color schemes
✓ Updated headers with gradient text effects and enhanced navigation styling
✓ Added custom CSS utility classes for consistent agricultural branding
✓ Improved card designs with backdrop blur effects and enhanced shadows
✓ Enhanced NPK device integration to support real hardware scanning and manual data entry
✓ Added QR code parsing for authentic NPK device connection (format: NPK:DEVICE_ID:MODEL:FIRMWARE)
✓ Implemented manual data entry interface for real NPK device readings
✓ Added device validation and API key authentication for real-time data reception
✓ Created comprehensive soil data recording system supporting both automatic and manual entry
✓ Fixed email input field binding issues in login and registration forms
✓ Enabled functional auto irrigation toggle button with visual state changes
✓ Integrated Google Maps API across the entire system for enhanced location functionality
✓ Created reusable MapComponent and LocationPicker components for location selection
✓ Added Field Location tab in AgroSoil module with interactive Google Maps integration
✓ Enhanced registration form with Google Maps-powered location selection
✓ Implemented geolocation support for automatic current location detection
✓ Integrated Pesapal payment gateway for secure subscription payments
✓ Added comprehensive payment and subscription management system
✓ Created payment tables with PostgreSQL database integration
✓ Built subscription page with multiple plan options and Pesapal integration
✓ Implemented payment callbacks and IPN handling for transaction processing
✓ Added subscription status tracking and payment history features
✓ Created comprehensive systems administration panel with full system control capabilities
✓ Implemented secure admin authentication for single administrator (atreavez@gmail.com)
✓ Added admin database schema with settings, logs, and activity tracking tables
✓ Built complete admin API endpoints for user, payment, subscription, and system management
✓ Created multi-tab admin interface with Users, Payments, Subscriptions, Settings, Monitoring, and Logs
✓ Added real-time system monitoring with health status indicators
✓ Implemented system settings management with live configuration updates
✓ Added user management controls including trial status and subscription management
✓ Created comprehensive activity logging system for all admin actions
✓ Built system administration tools including maintenance mode, cache management, and session control
✓ Added secure admin panel accessible only via direct URL (/admin-control-panel) without public navigation links
✓ Created comprehensive Docker deployment configuration with multi-stage builds
✓ Implemented production-ready Dockerfile with security best practices and health checks
✓ Added Docker Compose configurations for both development and production environments
✓ Created Nginx reverse proxy configuration with SSL support, rate limiting, and security headers
✓ Built automated deployment scripts and comprehensive documentation for server deployment
✓ Configured external database connection support for production PostgreSQL instances
✓ Added database migration handling and production startup scripts for containerized deployment
✓ Enhanced deploy.sh to use Docker containers with comprehensive build pipeline and health checking
✓ Fixed WebSocket connection issues in Docker environments by disabling WebSockets for Neon database
✓ Implemented robust Docker deployment with retry logic and comprehensive error handling
✓ Added Docker management commands for logs, restart, rebuild, and shell access
✓ Updated deployment to run on port 8080 externally (6000 internally) with proper container management
✓ Successfully validated Docker container deployment with external Neon database integration
✓ Confirmed Docker environment properly handles WebSocket disabling and database connectivity

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Charts**: Chart.js with react-chartjs-2 for data visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL storage
- **API Design**: RESTful API endpoints with JSON responses
- **Error Handling**: Centralized error handling middleware

### Database Design
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Tables**: Users, soil readings, AI recommendations, market listings, animals, health records, irrigation events, notifications, and market prices
- **Relationships**: Proper foreign key relationships between entities

## Key Components

### Soil Monitoring System
- Real-time soil sensor data collection (nitrogen, phosphorus, potassium, pH, moisture, temperature)
- Historical data visualization with interactive charts
- Field-specific monitoring capabilities
- Latest reading displays with trend indicators

### AI Recommendation Engine
- Integration with OpenAI GPT-4o for intelligent farming recommendations
- Automated analysis of soil data to generate actionable insights
- Categorized recommendations (fertilizer, irrigation, general management)
- Priority-based recommendation system

### Marketplace Platform
- Product listing and browsing functionality
- Category-based filtering and search
- User-specific listing management
- Market price tracking and trends

### Animal Management
- Individual animal tracking with unique tags
- Health record management and monitoring
- Vaccination and treatment history
- Animal status tracking (healthy, sick, treatment)

### Notification System
- Real-time alerts and notifications
- Priority-based notification categorization
- Mark as read/unread functionality
- System-wide notification center

## Data Flow

1. **Client Requests**: Frontend components use TanStack Query to fetch data from API endpoints
2. **API Processing**: Express.js routes handle requests and interact with the database through Drizzle ORM
3. **Database Operations**: PostgreSQL stores and retrieves data with proper indexing and relationships
4. **Real-time Updates**: Query invalidation ensures fresh data after mutations
5. **AI Integration**: OpenAI API calls generate recommendations based on soil data
6. **Response Flow**: JSON responses flow back through the stack to update the UI

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for Neon Database
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives
- **openai**: AI recommendation generation
- **chart.js**: Data visualization
- **wouter**: Lightweight React router

### Development Tools
- **drizzle-kit**: Database schema management and migrations
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling for server code
- **vite**: Frontend build tool and development server

### Database Schema
The application uses a comprehensive schema with the following main entities:
- Users (authentication and profile data)
- Soil readings (sensor data with timestamps)
- AI recommendations (generated insights and status)
- Market listings (product marketplace)
- Animals (livestock tracking)
- Health records (veterinary data)
- Irrigation events (watering history)
- Notifications (system alerts)

## Deployment Strategy

### Development Environment
- Vite development server for frontend with HMR
- tsx for running TypeScript server code directly
- Environment variables for API keys and database connections
- Replit-specific optimizations and error handling

### Production Build
- Vite builds optimized frontend bundle to `dist/public`
- esbuild bundles server code to `dist/index.js`
- Single command deployment with `npm run build && npm start`
- Static file serving for production frontend assets

### Environment Configuration
- DATABASE_URL for PostgreSQL connection
- OPENAI_API_KEY for AI recommendation generation
- NODE_ENV for environment-specific behavior
- Session secrets and security configurations

The application follows a monorepo structure with shared TypeScript schemas between client and server, ensuring type safety across the entire stack. The architecture prioritizes developer experience with hot reloading, type safety, and modern tooling while maintaining production readiness with optimized builds and proper error handling.