#!/bin/bash

echo "🌱 AgroSet Neon Database Setup"
echo "=================================="
echo ""

echo "The error you encountered shows you're using a localhost database instead of Neon."
echo "Current DATABASE_URL: postgresql://postgres:***@localhost:5436/haveyoueaten_db"
echo ""

echo "🔧 To fix this, you need to:"
echo ""
echo "1. Go to: https://console.neon.tech/"
echo "2. Select your database project"
echo "3. Go to 'Connection Details' or 'Dashboard'"
echo "4. Copy the connection string that looks like:"
echo "   postgresql://username:password@host.neon.database/dbname?sslmode=require"
echo ""

echo "5. Then run ONE of these commands:"
echo ""
echo "   Option A - Set environment variable (temporary):"
echo "   export DATABASE_URL='your_neon_connection_string_here'"
echo ""
echo "   Option B - Update .env file (permanent):"
echo "   echo 'DATABASE_URL=your_neon_connection_string_here' > .env"
echo ""

echo "6. Finally, test the connection:"
echo "   node simple-start.js"
echo ""

echo "⚠️  IMPORTANT: The connection string MUST contain:"
echo "   - .neon.database in the hostname"
echo "   - ?sslmode=require at the end"
echo "   - Your actual Neon username and password"
echo ""

echo "📝 Example of a correct Neon URL:"
echo "   postgresql://myuser:mypassword@ep-cool-lab-12345.us-east-1.aws.neon.database/mydb?sslmode=require"
echo ""

echo "❌ What NOT to use (will fail):"
echo "   - postgresql://postgres@localhost:5432/db"
echo "   - postgresql://user@127.0.0.1:5436/db"
echo "   - Any URL containing 'localhost' or '127.0.0.1'"