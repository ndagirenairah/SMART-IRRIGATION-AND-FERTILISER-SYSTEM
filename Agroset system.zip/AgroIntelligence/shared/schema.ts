import { pgTable, text, serial, integer, boolean, timestamp, decimal, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  location: text("location"),
  farmSize: decimal("farm_size", { precision: 10, scale: 2 }),
  trialStartDate: timestamp("trial_start_date").defaultNow().notNull(),
  trialEndDate: timestamp("trial_end_date").default(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)).notNull(),
  subscriptionRequired: boolean("subscription_required").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Soil sensor readings
export const soilReadings = pgTable("soil_readings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  fieldId: text("field_id").notNull(),
  nitrogen: decimal("nitrogen", { precision: 5, scale: 2 }).notNull(),
  phosphorus: decimal("phosphorus", { precision: 5, scale: 2 }).notNull(),
  potassium: decimal("potassium", { precision: 5, scale: 2 }).notNull(),
  calcium: decimal("calcium", { precision: 5, scale: 2 }).notNull(),
  moisture: decimal("moisture", { precision: 5, scale: 2 }).notNull(),
  ph: decimal("ph", { precision: 4, scale: 2 }).notNull(),
  conductivity: decimal("conductivity", { precision: 8, scale: 2 }).notNull(),
  temperature: decimal("temperature", { precision: 5, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// AI recommendations
export const aiRecommendations = pgTable("ai_recommendations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  fieldId: text("field_id").notNull(),
  recommendation: text("recommendation").notNull(),
  category: text("category").notNull(), // 'fertilizer', 'irrigation', 'general'
  priority: text("priority").notNull(), // 'low', 'medium', 'high', 'critical'
  implemented: boolean("implemented").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Marketplace listings
export const marketListings = pgTable("market_listings", {
  id: serial("id").primaryKey(),
  sellerId: integer("seller_id").references(() => users.id).notNull(),
  productName: text("product_name").notNull(),
  category: text("category").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull(), // 'kg', 'tons', 'pieces'
  pricePerUnit: decimal("price_per_unit", { precision: 10, scale: 2 }).notNull(),
  location: text("location").notNull(),
  description: text("description"),
  photos: text("photos").array().default([]), // Array of photo URLs
  sellerName: text("seller_name"), // Seller's full name
  sellerPhone: text("seller_phone"), // Seller's phone number
  sellerEmail: text("seller_email"), // Seller's email
  latitude: decimal("latitude", { precision: 10, scale: 8 }), // GPS coordinates
  longitude: decimal("longitude", { precision: 11, scale: 8 }), // GPS coordinates
  status: text("status").default("active"), // 'active', 'sold', 'expired'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
});

// Animals
export const animals = pgTable("animals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tagId: text("tag_id").notNull().unique(),
  type: text("type").notNull(), // 'cow', 'sheep', 'goat', 'pig', etc.
  breed: text("breed"),
  gender: text("gender").notNull(),
  birthDate: timestamp("birth_date"),
  weight: decimal("weight", { precision: 6, scale: 2 }),
  healthStatus: text("health_status").default("healthy"), // 'healthy', 'sick', 'quarantine'
  location: text("location"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Animal health records
export const animalHealthRecords = pgTable("animal_health_records", {
  id: serial("id").primaryKey(),
  animalId: integer("animal_id").references(() => animals.id).notNull(),
  recordType: text("record_type").notNull(), // 'vaccination', 'treatment', 'checkup'
  description: text("description").notNull(),
  veterinarian: text("veterinarian"),
  cost: decimal("cost", { precision: 8, scale: 2 }),
  nextDueDate: timestamp("next_due_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Irrigation events
export const irrigationEvents = pgTable("irrigation_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  fieldId: text("field_id").notNull(),
  type: text("type").notNull(), // 'manual', 'automatic'
  duration: integer("duration"), // minutes
  waterAmount: decimal("water_amount", { precision: 8, scale: 2 }), // liters
  triggeredBy: text("triggered_by"), // 'user', 'system', 'schedule'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'warning', 'error', 'success'
  category: text("category").notNull(), // 'soil', 'market', 'animal', 'system'
  read: boolean("read").default(false),
  actionUrl: text("action_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Market price history
export const marketPrices = pgTable("market_prices", {
  id: serial("id").primaryKey(),
  productName: text("product_name").notNull(),
  location: text("location").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  unit: text("unit").notNull(),
  source: text("source"), // 'local_market', 'wholesale', 'retail'
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Soil monitoring devices
export const soilDevices = pgTable("soil_devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  deviceId: text("device_id").notNull().unique(),
  deviceName: text("device_name").notNull(),
  fieldId: text("field_id").notNull(),
  status: text("status").notNull().default("active"), // active, inactive, error
  apiKey: text("api_key").notNull(),
  lastSeen: timestamp("last_seen"),
  batteryLevel: integer("battery_level"), // percentage
  firmwareVersion: text("firmware_version"),
  location: text("location"), // GPS coordinates or description
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Deleted animals for farm bookkeeping
export const deletedAnimals = pgTable("deleted_animals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  originalAnimalId: integer("original_animal_id").notNull(),
  tagId: text("tag_id").notNull(),
  type: text("type").notNull(),
  breed: text("breed"),
  gender: text("gender").notNull(),
  birthDate: timestamp("birth_date"),
  weight: decimal("weight", { precision: 8, scale: 2 }),
  healthStatus: text("health_status"),
  location: text("location"),
  registrationDate: timestamp("registration_date"),
  deletionReason: text("deletion_reason").notNull(), // 'sold', 'deceased', 'transferred'
  deletionDate: timestamp("deletion_date").defaultNow().notNull(),
  salePrice: decimal("sale_price", { precision: 10, scale: 2 }), // if sold
  buyerInfo: text("buyer_info"), // if sold
  causeOfDeath: text("cause_of_death"), // if deceased
  notes: text("notes"),
  deletedBy: text("deleted_by"), // username who performed the deletion
});

// Payment transactions for Pesapal integration
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  transactionId: text("transaction_id").notNull().unique(),
  pesapalTrackingId: text("pesapal_tracking_id"),
  merchantReference: text("merchant_reference").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").default("UGX").notNull(),
  description: text("description").notNull(),
  status: text("status").default("PENDING"), // PENDING, COMPLETED, FAILED, CANCELLED
  paymentMethod: text("payment_method"), // Mobile Money, Card, Bank
  pesapalOrderId: text("pesapal_order_id"),
  ipnId: text("ipn_id").default("1a9676a5-6621-422c-8d48-db8dc027f4a6"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User subscriptions for premium features
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  planType: text("plan_type").notNull(), // basic, premium, enterprise
  status: text("status").default("active"), // active, cancelled, expired
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  paymentId: integer("payment_id").references(() => payments.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Admin activity logs
export const adminLogs = pgTable("admin_logs", {
  id: serial("id").primaryKey(),
  adminEmail: text("admin_email").notNull(),
  action: text("action").notNull(),
  targetType: text("target_type").notNull(), // 'user', 'payment', 'listing', 'system'
  targetId: text("target_id"),
  description: text("description").notNull(),
  details: json("details"), // Additional data about the action
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// System settings for admin control
export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  category: text("category").notNull(), // 'general', 'payment', 'notification', 'feature'
  updatedBy: text("updated_by").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  soilReadings: many(soilReadings),
  aiRecommendations: many(aiRecommendations),
  marketListings: many(marketListings),
  animals: many(animals),
  irrigationEvents: many(irrigationEvents),
  notifications: many(notifications),
  soilDevices: many(soilDevices),
  deletedAnimals: many(deletedAnimals),
  payments: many(payments),
  subscriptions: many(subscriptions),
}));

export const soilDevicesRelations = relations(soilDevices, ({ one }) => ({
  user: one(users, { fields: [soilDevices.userId], references: [users.id] }),
}));

export const soilReadingsRelations = relations(soilReadings, ({ one }) => ({
  user: one(users, { fields: [soilReadings.userId], references: [users.id] }),
}));

export const aiRecommendationsRelations = relations(aiRecommendations, ({ one }) => ({
  user: one(users, { fields: [aiRecommendations.userId], references: [users.id] }),
}));

export const marketListingsRelations = relations(marketListings, ({ one }) => ({
  seller: one(users, { fields: [marketListings.sellerId], references: [users.id] }),
}));

export const animalsRelations = relations(animals, ({ one, many }) => ({
  user: one(users, { fields: [animals.userId], references: [users.id] }),
  healthRecords: many(animalHealthRecords),
}));

export const animalHealthRecordsRelations = relations(animalHealthRecords, ({ one }) => ({
  animal: one(animals, { fields: [animalHealthRecords.animalId], references: [animals.id] }),
}));

export const irrigationEventsRelations = relations(irrigationEvents, ({ one }) => ({
  user: one(users, { fields: [irrigationEvents.userId], references: [users.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

export const deletedAnimalsRelations = relations(deletedAnimals, ({ one }) => ({
  user: one(users, { fields: [deletedAnimals.userId], references: [users.id] }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, { fields: [payments.userId], references: [users.id] }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, { fields: [subscriptions.userId], references: [users.id] }),
  payment: one(payments, { fields: [subscriptions.paymentId], references: [payments.id] }),
}));

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertSoilReadingSchema = createInsertSchema(soilReadings).omit({
  id: true,
  timestamp: true,
});

export const insertAiRecommendationSchema = createInsertSchema(aiRecommendations).omit({
  id: true,
  createdAt: true,
});

export const insertMarketListingSchema = createInsertSchema(marketListings).omit({
  id: true,
  createdAt: true,
});

export const insertAnimalSchema = createInsertSchema(animals).omit({
  id: true,
  createdAt: true,
});

export const insertAnimalHealthRecordSchema = createInsertSchema(animalHealthRecords).omit({
  id: true,
  createdAt: true,
});

export const insertIrrigationEventSchema = createInsertSchema(irrigationEvents).omit({
  id: true,
  timestamp: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertMarketPriceSchema = createInsertSchema(marketPrices).omit({
  id: true,
  timestamp: true,
});

export const insertSoilDeviceSchema = createInsertSchema(soilDevices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDeletedAnimalSchema = createInsertSchema(deletedAnimals).omit({
  id: true,
  deletionDate: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
});

export const insertAdminLogSchema = createInsertSchema(adminLogs).omit({
  id: true,
  timestamp: true,
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type SoilReading = typeof soilReadings.$inferSelect;
export type InsertSoilReading = z.infer<typeof insertSoilReadingSchema>;
export type AiRecommendation = typeof aiRecommendations.$inferSelect;
export type InsertAiRecommendation = z.infer<typeof insertAiRecommendationSchema>;
export type MarketListing = typeof marketListings.$inferSelect;
export type InsertMarketListing = z.infer<typeof insertMarketListingSchema>;
export type Animal = typeof animals.$inferSelect;
export type InsertAnimal = z.infer<typeof insertAnimalSchema>;
export type AnimalHealthRecord = typeof animalHealthRecords.$inferSelect;
export type InsertAnimalHealthRecord = z.infer<typeof insertAnimalHealthRecordSchema>;
export type IrrigationEvent = typeof irrigationEvents.$inferSelect;
export type InsertIrrigationEvent = z.infer<typeof insertIrrigationEventSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type MarketPrice = typeof marketPrices.$inferSelect;
export type InsertMarketPrice = z.infer<typeof insertMarketPriceSchema>;
export type SoilDevice = typeof soilDevices.$inferSelect;
export type InsertSoilDevice = z.infer<typeof insertSoilDeviceSchema>;
export type DeletedAnimal = typeof deletedAnimals.$inferSelect;
export type InsertDeletedAnimal = z.infer<typeof insertDeletedAnimalSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type AdminLog = typeof adminLogs.$inferSelect;
export type InsertAdminLog = z.infer<typeof insertAdminLogSchema>;
export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;
