#!/bin/bash

echo "🔄 Restarting AgroSet Application..."

# Kill existing process
if [ -f .agroset.pid ]; then
    PID=$(cat .agroset.pid)
    echo "Stopping existing process (PID: $PID)..."
    kill $PID 2>/dev/null || true
    sleep 5
    kill -9 $PID 2>/dev/null || true
    rm -f .agroset.pid
fi

# Kill any remaining processes
echo "Cleaning up any remaining processes..."
pkill -f 'node start-neon.js' 2>/dev/null || true
lsof -ti:6000 | xargs kill -9 2>/dev/null || true

sleep 3

# Verify DATABASE_URL is set
if [ -z "$DATABASE_URL" ]; then
    echo "❌ DATABASE_URL environment variable is not set!"
    echo "   Run: export DATABASE_URL='your_neon_database_url'"
    exit 1
fi

echo "✅ DATABASE_URL: $(echo $DATABASE_URL | sed 's/:.*@/:***@/')"

# Start new process
echo "🚀 Starting new application instance..."
NODE_ENV=production PORT=6000 nohup node start-neon.js > logs/app.log 2>&1 &
APP_PID=$!

echo "Application restarted with PID: $APP_PID"
echo $APP_PID > .agroset.pid

sleep 10

# Health check
if curl -f http://localhost:6000/api/user > /dev/null 2>&1; then
    echo "✅ AgroSet is running successfully on port 6000!"
    echo "📊 Process ID: $APP_PID"
else
    echo "❌ Health check failed. Check logs: tail -f logs/app.log"
    exit 1
fi