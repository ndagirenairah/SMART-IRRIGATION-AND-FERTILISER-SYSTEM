import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  Sprout, 
  Check, 
  Star, 
  TrendingUp, 
  Store, 
  Heart, 
  Zap,
  Shield,
  Users,
  ArrowRight,
  ArrowLeft
} from "lucide-react";

export default function Pricing() {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: "Starter",
      description: "Perfect for small farms getting started with smart agriculture",
      monthlyPrice: 45000,
      annualPrice: 450000,
      features: [
        "Up to 2 hectares monitoring",
        "Basic soil monitoring",
        "5 animal tracking",
        "Email support",
        "Mobile app access",
        "Basic market listings"
      ],
      color: "border-gray-200",
      buttonClass: "bg-gray-600 hover:bg-gray-700",
      popular: false
    },
    {
      name: "Professional",
      description: "Comprehensive solution for serious farmers and cooperatives",
      monthlyPrice: 180000,
      annualPrice: 1800000,
      features: [
        "Up to 10 hectares monitoring",
        "Advanced soil monitoring with AI",
        "Unlimited animal tracking",
        "24/7 priority support",
        "Advanced analytics",
        "Premium market features",
        "Irrigation automation",
        "Weather forecasting",
        "Veterinary consultation"
      ],
      color: "border-green-500 ring-2 ring-green-500",
      buttonClass: "bg-green-600 hover:bg-green-700",
      popular: true
    },
    {
      name: "Enterprise",
      description: "Custom solutions for large farms and agricultural organizations",
      monthlyPrice: 500000,
      annualPrice: 5000000,
      features: [
        "Unlimited hectares monitoring",
        "Full AI-powered analytics",
        "Unlimited everything",
        "Dedicated support manager",
        "Custom integrations",
        "White-label options",
        "Advanced reporting",
        "API access",
        "On-site training",
        "Custom development"
      ],
      color: "border-blue-500",
      buttonClass: "bg-blue-600 hover:bg-blue-700",
      popular: false
    }
  ];

  const addOns = [
    {
      name: "Additional IoT Sensors",
      price: 25000,
      description: "Extra soil sensors for expanded monitoring coverage"
    },
    {
      name: "Veterinary Consultation",
      price: 15000,
      description: "Monthly video consultations with certified veterinarians"
    },
    {
      name: "Advanced Weather Station",
      price: 35000,
      description: "Comprehensive weather monitoring and forecasting"
    },
    {
      name: "Drone Surveillance",
      price: 50000,
      description: "Monthly aerial monitoring and crop health analysis"
    }
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/welcome">
              <button className="flex items-center space-x-2 group">
                <ArrowLeft className="h-5 w-5 text-gray-600 group-hover:text-green-700 transition-colors" />
                <div className="flex items-center space-x-2">
                  <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
                    <Sprout className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                    AgroSet
                  </span>
                </div>
              </button>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="hover:bg-green-50 hover:border-green-300">
                  Login
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-200">
            <Star className="h-3 w-3 mr-1" />
            Transparent & Affordable Pricing
          </Badge>
          <h1 className="text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
              Choose Your Plan
            </span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-8">
            Simple, transparent pricing designed for Ugandan farmers. All plans include core features 
            with no hidden fees. Start your free 30-day trial today.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-12">
            <span className={`text-sm ${!isAnnual ? 'font-semibold text-green-700' : 'text-gray-600'}`}>
              Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isAnnual ? 'bg-green-600' : 'bg-gray-200'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isAnnual ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-sm ${isAnnual ? 'font-semibold text-green-700' : 'text-gray-600'}`}>
              Annual
            </span>
            {isAnnual && (
              <Badge className="bg-green-100 text-green-800 text-xs">
                Save 17%
              </Badge>
            )}
          </div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <Card key={index} className={`agro-card relative ${plan.color} ${plan.popular ? 'scale-105 shadow-2xl' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-green-600 text-white px-4 py-1">
                      <Star className="h-3 w-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-6">
                  <CardTitle className="text-2xl font-bold mb-2">{plan.name}</CardTitle>
                  <p className="text-gray-600 text-sm mb-4">{plan.description}</p>
                  
                  <div className="space-y-2">
                    <div className="text-4xl font-bold text-gray-900">
                      {formatPrice(isAnnual ? Math.floor(plan.annualPrice / 12) : plan.monthlyPrice)}
                      <span className="text-lg font-normal text-gray-600">/month</span>
                    </div>
                    {isAnnual && (
                      <div className="text-sm text-gray-500">
                        {formatPrice(plan.annualPrice)} billed annually
                      </div>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link href="/login">
                    <Button className={`w-full ${plan.buttonClass} h-11`}>
                      {plan.name === "Enterprise" ? "Contact Sales" : "Start Free Trial"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  
                  <p className="text-xs text-gray-500 text-center">
                    30-day free trial • No credit card required
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Add-ons Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Optional Add-ons</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Enhance your AgroSet experience with these specialized services
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {addOns.map((addon, index) => (
              <Card key={index} className="agro-card">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{addon.name}</h3>
                      <p className="text-sm text-gray-600">{addon.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-700">
                        {formatPrice(addon.price)}
                      </div>
                      <div className="text-sm text-gray-500">/month</div>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full hover:bg-green-50 hover:border-green-300">
                    Add to Plan
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-6">
            <Card className="agro-card">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-2">What's included in the free trial?</h3>
                <p className="text-gray-600">
                  Your 30-day free trial includes full access to all features of your chosen plan. 
                  No credit card required, and you can cancel anytime.
                </p>
              </CardContent>
            </Card>

            <Card className="agro-card">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Can I change plans later?</h3>
                <p className="text-gray-600">
                  Yes, you can upgrade or downgrade your plan at any time. Changes take effect 
                  immediately, and we'll prorate the billing accordingly.
                </p>
              </CardContent>
            </Card>

            <Card className="agro-card">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-2">What payment methods do you accept?</h3>
                <p className="text-gray-600">
                  We accept Mobile Money (MTN, Airtel), bank transfers, and credit/debit cards. 
                  All payments are processed securely with bank-level encryption.
                </p>
              </CardContent>
            </Card>

            <Card className="agro-card">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Is there support for cooperatives?</h3>
                <p className="text-gray-600">
                  Yes! We offer special pricing for farmer cooperatives and groups. 
                  Contact our sales team for custom enterprise solutions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-green-600 to-emerald-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Farm?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Join thousands of Ugandan farmers already using AgroSet to increase yields and profits.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-white text-green-700 hover:bg-gray-50 text-lg px-8 py-3">
                Start Your Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg px-8 py-3 border-white text-white hover:bg-white/10"
            >
              Contact Sales
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}