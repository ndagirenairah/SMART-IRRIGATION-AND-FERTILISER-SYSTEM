import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Store, 
  Plus, 
  Search, 
  Filter,
  MapPin,
  TrendingUp,
  TrendingDown,
  Package,
  Eye,
  Edit,
  Trash2,
  Phone,
  Mail,
  ExternalLink,
  Calendar,
  Weight,
  DollarSign
} from "lucide-react";
import Header from "@/components/header";
import MobileNav from "@/components/mobile-nav";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertMarketListingSchema, type MarketListing, type MarketPrice } from "@shared/schema";

const createListingSchema = insertMarketListingSchema.extend({
  sellerId: z.number().default(1),
  sellerName: z.string().min(1, "Seller name is required"),
  sellerPhone: z.string().min(1, "Phone number is required"),
  sellerEmail: z.string().email("Valid email is required"),
  // Enhanced fields for better product description
  breed: z.string().optional(),
  age: z.string().optional(),
  gender: z.string().optional(),
  weight: z.string().optional(),
  healthStatus: z.string().optional(),
  vaccinations: z.string().optional(),
  harvestDate: z.string().optional(),
  organic: z.boolean().optional(),
  grade: z.string().optional(),
  storage: z.string().optional(),
});

type CreateListingData = z.infer<typeof createListingSchema>;

// Product Details Dialog Component
function ProductDetailsDialog({ product, isOpen, onClose }: {
  product: MarketListing;
  isOpen: boolean;
  onClose: () => void;
}) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{product.productName}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Product Photos */}
          <div className="space-y-4">
            <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
              {product.photos && product.photos.length > 0 ? (
                <img 
                  src={product.photos[0]} 
                  alt={product.productName}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.src = `https://via.placeholder.com/400x400/e5e7eb/6b7280?text=${encodeURIComponent(product.productName)}`;
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-400">
                  <Package className="h-16 w-16" />
                </div>
              )}
            </div>
            
            {/* Additional Photos */}
            {product.photos && product.photos.length > 1 && (
              <div className="grid grid-cols-3 gap-2">
                {product.photos.slice(1).map((photo, index) => (
                  <div key={index} className="aspect-square bg-gray-100 rounded overflow-hidden">
                    <img 
                      src={photo} 
                      alt={`${product.productName} ${index + 2}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = `https://via.placeholder.com/200x200/e5e7eb/6b7280?text=Photo`;
                      }}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            {/* Price and Availability */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-3xl font-bold text-green-600">
                    USh {parseFloat(product.pricePerUnit).toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-600">per {product.unit}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">
                  {product.status}
                </Badge>
              </div>
              
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Weight className="h-4 w-4" />
                <span>{parseFloat(product.quantity).toLocaleString()} {product.unit} available</span>
              </div>
            </div>

            <Separator />

            {/* Product Information */}
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Description</h3>
                <p className="text-gray-700">{product.description}</p>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Category</h3>
                <Badge variant="outline">{product.category}</Badge>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Location</h3>
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="h-4 w-4" />
                  <span>{product.location}</span>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Listed</h3>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>{new Date(product.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Seller Information */}
            <div className="space-y-4">
              <h3 className="font-semibold">Seller Information</h3>
              
              <div className="space-y-3">
                {product.sellerName && (
                  <div className="flex items-center space-x-3">
                    <div className="h-4 w-4 flex items-center justify-center">
                      <span className="text-sm font-medium">👤</span>
                    </div>
                    <span className="text-sm font-medium">{product.sellerName}</span>
                  </div>
                )}
                
                {product.sellerPhone && (
                  <div className="flex items-center space-x-3">
                    <Phone className="h-4 w-4 text-green-600" />
                    <span className="text-sm">{product.sellerPhone}</span>
                    <Button size="sm" variant="outline" onClick={() => window.open(`tel:${product.sellerPhone}`)}>
                      Call
                    </Button>
                  </div>
                )}
                
                {product.sellerEmail && (
                  <div className="flex items-center space-x-3">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">{product.sellerEmail}</span>
                    <Button size="sm" variant="outline" onClick={() => window.open(`mailto:${product.sellerEmail}`)}>
                      Email
                    </Button>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Google Maps Integration */}
            {product.latitude && product.longitude && (
              <div className="space-y-4">
                <h3 className="font-semibold">Location on Map</h3>
                <div className="aspect-video rounded-lg overflow-hidden border">
                  <iframe
                    width="100%"
                    height="100%"
                    src={`https://www.google.com/maps/embed/v1/place?key=&q=${product.latitude},${product.longitude}&zoom=15`}
                    title={`Location of ${product.productName}`}
                    className="border-0"
                    onError={() => {
                      // Fallback if Google Maps fails to load
                      console.log("Google Maps failed to load");
                    }}
                  />
                </div>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => window.open(`https://www.google.com/maps?q=${product.latitude},${product.longitude}`, '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open in Google Maps
                </Button>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-2 pt-4">
              <Button className="flex-1 bg-green-600 hover:bg-green-700">
                <Phone className="h-4 w-4 mr-2" />
                Contact Seller
              </Button>
              <Button variant="outline" className="flex-1">
                <Package className="h-4 w-4 mr-2" />
                Make Offer
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function AgroMarket() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<MarketListing | null>(null);
  const [editingListing, setEditingListing] = useState<MarketListing | null>(null);
  const { toast } = useToast();

  const { data: marketListings = [], isLoading: loadingListings } = useQuery<MarketListing[]>({
    queryKey: ["/api/market/listings"],
  });

  const { data: myListings = [] } = useQuery<MarketListing[]>({
    queryKey: ["/api/market/my-listings"],
  });

  const { data: marketPrices = [] } = useQuery<MarketPrice[]>({
    queryKey: ["/api/market/prices"],
  });

  const form = useForm<CreateListingData>({
    resolver: zodResolver(createListingSchema),
    defaultValues: {
      sellerId: 1,
      productName: "",
      category: "",
      quantity: "",
      unit: "kg",
      pricePerUnit: "",
      location: "Kampala, Uganda",
      description: "",
      sellerName: "",
      sellerPhone: "",
      sellerEmail: "",
      status: "active",
    },
  });

  const createListingMutation = useMutation({
    mutationFn: async (data: CreateListingData) => {
      return apiRequest("POST", "/api/market/listings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/market"] });
      setShowCreateDialog(false);
      form.reset();
      toast({
        title: "Listing Created",
        description: "Your produce has been listed in the marketplace.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create listing.",
        variant: "destructive",
      });
    },
  });

  const filteredListings = marketListings.filter(listing => {
    const matchesCategory = selectedCategory === "all" || listing.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = !searchQuery || 
      listing.productName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      listing.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const categories = ["all", "vegetables", "fruits", "grains", "dairy", "meat", "livestock", "poultry"];

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX'
    }).format(parseFloat(price));
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const onSubmit = (data: CreateListingData) => {
    if (editingListing) {
      updateListingMutation.mutate({ id: editingListing.id, data });
    } else {
      createListingMutation.mutate(data);
    }
  };

  const updateListingMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<CreateListingData> }) => {
      return apiRequest("PUT", `/api/market/listings/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/market"] });
      setEditingListing(null);
      setShowCreateDialog(false);
      form.reset();
      toast({
        title: "Success",
        description: "Product listing updated successfully",
      });
    },
    onError: (error) => {
      console.error("Error updating listing:", error);
      toast({
        title: "Error",
        description: "Failed to update listing. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteListingMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/market/listings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/market"] });
      toast({
        title: "Success",
        description: "Product listing deleted successfully",
      });
    },
    onError: (error) => {
      console.error("Error deleting listing:", error);
      toast({
        title: "Error",
        description: "Failed to delete listing. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEditListing = (listing: MarketListing) => {
    setEditingListing(listing);
    form.reset({
      sellerId: listing.sellerId,
      productName: listing.productName,
      category: listing.category,
      quantity: listing.quantity,
      unit: listing.unit,
      pricePerUnit: listing.pricePerUnit,
      location: listing.location,
      description: listing.description || "",
      sellerName: listing.sellerName || "",
      sellerPhone: listing.sellerPhone || "",
      sellerEmail: listing.sellerEmail || "",
      status: listing.status,
    });
    setShowCreateDialog(true);
  };

  const handleDeleteListing = (id: number) => {
    if (window.confirm("Are you sure you want to delete this listing?")) {
      deleteListingMutation.mutate(id);
    }
  };

  if (loadingListings) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </main>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 pb-20 md:pb-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                AgroMarket
              </h1>
              <p className="text-gray-600 mt-2">Buy and sell agricultural produce in Uganda</p>
            </div>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="agro-button-primary">
                  <Plus className="h-4 w-4 mr-2" />
                  List Produce
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto agro-card">
                <DialogHeader>
                  <DialogTitle>
                    {editingListing ? "Edit Listing" : "Create New Listing"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingListing ? "Update your product listing details" : "Add a new product to the marketplace"}
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="productName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Organic Tomatoes" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Vegetables">Vegetables</SelectItem>
                              <SelectItem value="Fruits">Fruits</SelectItem>
                              <SelectItem value="Grains">Grains</SelectItem>
                              <SelectItem value="Dairy">Dairy</SelectItem>
                              <SelectItem value="Meat">Meat</SelectItem>
                              <SelectItem value="Livestock">Livestock</SelectItem>
                              <SelectItem value="Poultry">Poultry</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Conditional Fields for Vegetables */}
                    {form.watch("category") === "Vegetables" && (
                      <div className="border rounded-lg p-4 bg-green-50 space-y-4">
                        <h5 className="font-medium text-green-900">🥬 Vegetable Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="harvestDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Harvest Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="grade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Grade/Quality</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select grade" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Premium">Premium</SelectItem>
                                    <SelectItem value="Grade A">Grade A</SelectItem>
                                    <SelectItem value="Grade B">Grade B</SelectItem>
                                    <SelectItem value="Standard">Standard</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="organic"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                                <div className="space-y-0.5">
                                  <FormLabel>Organic Certification</FormLabel>
                                </div>
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Storage Condition</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select storage" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Fresh">Fresh</SelectItem>
                                    <SelectItem value="Cold Storage">Cold Storage</SelectItem>
                                    <SelectItem value="Room Temperature">Room Temperature</SelectItem>
                                    <SelectItem value="Refrigerated">Refrigerated</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="breed"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Variety/Cultivar</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Roma Tomatoes, Purple Top Turnips" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Fruits */}
                    {form.watch("category") === "Fruits" && (
                      <div className="border rounded-lg p-4 bg-orange-50 space-y-4">
                        <h5 className="font-medium text-orange-900">🍎 Fruit Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="harvestDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Harvest Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="grade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Ripeness Level</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select ripeness" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Tree Ripe">Tree Ripe</SelectItem>
                                    <SelectItem value="Nearly Ripe">Nearly Ripe</SelectItem>
                                    <SelectItem value="Firm Ripe">Firm Ripe</SelectItem>
                                    <SelectItem value="Green">Green (for ripening)</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="organic"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                                <div className="space-y-0.5">
                                  <FormLabel>Organic Certification</FormLabel>
                                </div>
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Storage Condition</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select storage" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Fresh">Fresh</SelectItem>
                                    <SelectItem value="Cold Storage">Cold Storage</SelectItem>
                                    <SelectItem value="Dried">Dried</SelectItem>
                                    <SelectItem value="Frozen">Frozen</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="breed"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Variety</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Red Delicious Apples, Valencia Oranges" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Grains */}
                    {form.watch("category") === "Grains" && (
                      <div className="border rounded-lg p-4 bg-yellow-50 space-y-4">
                        <h5 className="font-medium text-yellow-900">🌾 Grain Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="harvestDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Harvest Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="grade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Grain Grade</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select grade" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Grade 1">Grade 1 (Premium)</SelectItem>
                                    <SelectItem value="Grade 2">Grade 2 (Good)</SelectItem>
                                    <SelectItem value="Grade 3">Grade 3 (Fair)</SelectItem>
                                    <SelectItem value="Feed Grade">Feed Grade</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Moisture Content (%)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 12.5" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Processing Status</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select processing" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Raw">Raw/Unprocessed</SelectItem>
                                    <SelectItem value="Cleaned">Cleaned</SelectItem>
                                    <SelectItem value="Milled">Milled</SelectItem>
                                    <SelectItem value="Processed">Processed</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="breed"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Grain Type</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., White Maize, Red Sorghum, Short Grain Rice" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Dairy */}
                    {form.watch("category") === "Dairy" && (
                      <div className="border rounded-lg p-4 bg-blue-50 space-y-4">
                        <h5 className="font-medium text-blue-900">🥛 Dairy Product Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="harvestDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Production Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="grade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Fat Content</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select fat content" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Whole">Whole Milk (3.5%)</SelectItem>
                                    <SelectItem value="Low Fat">Low Fat (1-2%)</SelectItem>
                                    <SelectItem value="Skim">Skim (0%)</SelectItem>
                                    <SelectItem value="High Fat">High Fat (&gt;4%)</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="organic"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                                <div className="space-y-0.5">
                                  <FormLabel>Pasteurized</FormLabel>
                                </div>
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Storage Requirement</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select storage" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Refrigerated">Refrigerated (4°C)</SelectItem>
                                    <SelectItem value="Frozen">Frozen</SelectItem>
                                    <SelectItem value="Room Temperature">Room Temperature</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="breed"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Source Animal</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Holstein Cow, Friesian, Local Zebu" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Meat */}
                    {form.watch("category") === "Meat" && (
                      <div className="border rounded-lg p-4 bg-red-50 space-y-4">
                        <h5 className="font-medium text-red-900">🥩 Meat Product Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="harvestDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Processing Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="grade"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Cut Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select cut" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Whole Carcass">Whole Carcass</SelectItem>
                                    <SelectItem value="Half Carcass">Half Carcass</SelectItem>
                                    <SelectItem value="Quarter">Quarter</SelectItem>
                                    <SelectItem value="Prime Cuts">Prime Cuts</SelectItem>
                                    <SelectItem value="Mixed Cuts">Mixed Cuts</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Carcass Weight (kg)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 180" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="storage"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Processing Status</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select status" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Fresh">Fresh (Chilled)</SelectItem>
                                    <SelectItem value="Frozen">Frozen</SelectItem>
                                    <SelectItem value="Cured">Cured/Smoked</SelectItem>
                                    <SelectItem value="Processed">Processed</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="breed"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Animal Breed</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Ankole Cattle, Local Goat, Rhode Island Red" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="healthStatus"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Health Certification</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select certification" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Veterinary Inspected">Veterinary Inspected</SelectItem>
                                  <SelectItem value="Government Certified">Government Certified</SelectItem>
                                  <SelectItem value="Halal Certified">Halal Certified</SelectItem>
                                  <SelectItem value="Organic Certified">Organic Certified</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Livestock */}
                    {form.watch("category") === "Livestock" && (
                      <div className="border rounded-lg p-4 bg-amber-50 space-y-4">
                        <h5 className="font-medium text-amber-900">🐄 Livestock Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="breed"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Breed</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Ankole, Holstein, Friesian" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="age"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Age</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 2 years 6 months" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="gender"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Gender</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select gender" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Bull">Bull</SelectItem>
                                    <SelectItem value="Cow">Cow</SelectItem>
                                    <SelectItem value="Heifer">Heifer</SelectItem>
                                    <SelectItem value="Steer">Steer</SelectItem>
                                    <SelectItem value="Calf">Calf</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Weight (kg)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 450" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="healthStatus"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Health Status</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select health status" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Excellent">Excellent</SelectItem>
                                  <SelectItem value="Good">Good</SelectItem>
                                  <SelectItem value="Fair">Fair</SelectItem>
                                  <SelectItem value="Pregnant">Pregnant</SelectItem>
                                  <SelectItem value="Lactating">Lactating</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="vaccinations"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Vaccination History</FormLabel>
                              <FormControl>
                                <Textarea placeholder="List recent vaccinations: FMD (Jan 2024), Anthrax (Dec 2023)..." {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    {/* Conditional Fields for Poultry */}
                    {form.watch("category") === "Poultry" && (
                      <div className="border rounded-lg p-4 bg-yellow-50 space-y-4">
                        <h5 className="font-medium text-yellow-900">🐔 Poultry Details</h5>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="breed"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Breed</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., Rhode Island Red, Kuroiler, Broiler" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="age"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Age</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 8 weeks, 6 months" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="gender"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Type</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select type" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="Layers">Layers (Hens)</SelectItem>
                                    <SelectItem value="Broilers">Broilers</SelectItem>
                                    <SelectItem value="Roosters">Roosters</SelectItem>
                                    <SelectItem value="Chicks">Chicks</SelectItem>
                                    <SelectItem value="Mixed">Mixed Flock</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="weight"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Average Weight (kg)</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g., 2.5" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name="healthStatus"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Health & Production Status</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select status" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Excellent Layer">Excellent Layer</SelectItem>
                                  <SelectItem value="Good Layer">Good Layer</SelectItem>
                                  <SelectItem value="Ready for Market">Ready for Market</SelectItem>
                                  <SelectItem value="Breeding Stock">Breeding Stock</SelectItem>
                                  <SelectItem value="Growing">Growing</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="vaccinations"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Vaccination & Care</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Newcastle Disease (monthly), Deworming (quarterly), Special feed program..." {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="quantity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantity</FormLabel>
                            <FormControl>
                              <Input placeholder="100" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="unit"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Unit</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="kg">kg</SelectItem>
                                <SelectItem value="tons">tons</SelectItem>
                                <SelectItem value="pieces">pieces</SelectItem>
                                <SelectItem value="liters">liters</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="pricePerUnit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price per Unit (UGX)</FormLabel>
                          <FormControl>
                            <Input placeholder="15000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="Kampala, Uganda" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => {
                        const category = form.watch("category");
                        const getPlaceholder = () => {
                          if (category === "Livestock" || category === "Poultry") {
                            return "Describe the animal's condition, behavior, and any special characteristics...";
                          } else if (category === "Dairy") {
                            return "Fresh dairy product details, milk production, quality standards...";
                          } else {
                            return "Fresh organic produce, growing conditions, quality details...";
                          }
                        };

                        return (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea placeholder={getPlaceholder()} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        );
                      }}
                    />

                    <div className="border-t pt-4">
                      <h4 className="font-medium text-gray-900 mb-3">Seller Information</h4>
                      <div className="space-y-4">
                        <FormField
                          control={form.control}
                          name="sellerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="sellerPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="+256 701 234 567" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="sellerEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address</FormLabel>
                              <FormControl>
                                <Input placeholder="john@example.com" type="email" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-green-700 hover:bg-green-800"
                      disabled={createListingMutation.isPending || updateListingMutation.isPending}
                    >
                      {createListingMutation.isPending || updateListingMutation.isPending 
                        ? (editingListing ? "Updating..." : "Creating...") 
                        : (editingListing ? "Update Listing" : "Create Listing")}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="marketplace" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
            <TabsTrigger value="my-listings">My Listings</TabsTrigger>
            <TabsTrigger value="price-trends">Price Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace" className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search products or locations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full sm:w-48">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category === "all" ? "All Categories" : category.charAt(0).toUpperCase() + category.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Listings Grid */}
            {filteredListings.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredListings.map((listing) => (
                  <Card key={listing.id} className="agro-card hover:shadow-xl transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{listing.productName}</CardTitle>
                          <p className="text-sm text-gray-500">{listing.category}</p>
                        </div>
                        <Badge className="bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 border border-green-200">
                          {listing.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-green-600">
                            {formatPrice(listing.pricePerUnit)}
                          </span>
                          <span className="text-gray-500">per {listing.unit}</span>
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600">
                          <Package className="h-4 w-4 mr-1" />
                          {listing.quantity} {listing.unit} available
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-4 w-4 mr-1" />
                          {listing.location}
                        </div>
                        
                        {listing.description && (
                          <p className="text-sm text-gray-600 line-clamp-2">
                            {listing.description}
                          </p>
                        )}
                        
                        <div className="flex items-center justify-between text-xs text-gray-400">
                          <span>Listed {formatDate(listing.createdAt)}</span>
                        </div>
                        
                        <Button 
                          className="w-full bg-blue-700 hover:bg-blue-800"
                          onClick={() => setSelectedProduct(listing)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Store className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Listings Found</h3>
                  <p className="text-gray-500">
                    {searchQuery || selectedCategory !== "all" 
                      ? "Try adjusting your search criteria" 
                      : "Be the first to list produce in the marketplace"}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="my-listings" className="space-y-6">
            {myListings.length > 0 ? (
              <div className="space-y-4">
                {myListings.map((listing) => (
                  <Card key={listing.id}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-4">
                            <div>
                              <h3 className="text-lg font-semibold text-gray-900">
                                {listing.productName}
                              </h3>
                              <p className="text-sm text-gray-500">{listing.category}</p>
                            </div>
                            <Badge 
                              className={
                                listing.status === "active" 
                                  ? "bg-green-100 text-green-800"
                                  : listing.status === "sold"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-gray-100 text-gray-800"
                              }
                            >
                              {listing.status}
                            </Badge>
                          </div>
                          
                          <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Price:</span>
                              <p className="font-medium">{formatPrice(listing.pricePerUnit)}/{listing.unit}</p>
                            </div>
                            <div>
                              <span className="text-gray-500">Quantity:</span>
                              <p className="font-medium">{listing.quantity} {listing.unit}</p>
                            </div>
                            <div>
                              <span className="text-gray-500">Location:</span>
                              <p className="font-medium">{listing.location}</p>
                            </div>
                            <div>
                              <span className="text-gray-500">Listed:</span>
                              <p className="font-medium">{formatDate(listing.createdAt)}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleEditListing(listing)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDeleteListing(listing.id)}
                            disabled={deleteListingMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Package className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Listings Yet</h3>
                  <p className="text-gray-500 mb-4">
                    Start selling your produce by creating your first listing
                  </p>
                  <Button 
                    onClick={() => setShowCreateDialog(true)}
                    className="bg-green-700 hover:bg-green-800"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Listing
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="price-trends" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Market Price Trends</CardTitle>
                <p className="text-sm text-gray-600">Compare prices across different markets</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Sample price trend data */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Card className="border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">Tomatoes</h4>
                          <TrendingUp className="h-4 w-4 text-green-600" />
                        </div>
                        <div className="space-y-1">
                          <p className="text-2xl font-bold text-gray-900">UGX 16,800/kg</p>
                          <p className="text-sm text-green-600">↑ 15% this week</p>
                          <p className="text-xs text-gray-500">Kampala Market</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">Corn</h4>
                          <div className="h-4 w-4 text-gray-400">→</div>
                        </div>
                        <div className="space-y-1">
                          <p className="text-2xl font-bold text-gray-900">UGX 10,400/kg</p>
                          <p className="text-sm text-gray-500">→ 0% this week</p>
                          <p className="text-xs text-gray-500">Regional Market</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">Wheat</h4>
                          <TrendingDown className="h-4 w-4 text-red-600" />
                        </div>
                        <div className="space-y-1">
                          <p className="text-2xl font-bold text-gray-900">UGX 7,200/kg</p>
                          <p className="text-sm text-red-600">↓ 8% this week</p>
                          <p className="text-xs text-gray-500">Wholesale Market</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="mt-8">
                    <h4 className="font-medium text-gray-900 mb-4">Price Recommendations</h4>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <div className="h-5 w-5 text-blue-600 mt-0.5 flex items-center justify-center text-xs font-bold">UGX</div>
                        <div>
                          <h5 className="font-medium text-blue-900">Optimal Pricing Suggestion</h5>
                          <p className="text-sm text-blue-700 mt-1">
                            Based on current market trends, consider pricing tomatoes at UGX 15,600-17,200/kg for competitive positioning. 
                            Demand is high due to seasonal factors.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <MobileNav />
      
      {/* Product Details Dialog */}
      {selectedProduct && (
        <ProductDetailsDialog
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
