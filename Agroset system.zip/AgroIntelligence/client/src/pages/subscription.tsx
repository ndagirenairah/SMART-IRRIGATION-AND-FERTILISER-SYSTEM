import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Check, Crown, Star, Zap } from "lucide-react";
import Header from "@/components/header";
import MobileNav from "@/components/mobile-nav";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  duration: string;
  features: string[];
  recommended?: boolean;
  icon: React.ComponentType<{ className?: string }>;
}

const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: "basic",
    name: "Basic Plan",
    price: 5000,
    duration: "month",
    icon: Star,
    features: [
      "Basic soil monitoring",
      "Weekly AI recommendations",
      "5 animal records",
      "Basic marketplace access",
      "Email support"
    ]
  },
  {
    id: "premium",
    name: "Premium Plan",
    price: 10000,
    duration: "month",
    icon: Crown,
    recommended: true,
    features: [
      "Advanced soil monitoring",
      "Real-time AI recommendations",
      "Unlimited animal records",
      "Priority marketplace listings",
      "Smart irrigation controls",
      "Google Maps integration",
      "Phone & email support",
      "Export data reports"
    ]
  },
  {
    id: "enterprise",
    name: "Enterprise Plan",
    price: 20000,
    duration: "month",
    icon: Zap,
    features: [
      "All premium features",
      "Custom field monitoring",
      "Advanced analytics",
      "API access",
      "Multi-farm management",
      "Priority AI processing",
      "24/7 dedicated support",
      "Custom integrations"
    ]
  }
];

export default function Subscription() {
  const [isLoading, setIsLoading] = useState<string | null>(null);
  const { toast } = useToast();

  // Get current subscription
  const { data: currentSubscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/subscription"],
    enabled: true
  });

  // Get payment history
  const { data: payments } = useQuery({
    queryKey: ["/api/payments"],
    enabled: true
  });

  const createSubscriptionMutation = useMutation({
    mutationFn: async (planType: string) => {
      const response = await apiRequest("POST", "/api/payments/subscription", {
        planType
      });
      return response.json();
    },
    onSuccess: (data) => {
      // Redirect directly to Pesapal payment page for immediate payment
      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
      } else {
        toast({
          title: "Payment Error",
          description: "Unable to redirect to payment page. Please try again.",
          variant: "destructive"
        });
        setIsLoading(null);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Payment Error",
        description: error.message || "Failed to create subscription payment",
        variant: "destructive"
      });
      setIsLoading(null);
    }
  });

  const handleSubscribe = async (planType: string) => {
    setIsLoading(planType);
    createSubscriptionMutation.mutate(planType);
  };

  const formatPrice = (price: number) => {
    return `USh ${price.toLocaleString()}`;
  };

  return (
    <>
      <Header />
      <MobileNav />
      
      <main className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 pt-16">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-4">
              Choose Your AgroSet Plan
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Unlock the full potential of smart agriculture with our comprehensive subscription plans
            </p>
          </div>

          {/* Current Subscription Status */}
          {currentSubscription && !subscriptionLoading && (
            <div className="mb-8">
              <Card className="max-w-md mx-auto border-green-200 bg-green-50">
                <CardHeader className="text-center">
                  <CardTitle className="text-green-800">Current Subscription</CardTitle>
                  <Badge className="w-fit mx-auto bg-green-100 text-green-800 border-green-300">
                    {currentSubscription.planType?.toUpperCase()} PLAN
                  </Badge>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-green-600">
                    Status: <span className="font-semibold">{currentSubscription.status}</span>
                  </p>
                  <p className="text-sm text-green-600 mt-2">
                    Valid until: {new Date(currentSubscription.endDate).toLocaleDateString()}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Subscription Plans */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {subscriptionPlans.map((plan) => {
              const IconComponent = plan.icon;
              const isCurrentPlan = currentSubscription?.planType === plan.id;
              
              return (
                <Card 
                  key={plan.id}
                  className={`relative transition-all duration-300 hover:shadow-lg border-2 ${
                    plan.recommended 
                      ? "border-green-400 shadow-green-100" 
                      : "border-gray-200 hover:border-green-300"
                  } ${isCurrentPlan ? "bg-green-50 border-green-500" : "bg-white"}`}
                >
                  {plan.recommended && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-green-600 text-white px-4 py-1">
                        Recommended
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4 p-3 rounded-full bg-green-100">
                      <IconComponent className="h-8 w-8 text-green-600" />
                    </div>
                    <CardTitle className="text-2xl text-gray-800">{plan.name}</CardTitle>
                    <CardDescription className="text-lg">
                      <span className="text-3xl font-bold text-green-600">
                        {formatPrice(plan.price)}
                      </span>
                      <span className="text-gray-500">/{plan.duration}</span>
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm">
                          <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>

                  <CardFooter>
                    {isCurrentPlan ? (
                      <Button disabled className="w-full bg-green-600">
                        Current Plan
                      </Button>
                    ) : (
                      <Button 
                        onClick={() => handleSubscribe(plan.id)}
                        disabled={isLoading === plan.id}
                        className={`w-full transition-colors ${
                          plan.recommended 
                            ? "bg-green-600 hover:bg-green-700 text-white" 
                            : "bg-white text-green-600 border border-green-600 hover:bg-green-50"
                        }`}
                      >
                        {isLoading === plan.id ? "Processing..." : "Subscribe Now"}
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })}
          </div>

          {/* Payment Methods */}
          <div className="max-w-4xl mx-auto mb-12">
            <Card className="border-gray-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-gray-800">Secure Payment Methods</CardTitle>
                <CardDescription>
                  We use Pesapal for secure, reliable payments in Uganda
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div className="p-4">
                    <div className="text-2xl mb-2">📱</div>
                    <h3 className="font-semibold mb-2">Mobile Money</h3>
                    <p className="text-sm text-gray-600">
                      MTN Mobile Money, Airtel Money, and other mobile wallets
                    </p>
                  </div>
                  <div className="p-4">
                    <div className="text-2xl mb-2">💳</div>
                    <h3 className="font-semibold mb-2">Credit/Debit Cards</h3>
                    <p className="text-sm text-gray-600">
                      Visa, Mastercard, and other international cards
                    </p>
                  </div>
                  <div className="p-4">
                    <div className="text-2xl mb-2">🏦</div>
                    <h3 className="font-semibold mb-2">Bank Transfer</h3>
                    <p className="text-sm text-gray-600">
                      Direct bank transfers and online banking
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment History */}
          {payments && payments.length > 0 && (
            <div className="max-w-4xl mx-auto">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Payment History</CardTitle>
                  <CardDescription>Your recent payments and transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {payments.slice(0, 5).map((payment: any, index: number) => (
                      <div key={index} className="flex justify-between items-center py-3 border-b">
                        <div>
                          <p className="font-medium">{payment.description}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(payment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatPrice(parseInt(payment.amount))}</p>
                          <Badge 
                            variant={payment.status === "COMPLETED" ? "default" : "secondary"}
                            className={
                              payment.status === "COMPLETED" 
                                ? "bg-green-100 text-green-800" 
                                : payment.status === "PENDING"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                            }
                          >
                            {payment.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </>
  );
}