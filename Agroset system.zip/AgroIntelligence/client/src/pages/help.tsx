import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Link } from "wouter";
import { 
  Sprout, 
  Search, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp,
  ArrowLeft,
  MessageCircle,
  Phone,
  Mail,
  BookOpen,
  Video,
  Users,
  AlertCircle,
  CheckCircle,
  Clock,
  ExternalLink
} from "lucide-react";

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");
  const [openItems, setOpenItems] = useState<Record<string, boolean>>({});

  const toggleItem = (id: string) => {
    setOpenItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const categories = [
    {
      id: "getting-started",
      name: "Getting Started",
      icon: CheckCircle,
      count: 12,
      description: "New to AgroSet? Start here"
    },
    {
      id: "agrosoil",
      name: "AgroSoil",
      icon: CheckCircle,
      count: 18,
      description: "Soil monitoring and analytics"
    },
    {
      id: "agromarket",
      name: "AgroMarket",
      icon: CheckCircle,
      count: 15,
      description: "Marketplace and trading"
    },
    {
      id: "agroanimal",
      name: "AgroAnimal",
      icon: CheckCircle,
      count: 10,
      description: "Livestock management"
    },
    {
      id: "account",
      name: "Account & Billing",
      icon: CheckCircle,
      count: 8,
      description: "Account settings and payments"
    },
    {
      id: "troubleshooting",
      name: "Troubleshooting",
      icon: AlertCircle,
      count: 20,
      description: "Common issues and fixes"
    }
  ];

  const popularArticles = [
    {
      title: "How to set up your first soil sensor",
      category: "AgroSoil",
      views: 5420,
      helpful: 89,
      updated: "2 days ago"
    },
    {
      title: "Understanding soil NPK readings",
      category: "AgroSoil",
      views: 4830,
      helpful: 92,
      updated: "1 week ago"
    },
    {
      title: "Creating your first market listing",
      category: "AgroMarket",
      views: 3920,
      helpful: 85,
      updated: "3 days ago"
    },
    {
      title: "Adding animals to your herd",
      category: "AgroAnimal",
      views: 3510,
      helpful: 88,
      updated: "5 days ago"
    },
    {
      title: "Mobile Money payment issues",
      category: "Account & Billing",
      views: 2890,
      helpful: 91,
      updated: "1 day ago"
    }
  ];

  const faqData = {
    "getting-started": [
      {
        id: "gs1",
        question: "What is AgroSet and how does it work?",
        answer: "AgroSet is a comprehensive 3-in-1 smart agriculture platform designed for Ugandan farmers. It combines AgroSoil (soil monitoring), AgroMarket (marketplace), and AgroAnimal (livestock management) to help you modernize your farming operations and increase productivity."
      },
      {
        id: "gs2",
        question: "How do I get started with AgroSet?",
        answer: "Start with our free 30-day trial. Sign up, choose your plan, and follow our setup wizard. We'll guide you through connecting your first devices and setting up your farm profile."
      },
      {
        id: "gs3",
        question: "Do I need special equipment to use AgroSet?",
        answer: "AgroSet works with any smartphone or computer. For advanced features like soil monitoring, you'll need our IoT sensors, which we can deliver and install for you."
      }
    ],
    "agrosoil": [
      {
        id: "as1",
        question: "How accurate are the soil readings?",
        answer: "Our 7-in-1 NPK sensors provide laboratory-grade accuracy with ±2% precision for nitrogen, phosphorus, and potassium levels. pH readings are accurate to ±0.1 units."
      },
      {
        id: "as2",
        question: "How often should I check my soil readings?",
        answer: "Sensors automatically collect data every 30 minutes. For most crops, checking daily trends is sufficient, but you can monitor real-time data during critical growing periods."
      },
      {
        id: "as3",
        question: "What do I do if my sensor stops working?",
        answer: "First, check the power connection and WiFi signal. If the issue persists, our technical team provides free replacement within 24 hours for active subscribers."
      }
    ],
    "agromarket": [
      {
        id: "am1",
        question: "How do I set competitive prices for my produce?",
        answer: "AgroMarket shows real-time market prices in your area. Our AI suggests optimal pricing based on quality, season, and local demand patterns."
      },
      {
        id: "am2",
        question: "How does payment work for sales?",
        answer: "We support Mobile Money (MTN, Airtel), bank transfers, and cash on delivery. Payments are secured through our platform with buyer protection."
      },
      {
        id: "am3",
        question: "Can I sell to buyers outside my region?",
        answer: "Yes! AgroMarket connects you with buyers across Uganda. We partner with logistics companies to help arrange transportation for larger orders."
      }
    ],
    "agroanimal": [
      {
        id: "aa1",
        question: "How do electronic ear tags work?",
        answer: "Our RFID ear tags store unique animal IDs that sync with your AgroAnimal account. Simply scan with your phone to access complete health and breeding records."
      },
      {
        id: "aa2",
        question: "Can I track animals without ear tags?",
        answer: "Yes, you can manually enter animal data and use photos for identification. However, ear tags provide the most accurate and efficient tracking."
      },
      {
        id: "aa3",
        question: "What health records should I maintain?",
        answer: "Track vaccinations, treatments, breeding dates, weight changes, and general health observations. Our system reminds you of upcoming vaccinations and checkups."
      }
    ],
    "account": [
      {
        id: "ab1",
        question: "How do I change my subscription plan?",
        answer: "Go to Settings > Billing and select 'Change Plan'. Upgrades take effect immediately, downgrades at the next billing cycle."
      },
      {
        id: "ab2",
        question: "What payment methods do you accept?",
        answer: "We accept Mobile Money (MTN, Airtel), Visa/Mastercard, and bank transfers. All payments are processed securely with bank-level encryption."
      },
      {
        id: "ab3",
        question: "Can I get a refund if I'm not satisfied?",
        answer: "Yes, we offer a 30-day money-back guarantee. Contact our support team within 30 days of purchase for a full refund."
      }
    ],
    "troubleshooting": [
      {
        id: "ts1",
        question: "Why isn't my data syncing?",
        answer: "Check your internet connection and ensure your devices have the latest firmware. Data syncs every 5 minutes when connected to WiFi."
      },
      {
        id: "ts2",
        question: "I forgot my password, how do I reset it?",
        answer: "Click 'Forgot Password' on the login page. We'll send a reset link to your registered email address. Check your spam folder if you don't see it."
      },
      {
        id: "ts3",
        question: "The mobile app keeps crashing, what should I do?",
        answer: "Try clearing the app cache, restart your phone, and ensure you have the latest app version. If issues persist, contact our technical support team."
      }
    ]
  };

  const supportOptions = [
    {
      icon: MessageCircle,
      title: "Live Chat",
      description: "Chat with our support team",
      availability: "Mon-Fri, 9AM-5PM",
      responseTime: "< 5 minutes",
      action: "Start Chat"
    },
    {
      icon: Phone,
      title: "Phone Support",
      description: "Call us for immediate help",
      availability: "Mon-Fri, 8AM-6PM",
      responseTime: "Immediate",
      action: "Call Now"
    },
    {
      icon: Mail,
      title: "Email Support",
      description: "Send detailed inquiries",
      availability: "24/7",
      responseTime: "< 24 hours",
      action: "Send Email"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/welcome">
              <button className="flex items-center space-x-2 group">
                <ArrowLeft className="h-5 w-5 text-gray-600 group-hover:text-green-700 transition-colors" />
                <div className="flex items-center space-x-2">
                  <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
                    <Sprout className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                    AgroSet
                  </span>
                </div>
              </button>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="hover:bg-green-50 hover:border-green-300">
                  Login
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
              <HelpCircle className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
              Help Center
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Find answers to your questions and get the most out of AgroSet
          </p>

          {/* Search */}
          <div className="max-w-lg mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search for help articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="px-4 sm:px-6 lg:px-8 pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar - Categories */}
            <div className="lg:col-span-1">
              <Card className="agro-card sticky top-4">
                <CardHeader>
                  <CardTitle className="text-lg">Browse by Category</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      className="w-full text-left p-3 rounded-lg hover:bg-green-50 transition-colors group"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <category.icon className="h-5 w-5 text-green-600" />
                          <div>
                            <div className="font-medium text-gray-900 group-hover:text-green-700">
                              {category.name}
                            </div>
                            <div className="text-xs text-gray-500">{category.description}</div>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {category.count}
                        </Badge>
                      </div>
                    </button>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-8">
              {/* Popular Articles */}
              <Card className="agro-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5" />
                    <span>Popular Articles</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {popularArticles.map((article, index) => (
                    <div key={index} className="p-4 border rounded-lg hover:bg-green-50 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 hover:text-green-700 mb-2">
                            {article.title}
                          </h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <Badge variant="outline">{article.category}</Badge>
                            <span>{article.views} views</span>
                            <span>{article.helpful}% helpful</span>
                            <span>Updated {article.updated}</span>
                          </div>
                        </div>
                        <ExternalLink className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* FAQ Sections */}
              <Tabs defaultValue="getting-started" className="space-y-6">
                <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
                  <TabsTrigger value="getting-started" className="text-xs">Getting Started</TabsTrigger>
                  <TabsTrigger value="agrosoil" className="text-xs">AgroSoil</TabsTrigger>
                  <TabsTrigger value="agromarket" className="text-xs">AgroMarket</TabsTrigger>
                  <TabsTrigger value="agroanimal" className="text-xs">AgroAnimal</TabsTrigger>
                  <TabsTrigger value="account" className="text-xs">Account</TabsTrigger>
                  <TabsTrigger value="troubleshooting" className="text-xs">Troubleshooting</TabsTrigger>
                </TabsList>

                {Object.entries(faqData).map(([category, faqs]) => (
                  <TabsContent key={category} value={category}>
                    <Card className="agro-card">
                      <CardHeader>
                        <CardTitle>Frequently Asked Questions</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {faqs.map((faq) => (
                          <Collapsible key={faq.id} open={openItems[faq.id]} onOpenChange={() => toggleItem(faq.id)}>
                            <CollapsibleTrigger className="flex items-center justify-between w-full p-4 text-left bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors">
                              <span className="font-medium text-gray-900">{faq.question}</span>
                              {openItems[faq.id] ? (
                                <ChevronUp className="h-5 w-5 text-gray-500" />
                              ) : (
                                <ChevronDown className="h-5 w-5 text-gray-500" />
                              )}
                            </CollapsibleTrigger>
                            <CollapsibleContent className="px-4 py-3 text-gray-700 bg-white border-l-4 border-green-500 ml-4">
                              {faq.answer}
                            </CollapsibleContent>
                          </Collapsible>
                        ))}
                      </CardContent>
                    </Card>
                  </TabsContent>
                ))}
              </Tabs>

              {/* Contact Support */}
              <Card className="agro-card">
                <CardHeader>
                  <CardTitle>Still Need Help?</CardTitle>
                  <p className="text-gray-600">Our support team is here to help you succeed</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {supportOptions.map((option, index) => (
                      <div key={index} className="text-center p-6 border rounded-lg hover:shadow-md transition-shadow">
                        <div className="mx-auto p-3 rounded-full bg-green-100 w-16 h-16 flex items-center justify-center mb-4">
                          <option.icon className="h-8 w-8 text-green-700" />
                        </div>
                        <h3 className="font-semibold text-gray-900 mb-2">{option.title}</h3>
                        <p className="text-sm text-gray-600 mb-3">{option.description}</p>
                        <div className="space-y-1 mb-4">
                          <div className="text-xs text-gray-500">{option.availability}</div>
                          <div className="text-xs text-green-600 font-medium">
                            Response: {option.responseTime}
                          </div>
                        </div>
                        <Button className="w-full bg-green-600 hover:bg-green-700">
                          {option.action}
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}