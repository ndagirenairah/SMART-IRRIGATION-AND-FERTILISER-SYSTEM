import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSoilDeviceSchema } from "@shared/schema";
import { 
  Droplets, 
  Thermometer, 
  Activity, 
  Zap, 
  PlayCircle, 
  StopCircle,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  Plus,
  Smartphone,
  Wifi,
  Battery,
  Settings,
  Trash2,
  Scan,
  BarChart3,
  Camera,
  Image,
  Upload,
  X,
  CheckCircle
} from "lucide-react";
import Header from "@/components/header";
import MobileNav from "@/components/mobile-nav";
import SoilChart from "@/components/soil-chart";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MapComponent, LocationPicker } from "@/components/ui/maps";
import { LocationData } from "@/utils/maps";
import type { SoilReading, AiRecommendation, IrrigationEvent, SoilDevice } from "@shared/schema";
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

type DeviceFormData = {
  deviceId: string;
  deviceName: string;
  fieldId: string;
  location?: string;
};

export default function AgroSoil() {
  const [selectedField, setSelectedField] = useState("field_a");
  const [selectedMetric, setSelectedMetric] = useState<'moisture' | 'ph' | 'nitrogen' | 'phosphorus' | 'potassium' | 'temperature'>('moisture');
  const [showAddDeviceDialog, setShowAddDeviceDialog] = useState(false);
  const [showScanDialog, setShowScanDialog] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);
  const [showManualEntryDialog, setShowManualEntryDialog] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<SoilDevice | null>(null);
  const [scannedDevice, setScannedDevice] = useState<any>(null);
  const [qrInput, setQrInput] = useState("");
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  const [scanningMode, setScanningMode] = useState<"manual" | "camera" | "gallery">("manual");
  const [autoIrrigationEnabled, setAutoIrrigationEnabled] = useState(true);
  const [fieldLocation, setFieldLocation] = useState<LocationData | null>(null);
  const [manualReadings, setManualReadings] = useState({
    nitrogen: "",
    phosphorus: "", 
    potassium: "",
    moisture: "",
    ph: "",
    temperature: "",
    calcium: "",
    conductivity: ""
  });
  const { toast } = useToast();

  const deviceForm = useForm<DeviceFormData>({
    resolver: zodResolver(insertSoilDeviceSchema.omit({ userId: true, apiKey: true, status: true, createdAt: true, updatedAt: true })),
    defaultValues: {
      deviceId: "",
      deviceName: "",
      fieldId: selectedField,
      location: "",
    },
  });

  const { data: soilReadings = [], isLoading: loadingReadings } = useQuery<SoilReading[]>({
    queryKey: ["/api/soil/readings", `fieldId=${selectedField}`],
  });

  const { data: latestReading } = useQuery<SoilReading>({
    queryKey: ["/api/soil/latest", selectedField],
  });

  const { data: recommendations = [] } = useQuery<AiRecommendation[]>({
    queryKey: ["/api/recommendations"],
  });

  const { data: irrigationEvents = [] } = useQuery<IrrigationEvent[]>({
    queryKey: ["/api/irrigation/events", `fieldId=${selectedField}`],
  });

  const { data: devices = [] } = useQuery<SoilDevice[]>({
    queryKey: ["/api/soil/devices"],
  });

  const generateRecommendationMutation = useMutation({
    mutationFn: async () => {
      if (!latestReading) throw new Error("No soil reading available");
      
      return apiRequest("POST", "/api/recommendations/generate", {
        fieldId: selectedField,
        soilData: {
          nitrogen: latestReading.nitrogen,
          phosphorus: latestReading.phosphorus,
          potassium: latestReading.potassium,
          calcium: latestReading.calcium,
          moisture: latestReading.moisture,
          ph: latestReading.ph,
          conductivity: latestReading.conductivity,
          temperature: latestReading.temperature,
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
      toast({
        title: "AI Recommendations Generated",
        description: "New recommendations based on current soil conditions.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate AI recommendations.",
        variant: "destructive",
      });
    },
  });

  const startIrrigationMutation = useMutation({
    mutationFn: async (data: { type: "manual" | "automatic"; duration?: number; waterAmount?: number }) => {
      return apiRequest("POST", "/api/irrigation/start", {
        userId: 1,
        fieldId: selectedField,
        type: data.type,
        duration: data.duration || waterCalculation.duration,
        waterAmount: (data.waterAmount || waterCalculation.volume).toString(),
        triggeredBy: data.type === "manual" ? "user" : "system",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/irrigation/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/irrigation/events", `fieldId=${selectedField}`] });
      toast({
        title: "Irrigation Started",
        description: `Irrigation started with ${waterCalculation.volume}L/m² for ${waterCalculation.duration} minutes`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start irrigation.",
        variant: "destructive",
      });
    },
  });

  const createDeviceMutation = useMutation({
    mutationFn: async (data: DeviceFormData) => {
      return apiRequest("POST", "/api/soil/devices", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/soil/devices"] });
      setShowAddDeviceDialog(false);
      deviceForm.reset();
      toast({ title: "Device added successfully" });
    },
    onError: () => {
      toast({ title: "Failed to add device", variant: "destructive" });
    },
  });

  const scanDeviceMutation = useMutation({
    mutationFn: async ({ qrData, fieldId }: { qrData: string; fieldId: string }) => {
      return apiRequest("POST", "/api/soil/devices/scan", { qrData, fieldId });
    },
    onSuccess: (data) => {
      setScannedDevice(data);
      deviceForm.setValue("deviceId", data.deviceId);
      deviceForm.setValue("deviceName", data.deviceName);
      deviceForm.setValue("fieldId", data.fieldId);
      toast({ title: "Device scanned successfully" });
    },
    onError: (error: any) => {
      const message = error?.response?.data?.message || "Failed to scan device";
      toast({ title: "Scan Error", description: message, variant: "destructive" });
    },
  });

  const manualDataEntryMutation = useMutation({
    mutationFn: async (data: { deviceId: string; readings: any }) => {
      return apiRequest("POST", "/api/soil/readings/manual", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/soil/readings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/soil/latest"] });
      setShowManualEntryDialog(false);
      toast({ title: "Reading recorded successfully" });
    },
    onError: () => {
      toast({ title: "Failed to record reading", variant: "destructive" });
    },
  });

  // QR Code parsing function
  const parseQRCode = (qrData: string) => {
    try {
      // Handle different QR code formats
      if (qrData.startsWith('NPK:')) {
        return qrData;
      }
      // If it's a JSON string, try to parse it
      if (qrData.startsWith('{')) {
        const parsed = JSON.parse(qrData);
        if (parsed.deviceId && parsed.model) {
          return `NPK:${parsed.deviceId}:${parsed.model}:${parsed.firmware || 'v1.0.0'}`;
        }
      }
      return qrData;
    } catch (error) {
      return qrData;
    }
  };

  // Handle file upload for QR code scanning
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({ 
        title: "Invalid file type", 
        description: "Please select an image file",
        variant: "destructive" 
      });
      return;
    }

    setScanningMode("gallery");
    
    try {
      // Create a canvas to extract QR code
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);
        
        // In a real implementation, you'd use a QR code library like jsQR to scan the image
        // For demo purposes, we'll simulate QR detection with realistic device data
        const deviceId = "DEV" + Math.random().toString(36).substr(2, 6).toUpperCase();
        const models = ["7-in-1 Sensor", "NPK Pro Sensor", "Smart Soil Analyzer", "AgriScan 3000"];
        const firmwares = ["v2.1.3", "v3.0.1", "v2.5.0", "v1.8.2"];
        
        const mockQRData = `NPK:${deviceId}:${models[Math.floor(Math.random() * models.length)]}:${firmwares[Math.floor(Math.random() * firmwares.length)]}`;
        const parsedData = parseQRCode(mockQRData);
        setQrInput(parsedData);
        
        toast({ 
          title: "QR Code detected from gallery", 
          description: `Device ${deviceId} found` 
        });
        
        // Clean up
        URL.revokeObjectURL(img.src);
      };
      
      img.onerror = () => {
        toast({ 
          title: "Failed to process image", 
          description: "Could not read the selected image",
          variant: "destructive" 
        });
      };
      
      img.src = URL.createObjectURL(file);
    } catch (error) {
      toast({ 
        title: "Upload failed", 
        description: "Failed to process the selected image",
        variant: "destructive" 
      });
    }

    // Reset file input
    event.target.value = '';
  };

  // Start camera scanning
  const startCameraScanning = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', // Use back camera on mobile
          width: { ideal: 640 },
          height: { ideal: 480 }
        } 
      });
      
      setShowCameraScanner(true);
      setScanningMode("camera");
      
      // Connect stream to video element
      const video = document.getElementById('camera-video') as HTMLVideoElement;
      if (video) {
        video.srcObject = stream;
      }
      
      // In a real implementation, you'd set up QR code detection here with libraries like jsQR
      // For demo, we'll simulate QR detection after a delay
      setTimeout(() => {
        const mockQRData = "NPK:CAM" + Math.random().toString(36).substr(2, 6).toUpperCase() + ":NPK Sensor Pro:v3.0.1";
        const parsedData = parseQRCode(mockQRData);
        setQrInput(parsedData);
        setShowCameraScanner(false);
        stream.getTracks().forEach(track => track.stop());
        toast({ title: "QR Code scanned from camera" });
      }, 3000);
    } catch (error) {
      console.error('Camera access error:', error);
      toast({ 
        title: "Camera access denied", 
        description: "Please allow camera access or use gallery/manual entry",
        variant: "destructive" 
      });
    }
  };

  // Stop camera scanning
  const stopCameraScanning = () => {
    const video = document.getElementById('camera-video') as HTMLVideoElement;
    if (video && video.srcObject) {
      const stream = video.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      video.srcObject = null;
    }
    setShowCameraScanner(false);
    setScanningMode("manual");
  };

  // Smart water volume calculation based on soil conditions
  const calculateWaterVolume = () => {
    if (!latestReading) {
      return { 
        volume: 25, 
        duration: 30, 
        recommendation: "Standard irrigation recommended - no soil data available",
        factors: {
          moisture: "No data",
          temperature: "No data", 
          ph: "No data",
          nutrients: "No data"
        }
      };
    }

    const { moisture, temperature, ph, nitrogen, phosphorus, potassium } = latestReading;
    
    // Base water requirement (liters per square meter)
    let baseVolume = 25;
    let duration = 30;
    let recommendation = "";
    
    // Adjust based on moisture level
    if (moisture < 20) {
      baseVolume = 40; // Severely dry soil
      duration = 45;
      recommendation = "Critical irrigation needed - soil is severely dry";
    } else if (moisture < 30) {
      baseVolume = 35; // Dry soil
      duration = 40;
      recommendation = "High irrigation needed - soil moisture is low";
    } else if (moisture < 50) {
      baseVolume = 25; // Moderate irrigation
      duration = 30;
      recommendation = "Moderate irrigation recommended";
    } else if (moisture < 70) {
      baseVolume = 15; // Light irrigation
      duration = 20;
      recommendation = "Light irrigation sufficient";
    } else {
      baseVolume = 0; // No irrigation needed
      duration = 0;
      recommendation = "No irrigation needed - soil moisture is adequate";
    }
    
    // Adjust based on temperature
    if (temperature > 30) {
      baseVolume += 5; // Hot weather increases water needs
      recommendation += " (increased for hot weather)";
    } else if (temperature > 25) {
      baseVolume += 2; // Warm weather slight increase
    } else if (temperature < 15) {
      baseVolume = Math.max(0, baseVolume - 3); // Cool weather reduces needs
      recommendation += " (reduced for cool weather)";
    }
    
    // Adjust based on pH (plants absorb water better in optimal pH range)
    if (ph < 6.0 || ph > 7.5) {
      baseVolume += 3; // Poor pH requires more water for nutrient uptake
      recommendation += " (increased due to suboptimal pH)";
    }
    
    // Adjust based on nutrient levels (high nutrients may indicate good water retention)
    const avgNutrients = (nitrogen + phosphorus + potassium) / 3;
    if (avgNutrients > 60) {
      baseVolume = Math.max(0, baseVolume - 2); // Good nutrient levels
    } else if (avgNutrients < 30) {
      baseVolume += 2; // Poor nutrients need more water for uptake
    }
    
    return {
      volume: Math.round(baseVolume),
      duration: Math.round(duration),
      recommendation,
      factors: {
        moisture: `${moisture}% (${moisture < 30 ? 'Low' : moisture < 70 ? 'Moderate' : 'High'})`,
        temperature: `${temperature}°C (${temperature > 30 ? 'Hot' : temperature > 25 ? 'Warm' : temperature < 15 ? 'Cool' : 'Optimal'})`,
        ph: `${ph} (${ph < 6.0 || ph > 7.5 ? 'Suboptimal' : 'Good'})`,
        nutrients: `${Math.round(avgNutrients)}% avg (${avgNutrients < 30 ? 'Low' : avgNutrients > 60 ? 'High' : 'Moderate'})`
      }
    };
  };

  const waterCalculation = calculateWaterVolume();

  // Toggle automatic irrigation mode
  const toggleAutoIrrigation = () => {
    const newState = !autoIrrigationEnabled;
    setAutoIrrigationEnabled(newState);
    
    toast({
      title: newState ? "Auto Mode Enabled" : "Auto Mode Disabled",
      description: newState 
        ? "Automatic irrigation will monitor soil conditions and irrigate as needed"
        : "Automatic irrigation is now disabled. Use manual irrigation when needed",
    });
  };

  const updateDeviceMutation = useMutation({
    mutationFn: async (data: { deviceId: string; updates: Partial<SoilDevice> }) => {
      return apiRequest("PUT", `/api/soil/devices/${data.deviceId}`, data.updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/soil/devices"] });
      setShowConfigDialog(false);
      setSelectedDevice(null);
      toast({ title: "Device updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update device", variant: "destructive" });
    },
  });

  const deleteDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      return apiRequest("DELETE", `/api/soil/devices/${deviceId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/soil/devices"] });
      toast({ title: "Device removed successfully" });
    },
    onError: () => {
      toast({ title: "Failed to remove device", variant: "destructive" });
    },
  });

  const markImplementedMutation = useMutation({
    mutationFn: async (recommendationId: number) => {
      return apiRequest("PUT", `/api/recommendations/${recommendationId}`, {
        implemented: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recommendations"] });
      toast({ title: "Recommendation marked as implemented" });
    },
    onError: () => {
      toast({ title: "Failed to update recommendation", variant: "destructive" });
    },
  });

  const onSubmitDevice = (data: DeviceFormData) => {
    createDeviceMutation.mutate(data);
  };

  const handleConfigureDevice = (device: SoilDevice) => {
    setSelectedDevice(device);
    setShowConfigDialog(true);
  };

  const handleRemoveDevice = (deviceId: string) => {
    if (confirm("Are you sure you want to remove this device? This action cannot be undone.")) {
      deleteDeviceMutation.mutate(deviceId);
    }
  };

  const onUpdateDevice = (updates: Partial<SoilDevice>) => {
    if (selectedDevice) {
      updateDeviceMutation.mutate({
        deviceId: selectedDevice.deviceId,
        updates
      });
    }
  };

  // Enhanced chart data for soil metrics
  const getChartData = () => {
    if (!latestReading) return null;

    return {
      labels: ['Nitrogen', 'Phosphorus', 'Potassium', 'Moisture', 'pH', 'Temperature', 'Conductivity'],
      datasets: [
        {
          label: 'Current Levels',
          data: [
            latestReading.nitrogen,
            latestReading.phosphorus,
            latestReading.potassium,
            latestReading.moisture,
            latestReading.ph * 10, // Scale pH for visibility
            latestReading.temperature,
            latestReading.conductivity
          ],
          backgroundColor: [
            'rgba(34, 197, 94, 0.8)',   // green
            'rgba(59, 130, 246, 0.8)',  // blue
            'rgba(249, 115, 22, 0.8)',  // orange
            'rgba(6, 182, 212, 0.8)',   // cyan
            'rgba(168, 85, 247, 0.8)',  // purple
            'rgba(239, 68, 68, 0.8)',   // red
            'rgba(245, 158, 11, 0.8)',  // amber
          ],
          borderColor: [
            'rgba(34, 197, 94, 1)',
            'rgba(59, 130, 246, 1)',
            'rgba(249, 115, 22, 1)',
            'rgba(6, 182, 212, 1)',
            'rgba(168, 85, 247, 1)',
            'rgba(239, 68, 68, 1)',
            'rgba(245, 158, 11, 1)',
          ],
          borderWidth: 2
        }
      ]
    };
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Current Soil Metrics Overview',
        font: { size: 16, weight: 'bold' }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  const getStatusColor = (value: number, metric: string) => {
    // Define optimal ranges for different metrics
    const ranges = {
      moisture: { low: 30, high: 70 },
      ph: { low: 6.0, high: 7.5 },
      nitrogen: { low: 20, high: 50 },
      phosphorus: { low: 15, high: 40 },
      potassium: { low: 40, high: 80 },
      temperature: { low: 18, high: 30 },
    };

    const range = ranges[metric as keyof typeof ranges];
    if (!range) return "text-gray-600";

    if (value < range.low) return "text-red-600";
    if (value > range.high) return "text-orange-600";
    return "text-green-600";
  };

  const getMetricUnit = (metric: string) => {
    const units = {
      moisture: "%",
      ph: "",
      nitrogen: "%",
      phosphorus: "%",
      potassium: "%",
      temperature: "°C",
      conductivity: "mS/cm",
      calcium: "%",
    };
    return units[metric as keyof typeof units] || "";
  };

  if (loadingReadings) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </main>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 pb-20 md:pb-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                AgroSoil Management
              </h1>
              <p className="text-gray-600 mt-2">Monitor soil conditions and manage irrigation</p>
            </div>
            <div className="flex items-center space-x-4">
              <Select value={selectedField} onValueChange={setSelectedField}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="field_a">Field A</SelectItem>
                  <SelectItem value="field_b">Field B</SelectItem>
                  <SelectItem value="field_c">Field C</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={() => generateRecommendationMutation.mutate()}
                disabled={generateRecommendationMutation.isPending || !latestReading}
                className="bg-green-700 hover:bg-green-800"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${generateRecommendationMutation.isPending ? 'animate-spin' : ''}`} />
                Generate AI Recommendations
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="monitoring" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="monitoring">Soil Monitoring</TabsTrigger>
            <TabsTrigger value="devices">Device Management</TabsTrigger>
            <TabsTrigger value="irrigation">Irrigation Control</TabsTrigger>
            <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
            <TabsTrigger value="location">Field Location</TabsTrigger>
          </TabsList>

          <TabsContent value="monitoring" className="space-y-6">
            {/* Enhanced Chart Overview */}
            {latestReading && getChartData() && (
              <Card className="backdrop-blur-sm bg-white/90 border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center text-green-800">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Soil Metrics Overview
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <Bar data={getChartData()!} options={chartOptions} />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Current Readings */}
            {latestReading && (
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
                {[
                  { key: 'nitrogen', label: 'Nitrogen', icon: Activity },
                  { key: 'phosphorus', label: 'Phosphorus', icon: Activity },
                  { key: 'potassium', label: 'Potassium', icon: Activity },
                  { key: 'calcium', label: 'Calcium', icon: Activity },
                  { key: 'moisture', label: 'Moisture', icon: Droplets },
                  { key: 'ph', label: 'pH Level', icon: Zap },
                  { key: 'conductivity', label: 'Conductivity', icon: Zap },
                  { key: 'temperature', label: 'Temperature', icon: Thermometer },
                ].map(({ key, label, icon: Icon }) => {
                  const value = parseFloat(latestReading[key as keyof SoilReading] as string);
                  return (
                    <Card key={key}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-2 mb-2">
                          <Icon className="h-4 w-4 text-gray-500" />
                          <span className="text-sm font-medium text-gray-700">{label}</span>
                        </div>
                        <div className={`text-2xl font-bold ${getStatusColor(value, key)}`}>
                          {key === 'ph' ? value.toFixed(1) : Math.round(value)}
                          <span className="text-sm font-normal">{getMetricUnit(key)}</span>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Soil Trends Chart */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Soil Trends (Last 7 Days)</CardTitle>
                  <Select value={selectedMetric} onValueChange={(value) => setSelectedMetric(value as any)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="moisture">Moisture</SelectItem>
                      <SelectItem value="ph">pH Level</SelectItem>
                      <SelectItem value="nitrogen">Nitrogen</SelectItem>
                      <SelectItem value="phosphorus">Phosphorus</SelectItem>
                      <SelectItem value="potassium">Potassium</SelectItem>
                      <SelectItem value="temperature">Temperature</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {soilReadings.length > 0 ? (
                  <SoilChart readings={soilReadings.slice(-7)} metric={selectedMetric} />
                ) : (
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    No soil data available for this field
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="devices" className="space-y-6">
            {/* Device Management Header */}
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-green-800">Connected Devices</h2>
              <div className="flex space-x-2">
                <Dialog open={showScanDialog} onOpenChange={setShowScanDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="border-green-600 text-green-700 hover:bg-green-50">
                      <Scan className="h-4 w-4 mr-2" />
                      Scan Device
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Scan NPK Device</DialogTitle>
                      <DialogDescription>
                        Choose your preferred method to scan the QR code on your NPK device.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-6">
                      {/* Scanning Options */}
                      <div className="grid grid-cols-3 gap-3">
                        <Button
                          variant={scanningMode === "camera" ? "default" : "outline"}
                          onClick={startCameraScanning}
                          className="flex flex-col items-center p-4 h-auto"
                          disabled={showCameraScanner}
                        >
                          <Camera className="h-6 w-6 mb-2" />
                          <span className="text-xs">Camera</span>
                        </Button>
                        
                        <Button
                          variant={scanningMode === "gallery" ? "default" : "outline"}
                          onClick={() => document.getElementById('file-upload')?.click()}
                          className="flex flex-col items-center p-4 h-auto"
                          disabled={scanDeviceMutation.isPending}
                        >
                          <Image className="h-6 w-6 mb-2" />
                          <span className="text-xs">Gallery</span>
                        </Button>
                        
                        <Button
                          variant={scanningMode === "manual" ? "default" : "outline"}
                          onClick={() => setScanningMode("manual")}
                          className="flex flex-col items-center p-4 h-auto"
                        >
                          <Scan className="h-6 w-6 mb-2" />
                          <span className="text-xs">Manual</span>
                        </Button>
                      </div>

                      {/* Hidden file input for gallery */}
                      <input
                        id="file-upload"
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />

                      {/* Camera Scanner View */}
                      {showCameraScanner && (
                        <div className="relative">
                          <div className="border-2 border-green-300 rounded-lg p-8 text-center bg-black">
                            <div className="relative">
                              <video 
                                id="camera-video" 
                                className="w-full h-48 object-cover rounded-lg"
                                autoPlay 
                                playsInline
                              />
                              <div className="absolute inset-0 border-2 border-green-400 rounded-lg">
                                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                                  <div className="w-48 h-48 border-2 border-green-400 border-dashed rounded-lg flex items-center justify-center">
                                    <Scan className="h-12 w-12 text-green-400 animate-pulse" />
                                  </div>
                                </div>
                              </div>
                            </div>
                            <p className="text-white text-sm mt-4">Position QR code within the frame</p>
                            <Button 
                              onClick={stopCameraScanning}
                              variant="outline"
                              size="sm"
                              className="mt-3"
                            >
                              <X className="h-4 w-4 mr-2" />
                              Stop Scanning
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Manual Entry Mode */}
                      {scanningMode === "manual" && !showCameraScanner && (
                        <div className="space-y-4">
                          <div className="border-2 border-dashed border-green-300 rounded-lg p-6 text-center">
                            <Scan className="h-10 w-10 mx-auto mb-3 text-green-600" />
                            <p className="text-sm text-gray-600 mb-2">Enter QR code data manually</p>
                            <p className="text-xs text-gray-500">
                              Expected format: NPK:DEVICE_ID:MODEL:FIRMWARE
                            </p>
                          </div>
                          
                          <div className="space-y-3">
                            <Label htmlFor="qr-input">QR Code Data:</Label>
                            <Input
                              id="qr-input"
                              value={qrInput}
                              onChange={(e) => setQrInput(e.target.value)}
                              placeholder="NPK:DEV001:7-in-1 Sensor:v2.1.3"
                              className="font-mono text-sm"
                            />
                          </div>
                        </div>
                      )}

                      {/* Scanning Result Display */}
                      {qrInput && !showCameraScanner && (
                        <div className="space-y-3">
                          <div className="p-3 bg-gray-50 rounded-lg">
                            <Label className="text-xs text-gray-500">Detected QR Data:</Label>
                            <p className="font-mono text-sm text-gray-800 break-all">{qrInput}</p>
                          </div>
                          
                          <Button 
                            onClick={() => {
                              if (qrInput.trim()) {
                                scanDeviceMutation.mutate({ 
                                  qrData: qrInput.trim(), 
                                  fieldId: selectedField 
                                });
                              }
                            }}
                            disabled={scanDeviceMutation.isPending || !qrInput.trim()}
                            className="w-full bg-green-700 hover:bg-green-800"
                          >
                            {scanDeviceMutation.isPending ? 'Processing...' : 'Connect Device'}
                          </Button>
                        </div>
                      )}

                      {/* Device Registration Success */}
                      {scannedDevice && (
                        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                          <h4 className="font-medium text-green-800 mb-2 flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Device Ready!
                          </h4>
                          <div className="space-y-1 text-sm text-green-700">
                            <p><span className="font-medium">Device ID:</span> {scannedDevice.deviceId}</p>
                            <p><span className="font-medium">Model:</span> {scannedDevice.deviceName}</p>
                            <p><span className="font-medium">Firmware:</span> {scannedDevice.firmwareVersion}</p>
                            <p><span className="font-medium">Field:</span> {scannedDevice.fieldId}</p>
                          </div>
                          <Button 
                            className="w-full mt-3 bg-green-700 hover:bg-green-800"
                            onClick={() => {
                              deviceForm.handleSubmit(onSubmitDevice)();
                              setShowScanDialog(false);
                              setQrInput("");
                              setScannedDevice(null);
                              setScanningMode("manual");
                            }}
                          >
                            Register Device
                          </Button>
                        </div>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>

                <Dialog open={showManualEntryDialog} onOpenChange={setShowManualEntryDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="border-blue-600 text-blue-700 hover:bg-blue-50">
                      <Plus className="h-4 w-4 mr-2" />
                      Manual Entry
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Manual NPK Data Entry</DialogTitle>
                      <DialogDescription>
                        Enter soil readings manually from your NPK device display.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="device-select">Select Device:</Label>
                        <Select value={selectedDevice?.deviceId || ""} onValueChange={(value) => {
                          const device = devices.find(d => d.deviceId === value);
                          setSelectedDevice(device || null);
                        }}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a registered device" />
                          </SelectTrigger>
                          <SelectContent>
                            {devices.filter(device => device.deviceId && device.deviceId.trim() !== "").map((device) => (
                              <SelectItem key={device.deviceId} value={device.deviceId}>
                                {device.deviceName || "Unnamed Device"} ({device.fieldId})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {selectedDevice && (
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="nitrogen">Nitrogen (%)</Label>
                            <Input
                              id="nitrogen"
                              type="number"
                              step="0.01"
                              value={manualReadings.nitrogen}
                              onChange={(e) => setManualReadings(prev => ({...prev, nitrogen: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="phosphorus">Phosphorus (%)</Label>
                            <Input
                              id="phosphorus"
                              type="number"
                              step="0.01"
                              value={manualReadings.phosphorus}
                              onChange={(e) => setManualReadings(prev => ({...prev, phosphorus: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="potassium">Potassium (%)</Label>
                            <Input
                              id="potassium"
                              type="number"
                              step="0.01"
                              value={manualReadings.potassium}
                              onChange={(e) => setManualReadings(prev => ({...prev, potassium: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="moisture">Moisture (%)</Label>
                            <Input
                              id="moisture"
                              type="number"
                              step="0.01"
                              value={manualReadings.moisture}
                              onChange={(e) => setManualReadings(prev => ({...prev, moisture: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="ph">pH Level</Label>
                            <Input
                              id="ph"
                              type="number"
                              step="0.01"
                              value={manualReadings.ph}
                              onChange={(e) => setManualReadings(prev => ({...prev, ph: e.target.value}))}
                              placeholder="7.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="temperature">Temperature (°C)</Label>
                            <Input
                              id="temperature"
                              type="number"
                              step="0.01"
                              value={manualReadings.temperature}
                              onChange={(e) => setManualReadings(prev => ({...prev, temperature: e.target.value}))}
                              placeholder="25.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="calcium">Calcium (%) - Optional</Label>
                            <Input
                              id="calcium"
                              type="number"
                              step="0.01"
                              value={manualReadings.calcium}
                              onChange={(e) => setManualReadings(prev => ({...prev, calcium: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="conductivity">Conductivity (mS/cm) - Optional</Label>
                            <Input
                              id="conductivity"
                              type="number"
                              step="0.01"
                              value={manualReadings.conductivity}
                              onChange={(e) => setManualReadings(prev => ({...prev, conductivity: e.target.value}))}
                              placeholder="0.00"
                            />
                          </div>
                        </div>
                      )}

                      {selectedDevice && (
                        <Button 
                          className="w-full bg-blue-700 hover:bg-blue-800"
                          onClick={() => {
                            const readings = {
                              nitrogen: parseFloat(manualReadings.nitrogen) || 0,
                              phosphorus: parseFloat(manualReadings.phosphorus) || 0,
                              potassium: parseFloat(manualReadings.potassium) || 0,
                              moisture: parseFloat(manualReadings.moisture) || 0,
                              ph: parseFloat(manualReadings.ph) || 7,
                              temperature: parseFloat(manualReadings.temperature) || 20,
                              calcium: parseFloat(manualReadings.calcium) || 0,
                              conductivity: parseFloat(manualReadings.conductivity) || 0,
                            };
                            manualDataEntryMutation.mutate({
                              deviceId: selectedDevice.deviceId,
                              readings
                            });
                          }}
                          disabled={manualDataEntryMutation.isPending || !selectedDevice}
                        >
                          {manualDataEntryMutation.isPending ? 'Recording...' : 'Record Reading'}
                        </Button>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
                
                <Dialog open={showAddDeviceDialog} onOpenChange={setShowAddDeviceDialog}>
                  <DialogTrigger asChild>
                    <Button className="bg-green-700 hover:bg-green-800">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Device
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Device</DialogTitle>
                      <DialogDescription>
                        Register a new soil monitoring device to your field.
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...deviceForm}>
                      <form onSubmit={deviceForm.handleSubmit(onSubmitDevice)} className="space-y-4">
                        <FormField
                          control={deviceForm.control}
                          name="deviceId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Device ID</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter device ID..." {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={deviceForm.control}
                          name="deviceName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Device Name</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. 7-in-1 NPK Sensor" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={deviceForm.control}
                          name="fieldId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Field Assignment</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a field" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="field_a">Field A</SelectItem>
                                  <SelectItem value="field_b">Field B</SelectItem>
                                  <SelectItem value="field_c">Field C</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={deviceForm.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Location (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. North section" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="flex justify-end space-x-2">
                          <Button type="button" variant="outline" onClick={() => setShowAddDeviceDialog(false)}>
                            Cancel
                          </Button>
                          <Button type="submit" disabled={createDeviceMutation.isPending} className="bg-green-700 hover:bg-green-800">
                            {createDeviceMutation.isPending ? 'Adding...' : 'Add Device'}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>

                {/* Device Configuration Dialog */}
                <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Configure Device</DialogTitle>
                      <DialogDescription>
                        Update device settings and configuration.
                      </DialogDescription>
                    </DialogHeader>
                    {selectedDevice && (
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Device Name</label>
                          <Input 
                            defaultValue={selectedDevice.deviceName}
                            onChange={(e) => {
                              setSelectedDevice({...selectedDevice, deviceName: e.target.value});
                            }}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Field Assignment</label>
                          <Select 
                            defaultValue={selectedDevice.fieldId}
                            onValueChange={(value) => {
                              setSelectedDevice({...selectedDevice, fieldId: value});
                            }}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="field_a">Field A</SelectItem>
                              <SelectItem value="field_b">Field B</SelectItem>
                              <SelectItem value="field_c">Field C</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Location</label>
                          <Input 
                            defaultValue={selectedDevice.location || ''}
                            onChange={(e) => {
                              setSelectedDevice({...selectedDevice, location: e.target.value});
                            }}
                            placeholder="e.g. North section"
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Status</label>
                          <Select 
                            defaultValue={selectedDevice.status}
                            onValueChange={(value) => {
                              setSelectedDevice({...selectedDevice, status: value as 'active' | 'inactive' | 'maintenance'});
                            }}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="inactive">Inactive</SelectItem>
                              <SelectItem value="maintenance">Maintenance</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <h4 className="font-medium text-sm mb-2">Device Information</h4>
                          <div className="space-y-1 text-xs text-gray-600">
                            <p>Device ID: {selectedDevice.deviceId}</p>
                            <p>API Key: {selectedDevice.apiKey?.substring(0, 12)}...</p>
                            <p>Created: {new Date(selectedDevice.createdAt).toLocaleDateString()}</p>
                          </div>
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setShowConfigDialog(false)}
                          >
                            Cancel
                          </Button>
                          <Button 
                            onClick={() => onUpdateDevice({
                              deviceName: selectedDevice.deviceName,
                              fieldId: selectedDevice.fieldId,
                              location: selectedDevice.location,
                              status: selectedDevice.status
                            })}
                            disabled={updateDeviceMutation.isPending}
                            className="bg-green-700 hover:bg-green-800"
                          >
                            {updateDeviceMutation.isPending ? 'Updating...' : 'Update Device'}
                          </Button>
                        </div>
                      </div>
                    )}
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Devices Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {devices.map((device) => (
                <Card key={device.id} className="backdrop-blur-sm bg-white/90 border-0 shadow-lg">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg text-green-800">{device.deviceName}</CardTitle>
                      <Badge variant={device.status === 'active' ? 'default' : 'secondary'} className="bg-green-100 text-green-800">
                        {device.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-gray-600">ID: {device.deviceId}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Wifi className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Field: {device.fieldId}</span>
                    </div>
                    {device.location && (
                      <div className="flex items-center space-x-2">
                        <Activity className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-600">Location: {device.location}</span>
                      </div>
                    )}
                    <div className="flex items-center space-x-2">
                      <Battery className="h-4 w-4 text-gray-500" />
                      <span className="text-sm text-gray-600">Battery: 85%</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-green-700 border-green-600 hover:bg-green-50"
                        onClick={() => handleConfigureDevice(device)}
                      >
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-red-600 border-red-300 hover:bg-red-50"
                        onClick={() => handleRemoveDevice(device.deviceId)}
                        disabled={deleteDeviceMutation.isPending}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        {deleteDeviceMutation.isPending ? 'Removing...' : 'Remove'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {devices.length === 0 && (
                <div className="col-span-full text-center py-12">
                  <Smartphone className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No devices connected</h3>
                  <p className="text-gray-600 mb-6">Add your first soil monitoring device to get started</p>
                  <Button 
                    onClick={() => setShowAddDeviceDialog(true)}
                    className="bg-green-700 hover:bg-green-800"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Device
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="irrigation" className="space-y-6">
            {/* Water Volume Summary */}
            <Card className="bg-gradient-to-r from-blue-500 to-green-500 text-white">
              <CardHeader>
                <CardTitle className="text-white">Smart Water Volume Recommendation</CardTitle>
                <p className="text-blue-100">AI-calculated based on current soil conditions</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-white/20 rounded-lg p-4">
                    <div className="text-3xl font-bold">{waterCalculation.volume}</div>
                    <div className="text-sm text-blue-100">Liters per m²</div>
                  </div>
                  <div className="bg-white/20 rounded-lg p-4">
                    <div className="text-3xl font-bold">{waterCalculation.duration}</div>
                    <div className="text-sm text-blue-100">Minutes</div>
                  </div>
                  <div className="bg-white/20 rounded-lg p-4">
                    <div className="text-lg font-semibold">
                      {latestReading?.moisture || 'N/A'}%
                    </div>
                    <div className="text-sm text-blue-100">Current Moisture</div>
                  </div>
                </div>
                <div className="mt-4 text-center text-sm text-blue-100">
                  {waterCalculation.recommendation}
                </div>
              </CardContent>
            </Card>

            {/* Irrigation Controls */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Smart Irrigation Recommendation</CardTitle>
                  <p className="text-sm text-gray-600">AI-calculated water needs based on soil conditions</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gradient-to-br from-blue-50 to-green-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-gray-700">Recommended Volume:</span>
                      <span className="text-2xl font-bold text-blue-600">
                        {waterCalculation.volume} <span className="text-sm">L/m²</span>
                      </span>
                    </div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-gray-700">Duration:</span>
                      <span className="text-lg font-semibold text-green-600">
                        {waterCalculation.duration} minutes
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 mb-3">
                      <strong>Assessment:</strong> {waterCalculation.recommendation}
                    </div>
                    
                    {/* Calculation Factors */}
                    <div className="space-y-2 text-xs">
                      <div className="font-medium text-gray-700 mb-1">Based on current conditions:</div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>• Moisture: {waterCalculation.factors.moisture}</div>
                        <div>• Temperature: {waterCalculation.factors.temperature}</div>
                        <div>• pH: {waterCalculation.factors.ph}</div>
                        <div>• Nutrients: {waterCalculation.factors.nutrients}</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Current Status:</span>
                    <Badge variant="outline">Standby</Badge>
                  </div>
                  
                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    onClick={() => {
                      startIrrigationMutation.mutate({ 
                        type: "manual", 
                        duration: waterCalculation.duration, 
                        waterAmount: waterCalculation.volume 
                      });
                    }}
                    disabled={startIrrigationMutation.isPending || waterCalculation.volume === 0}
                  >
                    <PlayCircle className="h-4 w-4 mr-2" />
                    {startIrrigationMutation.isPending 
                      ? "Starting..." 
                      : waterCalculation.volume === 0 
                        ? "No Irrigation Needed"
                        : "Start Smart Irrigation"
                    }
                  </Button>
                  
                  {waterCalculation.volume > 0 && (
                    <p className="text-xs text-gray-500">
                      This will apply {waterCalculation.volume}L per square meter for {waterCalculation.duration} minutes
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Automatic Irrigation</CardTitle>
                  <p className="text-sm text-gray-600">AI-controlled irrigation based on smart soil analysis</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className={`bg-gradient-to-br p-4 rounded-lg border ${
                    autoIrrigationEnabled 
                      ? 'from-green-50 to-blue-50 border-green-200' 
                      : 'from-gray-50 to-red-50 border-red-200'
                  }`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-gray-700">Auto Mode:</span>
                      <Badge className={autoIrrigationEnabled 
                        ? "bg-green-100 text-green-800" 
                        : "bg-red-100 text-red-800"
                      }>
                        {autoIrrigationEnabled ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                    
                    <div className={`space-y-2 text-sm ${!autoIrrigationEnabled ? 'opacity-60' : ''}`}>
                      <div className="flex justify-between">
                        <span>• Smart Volume:</span>
                        <span className={`font-semibold ${autoIrrigationEnabled ? 'text-blue-600' : 'text-gray-500'}`}>
                          {autoIrrigationEnabled ? waterCalculation.volume : '--'}L/m²
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>• Moisture threshold:</span>
                        <span>{autoIrrigationEnabled ? '30%' : '--'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>• Next check:</span>
                        <span>{autoIrrigationEnabled ? 'in 2 hours' : 'Disabled'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>• Target moisture:</span>
                        <span>{autoIrrigationEnabled ? '50-60%' : '--'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>• Smart duration:</span>
                        <span className={`font-semibold ${autoIrrigationEnabled ? 'text-green-600' : 'text-gray-500'}`}>
                          {autoIrrigationEnabled ? waterCalculation.duration : '--'} min
                        </span>
                      </div>
                    </div>
                    
                    {autoIrrigationEnabled && (
                      <div className="mt-3 p-2 bg-blue-100 rounded text-xs text-blue-800">
                        <strong>Next Action:</strong> {waterCalculation.recommendation}
                      </div>
                    )}
                    {!autoIrrigationEnabled && (
                      <div className="mt-3 p-2 bg-red-100 rounded text-xs text-red-800">
                        <strong>Status:</strong> Automatic irrigation is disabled. Manual irrigation required.
                      </div>
                    )}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className={`w-full ${
                      autoIrrigationEnabled 
                        ? 'hover:bg-red-50 hover:border-red-300 hover:text-red-700' 
                        : 'hover:bg-green-50 hover:border-green-300 hover:text-green-700'
                    }`}
                    onClick={toggleAutoIrrigation}
                  >
                    {autoIrrigationEnabled ? (
                      <>
                        <StopCircle className="h-4 w-4 mr-2" />
                        Disable Auto Mode
                      </>
                    ) : (
                      <>
                        <PlayCircle className="h-4 w-4 mr-2" />
                        Enable Auto Mode
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Irrigation History */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Irrigation Events</CardTitle>
              </CardHeader>
              <CardContent>
                {irrigationEvents.length > 0 ? (
                  <div className="space-y-3">
                    {irrigationEvents.slice(0, 5).map((event) => (
                      <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Droplets className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium text-gray-900">
                              {event.type === 'manual' ? 'Manual' : 'Automatic'} Irrigation
                            </p>
                            <p className="text-sm text-gray-500">
                              {event.duration} minutes • {event.waterAmount}L/m² applied
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-500">
                            {new Date(event.timestamp).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-400">
                            {new Date(event.timestamp).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Droplets className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No irrigation events recorded for this field</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            {/* AI Recommendations */}
            <div className="space-y-4">
              {recommendations.length > 0 ? (
                recommendations.map((rec) => (
                  <Card key={rec.id} className={`border-l-4 ${
                    rec.priority === 'critical' ? 'border-l-red-500' :
                    rec.priority === 'high' ? 'border-l-orange-500' :
                    rec.priority === 'medium' ? 'border-l-yellow-500' :
                    'border-l-blue-500'
                  }`}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          {rec.category === 'fertilizer' && <Activity className="h-5 w-5 text-green-600" />}
                          {rec.category === 'irrigation' && <Droplets className="h-5 w-5 text-blue-600" />}
                          {rec.category === 'general' && <TrendingUp className="h-5 w-5 text-purple-600" />}
                          <div>
                            <CardTitle className="text-lg capitalize">{rec.category} Recommendation</CardTitle>
                            <p className="text-sm text-gray-500">
                              Field: {rec.fieldId.replace('_', ' ').toUpperCase()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={
                            rec.priority === 'critical' ? 'destructive' :
                            rec.priority === 'high' ? 'default' :
                            'secondary'
                          }>
                            {rec.priority} priority
                          </Badge>
                          {rec.priority === 'critical' && <AlertTriangle className="h-5 w-5 text-red-500" />}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4">{rec.recommendation}</p>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-gray-500">
                          Generated: {new Date(rec.createdAt).toLocaleDateString()}
                        </p>
                        <Button
                          size="sm"
                          variant={rec.implemented ? "outline" : "default"}
                          disabled={rec.implemented || markImplementedMutation.isPending}
                          onClick={() => markImplementedMutation.mutate(rec.id)}
                          className={rec.implemented ? "bg-green-100 text-green-800" : "bg-blue-600 hover:bg-blue-700"}
                        >
                          {rec.implemented ? "✓ Implemented" : 
                           markImplementedMutation.isPending ? "Marking..." : "Mark as Implemented"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Activity className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Recommendations Yet</h3>
                    <p className="text-gray-500 mb-4">
                      Generate AI-powered recommendations based on your current soil conditions.
                    </p>
                    <Button
                      onClick={() => generateRecommendationMutation.mutate()}
                      disabled={generateRecommendationMutation.isPending || !latestReading}
                      className="bg-green-700 hover:bg-green-800"
                    >
                      <RefreshCw className={`h-4 w-4 mr-2 ${generateRecommendationMutation.isPending ? 'animate-spin' : ''}`} />
                      Generate Recommendations
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="location" className="space-y-6">
            {/* Field Location Management */}
            <div className="grid gap-6 md:grid-cols-2">
              {/* Location Selector */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <span>📍</span>
                    <span>Field Location</span>
                  </CardTitle>
                  <p className="text-sm text-gray-600">
                    Set and manage your field's precise location using Google Maps
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="field-location">Current Location</Label>
                    <LocationPicker
                      onLocationSelect={(location) => {
                        setFieldLocation(location);
                        toast({
                          title: "Location Updated",
                          description: `Field location set to: ${location.address || `${location.lat.toFixed(6)}, ${location.lng.toFixed(6)}`}`,
                        });
                      }}
                      initialLocation={fieldLocation || undefined}
                      placeholder="Select field location on map"
                      className="mt-2"
                    />
                  </div>

                  {fieldLocation && (
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="font-medium">Coordinates:</span>
                          <span>{fieldLocation.lat.toFixed(6)}, {fieldLocation.lng.toFixed(6)}</span>
                        </div>
                        {fieldLocation.address && (
                          <div className="flex justify-between">
                            <span className="font-medium">Address:</span>
                            <span className="text-right max-w-48 truncate">{fieldLocation.address}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <Button 
                    className="w-full"
                    variant="outline"
                    onClick={() => {
                      // Get current location using browser geolocation
                      if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(
                          (position) => {
                            const location: LocationData = {
                              lat: position.coords.latitude,
                              lng: position.coords.longitude,
                            };
                            setFieldLocation(location);
                            toast({
                              title: "Location Detected",
                              description: "Current location has been set as field location",
                            });
                          },
                          (error) => {
                            toast({
                              title: "Location Error",
                              description: "Unable to get current location. Please select manually.",
                              variant: "destructive",
                            });
                          }
                        );
                      }
                    }}
                  >
                    📡 Use My Current Location
                  </Button>
                </CardContent>
              </Card>

              {/* Field Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <span>🌾</span>
                    <span>Field Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-xs text-gray-500">Field ID</Label>
                      <p className="font-mono text-sm">{selectedField}</p>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-gray-500">Status</Label>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                  </div>

                  {fieldLocation && (
                    <>
                      <Separator />
                      <div className="space-y-3">
                        <Label className="text-sm font-medium">Location Details</Label>
                        <div className="grid grid-cols-1 gap-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Latitude:</span>
                            <span className="font-mono">{fieldLocation.lat.toFixed(6)}°</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Longitude:</span>
                            <span className="font-mono">{fieldLocation.lng.toFixed(6)}°</span>
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  <div className="pt-4">
                    <Button variant="outline" className="w-full">
                      🗺️ View on Satellite Map
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>


          </TabsContent>
        </Tabs>
      </main>

      <MobileNav />
    </div>
  );
}
