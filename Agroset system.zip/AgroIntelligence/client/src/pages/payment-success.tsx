import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Crown, ArrowRight, Loader2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";

export default function PaymentSuccess() {
  const [, setLocation] = useLocation();
  const [redirectTimer, setRedirectTimer] = useState(5);
  const [subscriptionActivated, setSubscriptionActivated] = useState(false);

  // Check subscription status
  const { data: subscription, isLoading } = useQuery({
    queryKey: ["/api/subscription"],
    refetchInterval: 2000, // Poll every 2 seconds until subscription is found
    refetchOnWindowFocus: true,
  });

  // Check trial status to ensure restrictions are lifted
  const { data: trialStatus } = useQuery({
    queryKey: ["/api/user/trial-status"],
    refetchInterval: 2000,
  });

  useEffect(() => {
    // Clear any cached data to force fresh fetch
    queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
    queryClient.invalidateQueries({ queryKey: ["/api/user/trial-status"] });
    queryClient.invalidateQueries({ queryKey: ["/api/user"] });
  }, []);

  useEffect(() => {
    if (subscription && subscription.status === "active") {
      setSubscriptionActivated(true);
      
      // Start redirect timer
      const timer = setInterval(() => {
        setRedirectTimer((prev) => {
          if (prev <= 1) {
            setLocation("/dashboard");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [subscription, setLocation]);

  const planInfo = {
    basic: { name: "Basic Plan", price: "USh 5,000" },
    premium: { name: "Premium Plan", price: "USh 10,000" },
    enterprise: { name: "Enterprise Plan", price: "USh 20,000" }
  };

  const currentPlan = subscription?.planType || "premium";
  const plan = planInfo[currentPlan as keyof typeof planInfo] || planInfo.premium;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-green-200 shadow-xl">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto mb-6 p-4 rounded-full bg-green-100 animate-pulse">
            {subscriptionActivated ? (
              <CheckCircle className="h-16 w-16 text-green-600" />
            ) : (
              <Loader2 className="h-16 w-16 text-green-600 animate-spin" />
            )}
          </div>
          
          <CardTitle className="text-3xl font-bold text-gray-800 mb-2">
            {subscriptionActivated ? "Subscription Activated!" : "Processing Payment..."}
          </CardTitle>
          
          {subscriptionActivated ? (
            <div>
              <p className="text-lg text-gray-600 mb-2">
                Welcome to AgroSet {plan.name}!
              </p>
              <p className="text-sm text-gray-500">
                Your payment of {plan.price}/month has been processed successfully
              </p>
            </div>
          ) : (
            <p className="text-lg text-gray-600">
              Please wait while we activate your subscription...
            </p>
          )}
        </CardHeader>
        
        <CardContent>
          {subscriptionActivated ? (
            <>
              {/* Success Features */}
              <div className="bg-green-50 rounded-lg p-6 mb-6">
                <div className="flex items-center mb-4">
                  <Crown className="h-6 w-6 text-green-600 mr-2" />
                  <h3 className="font-semibold text-green-800">Now Available</h3>
                </div>
                <div className="grid md:grid-cols-2 gap-3">
                  <div className="flex items-center text-sm text-green-700">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Real-time soil monitoring
                  </div>
                  <div className="flex items-center text-sm text-green-700">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    AI-powered recommendations
                  </div>
                  <div className="flex items-center text-sm text-green-700">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Smart irrigation controls
                  </div>
                  <div className="flex items-center text-sm text-green-700">
                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                    Advanced analytics
                  </div>
                </div>
              </div>

              {/* Redirect Countdown */}
              <div className="text-center mb-6">
                <p className="text-gray-600 mb-4">
                  Automatically redirecting to your dashboard in {redirectTimer} seconds...
                </p>
                <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                  <div 
                    className="bg-green-600 h-2 rounded-full transition-all duration-1000"
                    style={{ width: `${((5 - redirectTimer) / 5) * 100}%` }}
                  ></div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Link href="/dashboard">
                  <Button className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-3">
                    Go to Dashboard Now
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>
                </Link>
                
                <div className="flex space-x-3">
                  <Link href="/soil" className="flex-1">
                    <Button variant="outline" className="w-full border-green-300 text-green-700">
                      View Soil Data
                    </Button>
                  </Link>
                  <Link href="/subscription" className="flex-1">
                    <Button variant="outline" className="w-full border-green-300 text-green-700">
                      Manage Plan
                    </Button>
                  </Link>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center">
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
              </div>
              <p className="text-sm text-gray-500 mt-4">
                This usually takes just a few moments...
              </p>
            </div>
          )}

          {/* Support Contact */}
          <div className="mt-8 pt-6 border-t text-center text-sm text-gray-500">
            <p>Need help? Contact our support team</p>
            <p className="font-medium text-green-600">support@agroset.com</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}