import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Heart, 
  Plus, 
  Search, 
  Filter,
  Calendar,
  Weight,
  Stethoscope,
  MapPin,
  Tag,
  Camera,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  Eye,
  Scan,
  Wifi,
  WifiOff,
  Settings,
  Edit,
  Trash2
} from "lucide-react";
import Header from "@/components/header";
import MobileNav from "@/components/mobile-nav";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertAnimalSchema, insertAnimalHealthRecordSchema, type Animal, type AnimalHealthRecord } from "@shared/schema";

const createAnimalSchema = insertAnimalSchema.extend({
  userId: z.number().default(1),
});

const createHealthRecordSchema = insertAnimalHealthRecordSchema;

const addCameraSchema = z.object({
  deviceId: z.string().min(1, "Device ID is required"),
  deviceName: z.string().min(1, "Device name is required"),
  location: z.string().min(1, "Location is required"),
  cameraType: z.enum(["indoor", "outdoor", "barn", "pasture"]),
});

const editAnimalSchema = z.object({
  tagId: z.string().min(1, "Tag ID is required"),
  type: z.string().min(1, "Animal type is required"),
  breed: z.string().optional(),
  gender: z.enum(["male", "female"]),
  weight: z.string().optional(),
  birthDate: z.string().optional(),
  location: z.string().optional(),
  healthStatus: z.string().optional(),
  notes: z.string().optional(),
});

const deleteAnimalSchema = z.object({
  deletionReason: z.enum(["sold", "deceased", "transferred"]),
  salePrice: z.string().optional(),
  buyerInfo: z.string().optional(),
  causeOfDeath: z.string().optional(),
  notes: z.string().optional(),
});

type CreateAnimalData = z.infer<typeof createAnimalSchema>;
type CreateHealthRecordData = z.infer<typeof createHealthRecordSchema>;
type AddCameraData = z.infer<typeof addCameraSchema>;
type EditAnimalData = z.infer<typeof editAnimalSchema>;
type DeleteAnimalData = z.infer<typeof deleteAnimalSchema>;

export default function AgroAnimal() {
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [showAddAnimalDialog, setShowAddAnimalDialog] = useState(false);
  const [showHealthRecordDialog, setShowHealthRecordDialog] = useState(false);
  const [showViewAnimalDialog, setShowViewAnimalDialog] = useState(false);
  const [showEditAnimalDialog, setShowEditAnimalDialog] = useState(false);
  const [showDeleteAnimalDialog, setShowDeleteAnimalDialog] = useState(false);
  const [showAddCameraDialog, setShowAddCameraDialog] = useState(false);
  const [showViewCameraDialog, setShowViewCameraDialog] = useState(false);
  const [showConfigCameraDialog, setShowConfigCameraDialog] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState<{id: string, name: string, location: string} | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scannedDeviceId, setScannedDeviceId] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const { toast } = useToast();

  const { data: animals = [], isLoading: loadingAnimals } = useQuery<Animal[]>({
    queryKey: ["/api/animals"],
  });

  const { data: healthRecords = [] } = useQuery<AnimalHealthRecord[]>({
    queryKey: ["/api/animals", selectedAnimal?.id, "health"],
    enabled: !!selectedAnimal,
  });

  const animalForm = useForm<CreateAnimalData>({
    resolver: zodResolver(createAnimalSchema),
    defaultValues: {
      userId: 1,
      tagId: "",
      type: "",
      breed: "",
      gender: "",
      weight: "",
      healthStatus: "healthy",
      location: "Main Pasture",
      notes: "",
    },
  });

  const healthForm = useForm<CreateHealthRecordData>({
    resolver: zodResolver(createHealthRecordSchema),
    defaultValues: {
      animalId: selectedAnimal?.id || 0,
      recordType: "",
      description: "",
      veterinarian: "",
      cost: "",
    },
  });

  const cameraForm = useForm<AddCameraData>({
    resolver: zodResolver(addCameraSchema),
    defaultValues: {
      deviceId: scannedDeviceId || "",
      deviceName: "",
      location: "",
      cameraType: "outdoor",
    },
  });

  const editForm = useForm<EditAnimalData>({
    resolver: zodResolver(editAnimalSchema),
    defaultValues: {
      tagId: "",
      type: "",
      breed: "",
      gender: "female",
      weight: "",
      birthDate: "",
      location: "",
      healthStatus: "",
      notes: "",
    },
  });

  const deleteForm = useForm<DeleteAnimalData>({
    resolver: zodResolver(deleteAnimalSchema),
    defaultValues: {
      deletionReason: "sold",
      salePrice: "",
      buyerInfo: "",
      causeOfDeath: "",
      notes: "",
    },
  });

  // Sync scanned device ID with form
  useEffect(() => {
    if (scannedDeviceId) {
      cameraForm.setValue("deviceId", scannedDeviceId);
    }
  }, [scannedDeviceId, cameraForm]);

  // Update edit form when animal is selected
  useEffect(() => {
    if (selectedAnimal && showEditAnimalDialog) {
      editForm.setValue("tagId", selectedAnimal.tagId);
      editForm.setValue("type", selectedAnimal.type);
      editForm.setValue("breed", selectedAnimal.breed || "");
      editForm.setValue("gender", selectedAnimal.gender as "male" | "female");
      editForm.setValue("weight", selectedAnimal.weight || "");
      editForm.setValue("birthDate", selectedAnimal.birthDate ? new Date(selectedAnimal.birthDate).toISOString().split('T')[0] : "");
      editForm.setValue("location", selectedAnimal.location || "");
      editForm.setValue("healthStatus", selectedAnimal.healthStatus || "");
      editForm.setValue("notes", selectedAnimal.notes || "");
    }
  }, [selectedAnimal, showEditAnimalDialog, editForm]);

  const createAnimalMutation = useMutation({
    mutationFn: async (data: CreateAnimalData) => {
      return apiRequest("POST", "/api/animals", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/animals"] });
      setShowAddAnimalDialog(false);
      animalForm.reset();
      toast({
        title: "Animal Added",
        description: "New animal has been registered successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add animal.",
        variant: "destructive",
      });
    },
  });

  const createHealthRecordMutation = useMutation({
    mutationFn: async (data: CreateHealthRecordData) => {
      return apiRequest("POST", "/api/animals/health", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/animals"] });
      setShowHealthRecordDialog(false);
      healthForm.reset();
      toast({
        title: "Health Record Added",
        description: "Health record has been recorded successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add health record.",
        variant: "destructive",
      });
    },
  });

  const addCameraMutation = useMutation({
    mutationFn: async (data: AddCameraData) => {
      return apiRequest("POST", "/api/cctv/devices", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cctv/devices"] });
      setShowAddCameraDialog(false);
      cameraForm.reset();
      setScannedDeviceId("");
      setIsScanning(false);
      toast({
        title: "Camera Added",
        description: "CCTV camera has been connected successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to connect camera device.",
        variant: "destructive",
      });
    },
  });

  const editAnimalMutation = useMutation({
    mutationFn: async (data: EditAnimalData) => {
      if (!selectedAnimal) throw new Error("No animal selected");
      return apiRequest("PUT", `/api/animals/${selectedAnimal.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/animals"] });
      setShowEditAnimalDialog(false);
      setSelectedAnimal(null);
      editForm.reset();
      toast({
        title: "Animal Updated",
        description: "Animal details have been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update animal.",
        variant: "destructive",
      });
    },
  });

  const deleteAnimalMutation = useMutation({
    mutationFn: async (data: DeleteAnimalData) => {
      if (!selectedAnimal) throw new Error("No animal selected");
      return apiRequest("DELETE", `/api/animals/${selectedAnimal.id}`, {
        ...data,
        deletedBy: "Farm Manager", // This would come from the authenticated user
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/animals"] });
      setShowDeleteAnimalDialog(false);
      setSelectedAnimal(null);
      deleteForm.reset();
      toast({
        title: "Animal Removed",
        description: "Animal has been removed and archived in farm records.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove animal.",
        variant: "destructive",
      });
    },
  });

  const filteredAnimals = animals.filter(animal => {
    const matchesSearch = !searchQuery || 
      animal.tagId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      animal.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (animal.breed && animal.breed.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = filterStatus === "all" || animal.healthStatus === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const getHealthStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-green-100 text-green-800";
      case "sick":
        return "bg-red-100 text-red-800";
      case "quarantine":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getHealthStatusIcon = (status: string) => {
    switch (status) {
      case "healthy":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "sick":
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case "quarantine":
        return <Clock className="h-4 w-4 text-yellow-600" />;
      default:
        return <Activity className="h-4 w-4 text-gray-600" />;
    }
  };

  const formatDate = (date: string | Date | null) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const onSubmitAnimal = (data: CreateAnimalData) => {
    createAnimalMutation.mutate(data);
  };

  const onSubmitHealthRecord = (data: CreateHealthRecordData) => {
    if (!selectedAnimal) return;
    const recordData = {
      ...data,
      animalId: selectedAnimal.id,
    };
    createHealthRecordMutation.mutate(recordData);
  };

  const onSubmitCamera = (data: AddCameraData) => {
    addCameraMutation.mutate(data);
  };

  const onSubmitEditAnimal = (data: EditAnimalData) => {
    editAnimalMutation.mutate(data);
  };

  const onSubmitDeleteAnimal = (data: DeleteAnimalData) => {
    deleteAnimalMutation.mutate(data);
  };

  const handleEditAnimal = (animal: Animal) => {
    setSelectedAnimal(animal);
    setShowEditAnimalDialog(true);
  };

  const handleDeleteAnimal = (animal: Animal) => {
    setSelectedAnimal(animal);
    setShowDeleteAnimalDialog(true);
  };

  const startScanning = () => {
    setIsScanning(true);
    // Simulate camera scanning - in real implementation, this would use device camera
    setTimeout(() => {
      const mockDeviceId = `CAM_${Math.random().toString(36).substr(2, 8).toUpperCase()}`;
      setScannedDeviceId(mockDeviceId);
      cameraForm.setValue("deviceId", mockDeviceId);
      setIsScanning(false);
      toast({
        title: "Device Scanned",
        description: `Camera device ID: ${mockDeviceId}`,
      });
    }, 3000);
  };

  const handleViewCamera = (camera: {id: string, name: string, location: string}) => {
    setSelectedCamera(camera);
    setShowViewCameraDialog(true);
  };

  const handleConfigureCamera = (camera: {id: string, name: string, location: string}) => {
    setSelectedCamera(camera);
    setShowConfigCameraDialog(true);
  };

  const calculateAge = (birthDate: string | Date | null) => {
    if (!birthDate) return "Unknown";
    const birth = new Date(birthDate);
    const now = new Date();
    const diffInMonths = (now.getFullYear() - birth.getFullYear()) * 12 + (now.getMonth() - birth.getMonth());
    
    if (diffInMonths < 12) {
      return `${diffInMonths} months`;
    }
    return `${Math.floor(diffInMonths / 12)} years`;
  };

  if (loadingAnimals) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </main>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 pb-20 md:pb-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                AgroAnimal Management
              </h1>
              <p className="text-gray-600 mt-2">Track and manage your livestock</p>
            </div>
            <Dialog open={showAddAnimalDialog} onOpenChange={setShowAddAnimalDialog}>
              <DialogTrigger asChild>
                <Button className="agro-button-primary">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Animal
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md agro-card">
                <DialogHeader>
                  <DialogTitle>Register New Animal</DialogTitle>
                  <DialogDescription>
                    Add a new animal to your livestock management system
                  </DialogDescription>
                </DialogHeader>
                <Form {...animalForm}>
                  <form onSubmit={animalForm.handleSubmit(onSubmitAnimal)} className="space-y-4">
                    <FormField
                      control={animalForm.control}
                      name="tagId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tag ID</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., A001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={animalForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="cow">Cow</SelectItem>
                                <SelectItem value="sheep">Sheep</SelectItem>
                                <SelectItem value="goat">Goat</SelectItem>
                                <SelectItem value="pig">Pig</SelectItem>
                                <SelectItem value="chicken">Chicken</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={animalForm.control}
                        name="gender"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select gender" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="male">Male</SelectItem>
                                <SelectItem value="female">Female</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={animalForm.control}
                      name="breed"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Breed</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Holstein" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={animalForm.control}
                      name="weight"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Weight (kg)</FormLabel>
                          <FormControl>
                            <Input placeholder="500" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={animalForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="Main Pasture" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={animalForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Any special notes..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full agro-button-primary"
                      disabled={createAnimalMutation.isPending}
                    >
                      {createAnimalMutation.isPending ? "Registering..." : "Register Animal"}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="animals" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="animals">Animal Registry</TabsTrigger>
            <TabsTrigger value="health">Health Records</TabsTrigger>
            <TabsTrigger value="monitoring">CCTV Monitoring</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="animals" className="space-y-6">
            {/* Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by tag ID, type, or breed..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-48">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="healthy">Healthy</SelectItem>
                  <SelectItem value="sick">Sick</SelectItem>
                  <SelectItem value="quarantine">Quarantine</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Statistics Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Heart className="h-5 w-5 text-amber-600" />
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{animals.length}</p>
                      <p className="text-sm text-gray-500">Total Animals</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <div>
                      <p className="text-2xl font-bold text-green-600">
                        {animals.filter(a => a.healthStatus === 'healthy').length}
                      </p>
                      <p className="text-sm text-gray-500">Healthy</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                    <div>
                      <p className="text-2xl font-bold text-red-600">
                        {animals.filter(a => a.healthStatus === 'sick').length}
                      </p>
                      <p className="text-sm text-gray-500">Sick</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5 text-yellow-600" />
                    <div>
                      <p className="text-2xl font-bold text-yellow-600">
                        {animals.filter(a => a.healthStatus === 'quarantine').length}
                      </p>
                      <p className="text-sm text-gray-500">Quarantine</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Animals Grid */}
            {filteredAnimals.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAnimals.map((animal) => (
                  <Card key={animal.id} className="agro-card hover:shadow-xl transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-amber-100 p-2 rounded-lg">
                            <Tag className="h-5 w-5 text-amber-700" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{animal.tagId}</CardTitle>
                            <p className="text-sm text-gray-500 capitalize">
                              {animal.type} • {animal.gender}
                            </p>
                          </div>
                        </div>
                        <Badge className={getHealthStatusColor(animal.healthStatus)}>
                          {getHealthStatusIcon(animal.healthStatus)}
                          <span className="ml-1 capitalize">{animal.healthStatus}</span>
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {animal.breed && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Breed:</span>
                            <span className="text-sm font-medium">{animal.breed}</span>
                          </div>
                        )}
                        
                        {animal.weight && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Weight:</span>
                            <span className="text-sm font-medium">{animal.weight} kg</span>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500">Age:</span>
                          <span className="text-sm font-medium">{calculateAge(animal.birthDate)}</span>
                        </div>
                        
                        {animal.location && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Location:</span>
                            <span className="text-sm font-medium">{animal.location}</span>
                          </div>
                        )}
                        
                        <Separator />
                        
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => {
                              setSelectedAnimal(animal);
                              setShowViewAnimalDialog(true);
                            }}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button 
                            size="sm" 
                            className="flex-1 agro-button-primary"
                            onClick={() => {
                              setSelectedAnimal(animal);
                              setShowHealthRecordDialog(true);
                            }}
                          >
                            <Stethoscope className="h-4 w-4 mr-1" />
                            Health
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Heart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Animals Found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchQuery || filterStatus !== "all" 
                      ? "Try adjusting your search criteria" 
                      : "Start by registering your first animal"}
                  </p>
                  <Button 
                    onClick={() => setShowAddAnimalDialog(true)}
                    className="agro-button-primary"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Animal
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="health" className="space-y-6">
            {selectedAnimal ? (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Health Records - {selectedAnimal.tagId}</CardTitle>
                        <p className="text-sm text-gray-500">
                          {selectedAnimal.type} • {selectedAnimal.breed}
                        </p>
                      </div>
                      <Button 
                        onClick={() => setShowHealthRecordDialog(true)}
                        className="agro-button-primary"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Record
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {healthRecords.length > 0 ? (
                      <div className="space-y-4">
                        {healthRecords.map((record) => (
                          <div key={record.id} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h4 className="font-medium text-gray-900 capitalize">
                                  {record.recordType}
                                </h4>
                                <p className="text-sm text-gray-600">{record.description}</p>
                              </div>
                              <Badge variant="outline">
                                {formatDate(record.createdAt)}
                              </Badge>
                            </div>
                            {record.veterinarian && (
                              <p className="text-sm text-gray-500">
                                Veterinarian: {record.veterinarian}
                              </p>
                            )}
                            {record.cost && (
                              <p className="text-sm text-gray-500">
                                Cost: UGX {record.cost}
                              </p>
                            )}
                            {record.nextDueDate && (
                              <p className="text-sm text-blue-600">
                                Next due: {formatDate(record.nextDueDate)}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <Stethoscope className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                        <p>No health records found for this animal</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Stethoscope className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select an Animal</h3>
                  <p className="text-gray-500">
                    Choose an animal from the registry to view their health records
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>CCTV Monitoring System</CardTitle>
                    <p className="text-sm text-gray-600">Real-time animal counting and location tracking</p>
                  </div>
                  <Dialog open={showAddCameraDialog} onOpenChange={setShowAddCameraDialog}>
                    <DialogTrigger asChild>
                      <Button className="agro-button-primary">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Camera
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md agro-card">
                      <DialogHeader>
                        <DialogTitle>Connect CCTV Camera</DialogTitle>
                        <DialogDescription>
                          Add a new camera device to your monitoring system
                        </DialogDescription>
                      </DialogHeader>
                      <Form {...cameraForm}>
                        <form onSubmit={cameraForm.handleSubmit(onSubmitCamera)} className="space-y-4">
                          <div className="space-y-4">
                            <div className="flex gap-2">
                              <Button
                                type="button"
                                variant="outline"
                                className="flex-1"
                                onClick={startScanning}
                                disabled={isScanning}
                              >
                                <Scan className={`h-4 w-4 mr-2 ${isScanning ? 'animate-spin' : ''}`} />
                                {isScanning ? "Scanning..." : "Scan QR Code"}
                              </Button>
                            </div>
                            
                            {isScanning && (
                              <Alert>
                                <Camera className="h-4 w-4" />
                                <AlertDescription>
                                  Point your camera at the device QR code to automatically detect the device ID.
                                </AlertDescription>
                              </Alert>
                            )}

                            <FormField
                              control={cameraForm.control}
                              name="deviceId"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Device ID</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Enter device ID manually or scan QR code" 
                                      {...field} 
                                      disabled={isScanning}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={cameraForm.control}
                              name="deviceName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Camera Name</FormLabel>
                                  <FormControl>
                                    <Input placeholder="e.g., Main Pasture Camera" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={cameraForm.control}
                              name="location"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Location</FormLabel>
                                  <FormControl>
                                    <Input placeholder="e.g., Main Pasture, Barn" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />

                            <FormField
                              control={cameraForm.control}
                              name="cameraType"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Camera Type</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select camera type" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="outdoor">Outdoor</SelectItem>
                                      <SelectItem value="indoor">Indoor</SelectItem>
                                      <SelectItem value="barn">Barn</SelectItem>
                                      <SelectItem value="pasture">Pasture</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>

                          <Button 
                            type="submit" 
                            className="w-full agro-button-primary"
                            disabled={addCameraMutation.isPending || isScanning}
                          >
                            {addCameraMutation.isPending ? "Connecting..." : "Connect Camera"}
                          </Button>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-gray-900">Live Camera Feeds</h4>
                      <Badge className="bg-blue-100 text-blue-800">2 Connected</Badge>
                    </div>
                    <div className="grid grid-cols-1 gap-4">
                      <div className="bg-gray-100 rounded-lg p-4 aspect-video flex items-center justify-center border-2 border-green-200">
                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <Camera className="h-12 w-12 text-gray-400" />
                            <div className="ml-2">
                              <Wifi className="h-4 w-4 text-green-600" />
                            </div>
                          </div>
                          <p className="text-sm text-gray-900 font-medium">Main Pasture Camera</p>
                          <p className="text-xs text-gray-500 mb-2">CAM_MP001</p>
                          <Badge className="bg-green-100 text-green-800">Live</Badge>
                          <div className="flex gap-1 mt-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={() => handleViewCamera({id: "CAM_MP001", name: "Main Pasture Camera", location: "Main Pasture"})}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={() => handleConfigureCamera({id: "CAM_MP001", name: "Main Pasture Camera", location: "Main Pasture"})}
                            >
                              <Settings className="h-3 w-3 mr-1" />
                              Config
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div className="bg-gray-100 rounded-lg p-4 aspect-video flex items-center justify-center border-2 border-green-200">
                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <Camera className="h-12 w-12 text-gray-400" />
                            <div className="ml-2">
                              <Wifi className="h-4 w-4 text-green-600" />
                            </div>
                          </div>
                          <p className="text-sm text-gray-900 font-medium">Barn Camera</p>
                          <p className="text-xs text-gray-500 mb-2">CAM_BN002</p>
                          <Badge className="bg-green-100 text-green-800">Live</Badge>
                          <div className="flex gap-1 mt-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={() => handleViewCamera({id: "CAM_BN002", name: "Barn Camera", location: "Barn"})}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={() => handleConfigureCamera({id: "CAM_BN002", name: "Barn Camera", location: "Barn"})}
                            >
                              <Settings className="h-3 w-3 mr-1" />
                              Config
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Animal Count Summary</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium">Main Pasture</span>
                        <div className="text-right">
                          <p className="font-bold text-gray-900">32 animals</p>
                          <p className="text-xs text-green-600">+2 since morning</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium">Barn</span>
                        <div className="text-right">
                          <p className="font-bold text-gray-900">15 animals</p>
                          <p className="text-xs text-gray-500">No change</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium">Quarantine Area</span>
                        <div className="text-right">
                          <p className="font-bold text-gray-900">0 animals</p>
                          <p className="text-xs text-gray-500">No change</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h5 className="font-medium text-blue-900 mb-2">Recent Activity</h5>
                      <div className="space-y-2 text-sm">
                        <p className="text-blue-700">• 2 cows entered main pasture at 14:30</p>
                        <p className="text-blue-700">• 5 sheep moved to barn at 13:15</p>
                        <p className="text-blue-700">• All animals accounted for</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Health Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Healthy Animals</span>
                      <span className="text-lg font-bold text-green-600">
                        {animals.filter(a => a.healthStatus === 'healthy').length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Health Rate</span>
                      <span className="text-lg font-bold text-green-600">
                        {animals.length > 0 ? Math.round((animals.filter(a => a.healthStatus === 'healthy').length / animals.length) * 100) : 0}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Vaccination Due</span>
                      <span className="text-lg font-bold text-yellow-600">2</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Growth Tracking</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Average Weight</span>
                      <span className="text-lg font-bold text-gray-900">
                        {animals.length > 0 ? Math.round(
                          animals.reduce((sum, animal) => sum + (parseFloat(animal.weight || "0")), 0) / animals.length
                        ) : 0} kg
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Weight Gain</span>
                      <span className="text-lg font-bold text-green-600">+5.2%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Feed Efficiency</span>
                      <span className="text-lg font-bold text-blue-600">92%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Breeding Program</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Breeding Age</span>
                      <span className="text-lg font-bold text-gray-900">
                        {animals.filter(a => a.gender === 'female').length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Expected Births</span>
                      <span className="text-lg font-bold text-blue-600">3</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Success Rate</span>
                      <span className="text-lg font-bold text-green-600">87%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Health Record Dialog */}
        <Dialog open={showHealthRecordDialog} onOpenChange={setShowHealthRecordDialog}>
          <DialogContent className="max-w-md agro-card">
            <DialogHeader>
              <DialogTitle>Add Health Record</DialogTitle>
              <DialogDescription>
                Record health information for {selectedAnimal?.tagId || 'the selected animal'}
              </DialogDescription>
            </DialogHeader>
            <Form {...healthForm}>
              <form onSubmit={healthForm.handleSubmit(onSubmitHealthRecord)} className="space-y-4">
                <FormField
                  control={healthForm.control}
                  name="recordType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Record Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="vaccination">Vaccination</SelectItem>
                          <SelectItem value="treatment">Treatment</SelectItem>
                          <SelectItem value="checkup">Checkup</SelectItem>
                          <SelectItem value="injury">Injury</SelectItem>
                          <SelectItem value="birth">Birth</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={healthForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Describe the health record..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={healthForm.control}
                  name="veterinarian"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Veterinarian (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Dr. Smith" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={healthForm.control}
                  name="cost"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cost (Optional) - UGX</FormLabel>
                      <FormControl>
                        <Input placeholder="184,000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full agro-button-primary"
                  disabled={createHealthRecordMutation.isPending}
                >
                  {createHealthRecordMutation.isPending ? "Adding..." : "Add Record"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* View Animal Details Dialog */}
        <Dialog open={showViewAnimalDialog} onOpenChange={setShowViewAnimalDialog}>
          <DialogContent className="max-w-2xl agro-card">
            <DialogHeader>
              <DialogTitle>Animal Details - {selectedAnimal?.tagId}</DialogTitle>
              <DialogDescription>
                Complete information about this animal
              </DialogDescription>
            </DialogHeader>
            
            {selectedAnimal && (
              <div className="space-y-6">
                {/* Basic Information */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center">
                    <Tag className="h-5 w-5 mr-2 text-amber-600" />
                    Basic Information
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Tag ID</p>
                      <p className="font-semibold">{selectedAnimal.tagId}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Type</p>
                      <p className="font-semibold capitalize">{selectedAnimal.type}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Gender</p>
                      <p className="font-semibold capitalize">{selectedAnimal.gender}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Breed</p>
                      <p className="font-semibold">{selectedAnimal.breed || "Not specified"}</p>
                    </div>
                  </div>
                </div>

                {/* Physical Details */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center">
                    <Weight className="h-5 w-5 mr-2 text-blue-600" />
                    Physical Details
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Weight</p>
                      <p className="font-semibold">{selectedAnimal.weight ? `${selectedAnimal.weight} kg` : "Not recorded"}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Age</p>
                      <p className="font-semibold">{calculateAge(selectedAnimal.birthDate)}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Birth Date</p>
                      <p className="font-semibold">{new Date(selectedAnimal.birthDate).toLocaleDateString()}</p>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Registration Date</p>
                      <p className="font-semibold">{new Date(selectedAnimal.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>

                {/* Health & Location */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 flex items-center">
                    <Heart className="h-5 w-5 mr-2 text-red-600" />
                    Health & Location
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Health Status</p>
                      <div className="flex items-center space-x-2">
                        <Badge className={getHealthStatusColor(selectedAnimal.healthStatus)}>
                          {getHealthStatusIcon(selectedAnimal.healthStatus)}
                          <span className="ml-1 capitalize">{selectedAnimal.healthStatus}</span>
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600">Location</p>
                      <p className="font-semibold flex items-center">
                        <MapPin className="h-4 w-4 mr-1 text-gray-500" />
                        {selectedAnimal.location || "Not specified"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Additional Notes */}
                {selectedAnimal.notes && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center">
                      <Activity className="h-5 w-5 mr-2 text-purple-600" />
                      Additional Notes
                    </h3>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-gray-700">{selectedAnimal.notes}</p>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-4 border-t">
                  <Button 
                    className="flex-1 bg-green-700 hover:bg-green-800"
                    onClick={() => {
                      setShowViewAnimalDialog(false);
                      setShowHealthRecordDialog(true);
                    }}
                  >
                    <Stethoscope className="h-4 w-4 mr-2" />
                    Add Health Record
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setShowViewAnimalDialog(false);
                      handleEditAnimal(selectedAnimal);
                    }}
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1 text-red-600 border-red-300 hover:bg-red-50"
                    onClick={() => {
                      setShowViewAnimalDialog(false);
                      handleDeleteAnimal(selectedAnimal);
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setShowViewAnimalDialog(false)}
                  >
                    Close
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* View Camera Dialog */}
        <Dialog open={showViewCameraDialog} onOpenChange={setShowViewCameraDialog}>
          <DialogContent className="max-w-4xl agro-card">
            <DialogHeader>
              <DialogTitle>Live Camera Feed - {selectedCamera?.name}</DialogTitle>
              <DialogDescription>
                Real-time video feed from {selectedCamera?.location}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-black rounded-lg aspect-video flex items-center justify-center relative">
                <div className="absolute top-4 left-4 flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-white text-sm font-medium">LIVE</span>
                </div>
                <div className="text-center text-white">
                  <Camera className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium">{selectedCamera?.name}</p>
                  <p className="text-sm opacity-75">Camera ID: {selectedCamera?.id}</p>
                  <p className="text-sm opacity-75 mt-2">Real-time animal monitoring active</p>
                </div>
                <div className="absolute bottom-4 left-4 text-white text-sm">
                  {new Date().toLocaleTimeString()}
                </div>
                <div className="absolute bottom-4 right-4 flex items-center space-x-2 text-white text-sm">
                  <Wifi className="h-4 w-4 text-green-400" />
                  <span>Strong Signal</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-2">Current Detection</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-gray-600">Animals Detected: <span className="font-medium text-gray-900">24</span></p>
                    <p className="text-gray-600">Motion Activity: <span className="font-medium text-green-600">High</span></p>
                    <p className="text-gray-600">Last Update: <span className="font-medium text-gray-900">2 seconds ago</span></p>
                  </div>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-2">Camera Status</h4>
                  <div className="space-y-1 text-sm">
                    <p className="text-gray-600">Resolution: <span className="font-medium text-gray-900">1080p HD</span></p>
                    <p className="text-gray-600">Frame Rate: <span className="font-medium text-gray-900">30 FPS</span></p>
                    <p className="text-gray-600">Night Vision: <span className="font-medium text-green-600">Active</span></p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowViewCameraDialog(false)}>
                  Close
                </Button>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    setShowViewCameraDialog(false);
                    setShowConfigCameraDialog(true);
                  }}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Configure
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Configure Camera Dialog */}
        <Dialog open={showConfigCameraDialog} onOpenChange={setShowConfigCameraDialog}>
          <DialogContent className="max-w-2xl agro-card">
            <DialogHeader>
              <DialogTitle>Configure Camera - {selectedCamera?.name}</DialogTitle>
              <DialogDescription>
                Adjust camera settings and monitoring parameters
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Basic Settings</h4>
                  
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Camera Name</label>
                      <Input defaultValue={selectedCamera?.name} className="mt-1" />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700">Location</label>
                      <Input defaultValue={selectedCamera?.location} className="mt-1" />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700">Resolution</label>
                      <Select defaultValue="1080p">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="720p">720p HD</SelectItem>
                          <SelectItem value="1080p">1080p Full HD</SelectItem>
                          <SelectItem value="4k">4K Ultra HD</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700">Recording Mode</label>
                      <Select defaultValue="continuous">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="continuous">Continuous</SelectItem>
                          <SelectItem value="motion">Motion Detection</SelectItem>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Detection Settings</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Animal Detection</span>
                      <input type="checkbox" defaultChecked className="h-4 w-4 text-green-600" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Motion Alerts</span>
                      <input type="checkbox" defaultChecked className="h-4 w-4 text-green-600" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Night Vision</span>
                      <input type="checkbox" defaultChecked className="h-4 w-4 text-green-600" />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Audio Recording</span>
                      <input type="checkbox" className="h-4 w-4 text-green-600" />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700">Sensitivity</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="10" 
                        defaultValue="7" 
                        className="w-full mt-1"
                      />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>Low</span>
                        <span>High</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Storage & Alerts</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Storage Duration</label>
                    <Select defaultValue="30days">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7days">7 Days</SelectItem>
                        <SelectItem value="30days">30 Days</SelectItem>
                        <SelectItem value="90days">90 Days</SelectItem>
                        <SelectItem value="unlimited">Unlimited</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700">Alert Method</label>
                    <Select defaultValue="app">
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="app">App Notification</SelectItem>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="sms">SMS</SelectItem>
                        <SelectItem value="all">All Methods</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowConfigCameraDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={() => {
                    setShowConfigCameraDialog(false);
                    toast({
                      title: "Camera Updated",
                      description: `Settings for ${selectedCamera?.name} have been saved.`,
                    });
                  }}
                >
                  Save Settings
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Animal Dialog */}
        <Dialog open={showEditAnimalDialog} onOpenChange={setShowEditAnimalDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Edit className="h-5 w-5 mr-2 text-blue-600" />
                Edit Animal Details
              </DialogTitle>
              <DialogDescription>
                Update the information for {selectedAnimal?.tagId}
              </DialogDescription>
            </DialogHeader>

            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onSubmitEditAnimal)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="tagId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tag ID</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., C001, S005" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Animal Type</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., cow, sheep, goat" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="breed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Breed</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Ankole, Friesian" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Gender</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="weight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Weight (kg)</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="e.g., 350" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="birthDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Birth Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editForm.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Pasture A, Barn 2" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={editForm.control}
                    name="healthStatus"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Health Status</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select health status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="healthy">Healthy</SelectItem>
                            <SelectItem value="sick">Sick</SelectItem>
                            <SelectItem value="quarantine">Quarantine</SelectItem>
                            <SelectItem value="treatment">Under Treatment</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={editForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Additional notes about the animal..."
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowEditAnimalDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-green-600 hover:bg-green-700"
                    disabled={editAnimalMutation.isPending}
                  >
                    {editAnimalMutation.isPending ? "Updating..." : "Update Animal"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Delete Animal Dialog */}
        <Dialog open={showDeleteAnimalDialog} onOpenChange={setShowDeleteAnimalDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center text-red-600">
                <Trash2 className="h-5 w-5 mr-2" />
                Remove Animal from Farm
              </DialogTitle>
              <DialogDescription>
                This will remove {selectedAnimal?.tagId} from your active animal records and add to farm bookkeeping.
              </DialogDescription>
            </DialogHeader>

            <Form {...deleteForm}>
              <form onSubmit={deleteForm.handleSubmit(onSubmitDeleteAnimal)} className="space-y-4">
                <FormField
                  control={deleteForm.control}
                  name="deletionReason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reason for Removal</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select reason" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sold">Sold</SelectItem>
                          <SelectItem value="deceased">Deceased</SelectItem>
                          <SelectItem value="transferred">Transferred</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {deleteForm.watch("deletionReason") === "sold" && (
                  <>
                    <FormField
                      control={deleteForm.control}
                      name="salePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sale Price (UGX)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="e.g., 1500000" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={deleteForm.control}
                      name="buyerInfo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Buyer Information</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Buyer name and contact" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </>
                )}

                {deleteForm.watch("deletionReason") === "deceased" && (
                  <FormField
                    control={deleteForm.control}
                    name="causeOfDeath"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cause of Death</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g., disease, accident, old age" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}

                <FormField
                  control={deleteForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any additional information..."
                          className="min-h-[60px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowDeleteAnimalDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    variant="destructive"
                    disabled={deleteAnimalMutation.isPending}
                  >
                    {deleteAnimalMutation.isPending ? "Removing..." : "Remove Animal"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </main>

      <MobileNav />
    </div>
  );
}
