import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  Sprout, 
  Search, 
  Book, 
  PlayCircle, 
  Download, 
  ExternalLink,
  ArrowLeft,
  TrendingUp,
  Store,
  Heart,
  Settings,
  Smartphone,
  Code,
  MessageCircle,
  Clock
} from "lucide-react";

export default function Documentation() {
  const [searchQuery, setSearchQuery] = useState("");

  const quickStartGuides = [
    {
      title: "Getting Started with AgroSet",
      description: "Complete setup guide for new users",
      duration: "15 min",
      icon: Sprout,
      category: "Basics"
    },
    {
      title: "Setting up Soil Sensors",
      description: "Hardware installation and configuration",
      duration: "30 min",
      icon: TrendingUp,
      category: "AgroSoil"
    },
    {
      title: "Creating Market Listings",
      description: "How to sell your produce online",
      duration: "10 min",
      icon: Store,
      category: "AgroMarket"
    },
    {
      title: "Animal Health Tracking",
      description: "Monitor and manage livestock health",
      duration: "20 min",
      icon: Heart,
      category: "AgroAnimal"
    }
  ];

  const apiDocuments = [
    {
      title: "REST API Reference",
      description: "Complete API documentation with examples",
      type: "API",
      updated: "2 days ago"
    },
    {
      title: "Webhook Integration",
      description: "Real-time data notifications setup",
      type: "Integration",
      updated: "1 week ago"
    },
    {
      title: "Mobile SDK",
      description: "Build custom mobile applications",
      type: "SDK",
      updated: "3 days ago"
    },
    {
      title: "Data Export Formats",
      description: "Export your farm data in various formats",
      type: "Data",
      updated: "1 day ago"
    }
  ];

  const videoTutorials = [
    {
      title: "AgroSet Platform Overview",
      description: "Complete walkthrough of all features",
      duration: "12:30",
      views: "5.2K",
      category: "Overview"
    },
    {
      title: "Installing IoT Sensors",
      description: "Step-by-step hardware setup",
      duration: "8:45",
      views: "3.1K",
      category: "Hardware"
    },
    {
      title: "Reading Soil Analytics",
      description: "Understanding your soil data",
      duration: "6:20",
      views: "4.8K",
      category: "Analytics"
    },
    {
      title: "Marketplace Best Practices",
      description: "Maximize your sales potential",
      duration: "10:15",
      views: "2.9K",
      category: "Marketing"
    }
  ];

  const troubleshooting = [
    {
      issue: "Sensor not connecting",
      solution: "Check WiFi settings and power supply",
      category: "Hardware"
    },
    {
      issue: "Data not updating",
      solution: "Verify internet connection and sensor placement",
      category: "Data"
    },
    {
      issue: "Login issues",
      solution: "Reset password or clear browser cache",
      category: "Account"
    },
    {
      issue: "Payment not processing",
      solution: "Check Mobile Money balance or try alternative method",
      category: "Billing"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/welcome">
              <button className="flex items-center space-x-2 group">
                <ArrowLeft className="h-5 w-5 text-gray-600 group-hover:text-green-700 transition-colors" />
                <div className="flex items-center space-x-2">
                  <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
                    <Sprout className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                    AgroSet
                  </span>
                </div>
              </button>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="hover:bg-green-50 hover:border-green-300">
                  Login
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
              <Book className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
              Documentation
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Everything you need to know about using AgroSet to transform your farming operations
          </p>

          {/* Search */}
          <div className="max-w-lg mx-auto mb-8">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search documentation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="px-4 sm:px-6 lg:px-8 pb-20">
        <div className="max-w-7xl mx-auto">
          <Tabs defaultValue="guides" className="space-y-8">
            <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto">
              <TabsTrigger value="guides">Quick Start</TabsTrigger>
              <TabsTrigger value="api">API Docs</TabsTrigger>
              <TabsTrigger value="videos">Videos</TabsTrigger>
              <TabsTrigger value="troubleshooting">Help</TabsTrigger>
            </TabsList>

            {/* Quick Start Guides */}
            <TabsContent value="guides" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Quick Start Guides</h2>
                <p className="text-lg text-gray-600">Get up and running quickly with step-by-step guides</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {quickStartGuides.map((guide, index) => (
                  <Card key={index} className="agro-card hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-lg bg-green-100">
                          <guide.icon className="h-6 w-6 text-green-700" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-gray-900">{guide.title}</h3>
                            <Badge variant="outline">{guide.category}</Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{guide.description}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2 text-sm text-gray-500">
                              <Clock className="h-4 w-4" />
                              <span>{guide.duration}</span>
                            </div>
                            <Button variant="ghost" size="sm">
                              Read Guide
                              <ExternalLink className="ml-1 h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* API Documentation */}
            <TabsContent value="api" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">API Documentation</h2>
                <p className="text-lg text-gray-600">Integrate AgroSet with your custom applications</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {apiDocuments.map((doc, index) => (
                  <Card key={index} className="agro-card hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 rounded-lg bg-blue-100">
                            <Code className="h-5 w-5 text-blue-700" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{doc.title}</h3>
                            <p className="text-sm text-gray-600">{doc.description}</p>
                          </div>
                        </div>
                        <Badge variant="outline">{doc.type}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Updated {doc.updated}</span>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="ghost" size="sm">
                            View
                            <ExternalLink className="ml-1 h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Video Tutorials */}
            <TabsContent value="videos" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Video Tutorials</h2>
                <p className="text-lg text-gray-600">Learn through visual step-by-step tutorials</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {videoTutorials.map((video, index) => (
                  <Card key={index} className="agro-card hover:shadow-lg transition-shadow cursor-pointer group">
                    <CardContent className="p-0">
                      <div className="relative bg-gradient-to-br from-green-400 to-emerald-500 h-48 rounded-t-lg flex items-center justify-center">
                        <PlayCircle className="h-16 w-16 text-white group-hover:scale-110 transition-transform" />
                        <div className="absolute top-3 right-3">
                          <Badge className="bg-black/70 text-white">{video.duration}</Badge>
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="outline" className="text-xs">{video.category}</Badge>
                          <span className="text-xs text-gray-500">{video.views} views</span>
                        </div>
                        <h3 className="font-semibold text-gray-900 mb-2">{video.title}</h3>
                        <p className="text-sm text-gray-600">{video.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Troubleshooting */}
            <TabsContent value="troubleshooting" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Troubleshooting</h2>
                <p className="text-lg text-gray-600">Common issues and solutions</p>
              </div>

              <div className="max-w-4xl mx-auto space-y-4">
                {troubleshooting.map((item, index) => (
                  <Card key={index} className="agro-card">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Badge variant="outline">{item.category}</Badge>
                            <h3 className="font-semibold text-gray-900">{item.issue}</h3>
                          </div>
                          <p className="text-gray-600">{item.solution}</p>
                        </div>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="text-center mt-12">
                <p className="text-gray-600 mb-4">Still need help?</p>
                <div className="flex justify-center space-x-4">
                  <Link href="/contact">
                    <Button variant="outline">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Contact Support
                    </Button>
                  </Link>
                  <Link href="/help">
                    <Button className="bg-green-600 hover:bg-green-700">
                      Visit Help Center
                    </Button>
                  </Link>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}