import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { 
  TrendingUp, 
  Store, 
  Heart, 
  Droplets, 
  Thermometer, 
  Activity,
  CheckCircle,
  AlertTriangle,
  Calendar,
  Plus,
  BarChart3,
  CalendarPlus
} from "lucide-react";
import Header from "@/components/header";
import MobileNav from "@/components/mobile-nav";
import TrialBanner from "@/components/trial-banner";
import SoilChart from "@/components/soil-chart";
import WeatherWidget from "@/components/weather-widget";
import NotificationCenter from "@/components/notification-center";
import { Link, useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { SoilReading, Animal, MarketListing, Notification } from "@shared/schema";

interface DashboardSummary {
  soil: {
    fieldA?: SoilReading;
    fieldB?: SoilReading;
  };
  animals: {
    total: number;
    healthy: number;
  };
  market: {
    activeListings: number;
    totalListings: number;
  };
  notifications: {
    unread: number;
    latest: Notification[];
  };
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [irrigationDialogOpen, setIrrigationDialogOpen] = useState(false);
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [selectedField, setSelectedField] = useState("");
  const [irrigationDuration, setIrrigationDuration] = useState("");
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDescription, setTaskDescription] = useState("");
  const [taskDate, setTaskDate] = useState("");
  const [taskCategory, setTaskCategory] = useState("");
  const [selectedSoilMetric, setSelectedSoilMetric] = useState<"moisture" | "ph" | "nitrogen">("moisture");

  const { data: summary, isLoading } = useQuery<DashboardSummary>({
    queryKey: ["/api/dashboard/summary"],
  });

  const { data: soilReadings = [] } = useQuery<SoilReading[]>({
    queryKey: ["/api/soil/readings"],
  });

  // Start Irrigation Mutation
  const startIrrigationMutation = useMutation({
    mutationFn: async (data: { fieldId: string; duration: string }) => {
      return apiRequest("POST", "/api/irrigation/start", {
        userId: 1,
        fieldId: data.fieldId,
        type: "manual",
        duration: parseInt(data.duration),
        waterAmount: 500,
        triggeredBy: "user",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/irrigation"] });
      setIrrigationDialogOpen(false);
      setSelectedField("");
      setIrrigationDuration("");
      toast({
        title: "Irrigation Started",
        description: `Manual irrigation started for ${selectedField}`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start irrigation. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Schedule Task Mutation
  const scheduleTaskMutation = useMutation({
    mutationFn: async (data: { title: string; description: string; category: string; date: string }) => {
      return apiRequest("POST", "/api/notifications", {
        userId: 1,
        title: data.title,
        message: data.description,
        type: "info",
        category: data.category,
        read: false,
        actionUrl: null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      setTaskDialogOpen(false);
      setTaskTitle("");
      setTaskDescription("");
      setTaskDate("");
      setTaskCategory("");
      toast({
        title: "Task Scheduled",
        description: "Your farm task has been scheduled successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to schedule task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartIrrigation = () => {
    if (!selectedField || !irrigationDuration) {
      toast({
        title: "Missing Information",
        description: "Please select a field and duration.",
        variant: "destructive",
      });
      return;
    }
    startIrrigationMutation.mutate({ fieldId: selectedField, duration: irrigationDuration });
  };

  const handleScheduleTask = () => {
    if (!taskTitle || !taskDescription || !taskCategory) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    scheduleTaskMutation.mutate({ 
      title: taskTitle, 
      description: taskDescription, 
      category: taskCategory,
      date: taskDate 
    });
  };

  const handleListProduce = () => {
    navigate("/market");
  };

  const handleViewReports = () => {
    navigate("/soil");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-64 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </main>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 pb-20 md:pb-6">
        {/* Trial Status Banner */}
        <TrialBanner />

        {/* Welcome Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                Welcome back, John!
              </h1>
              <p className="text-gray-600 mt-2">Here's what's happening on your farm today</p>
            </div>
            <div className="text-right bg-white/60 backdrop-blur-sm rounded-xl px-4 py-3 border border-green-100 shadow-sm">
              <p className="text-sm text-gray-500">Last updated</p>
              <p className="text-lg font-semibold text-green-700">
                {new Date().toLocaleTimeString()}
              </p>
            </div>
          </div>
        </div>

        {/* Alert Section */}
        {summary?.notifications.latest && summary.notifications.latest.length > 0 && (
          <div className="mb-6 space-y-3">
            {summary.notifications.latest.slice(0, 2).map((notification) => (
              <Alert 
                key={notification.id}
                className={`${
                  notification.type === "warning" 
                    ? "bg-yellow-50 border-yellow-200" 
                    : "bg-green-50 border-green-200"
                }`}
              >
                {notification.type === "warning" ? (
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                ) : (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                )}
                <AlertDescription>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className={`font-medium ${
                        notification.type === "warning" ? "text-yellow-800" : "text-green-800"
                      }`}>
                        {notification.title}
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {notification.message}
                      </p>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            ))}
          </div>
        )}

        {/* Module Overview Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* AgroSoil Card */}
          <Card className="agro-card hover:shadow-xl transition-all duration-300">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-green-700" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">AgroSoil</CardTitle>
                    <p className="text-sm text-gray-500">Soil monitoring & irrigation</p>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {/* Quick Metrics */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-gray-900">
                    {summary?.soil.fieldA ? Math.round(parseFloat(summary.soil.fieldA.moisture)) : 0}%
                  </div>
                  <div className="text-xs text-gray-500">Moisture</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-gray-900">
                    {summary?.soil.fieldA ? parseFloat(summary.soil.fieldA.ph).toFixed(1) : 0}
                  </div>
                  <div className="text-xs text-gray-500">pH Level</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-gray-900">
                    {summary?.soil.fieldA ? Math.round(parseFloat(summary.soil.fieldA.temperature)) : 0}°C
                  </div>
                  <div className="text-xs text-gray-500">Temperature</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-gray-900">Good</div>
                  <div className="text-xs text-gray-500">NPK Status</div>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <div className="flex items-start space-x-2">
                  <Activity className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900">AI Recommendation</h4>
                    <p className="text-sm text-blue-700">
                      Apply 15kg/ha of NPK fertilizer. Schedule irrigation for tomorrow morning.
                    </p>
                  </div>
                </div>
              </div>

              <Link href="/soil">
                <Button className="w-full bg-green-700 hover:bg-green-800 text-white">
                  View Detailed Analytics
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* AgroMarket Card */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Store className="h-6 w-6 text-blue-700" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">AgroMarket</CardTitle>
                    <p className="text-sm text-gray-500">Marketplace & pricing</p>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {/* Market Summary */}
              <div className="space-y-3 mb-4">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                      🍅
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">Tomatoes</div>
                      <div className="text-sm text-gray-500">Local market</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-600">UGX 16,800/kg</div>
                    <div className="text-xs text-green-600">↑ 15%</div>
                  </div>
                </div>

                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      🌽
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">Corn</div>
                      <div className="text-sm text-gray-500">Regional market</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-900">UGX 10,400/kg</div>
                    <div className="text-xs text-gray-500">→ 0%</div>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <div className="text-sm">
                  <span className="font-medium text-green-900">
                    {summary?.market.activeListings || 0} active listings
                  </span>
                  <span className="text-green-700"> • 12 buyer inquiries</span>
                </div>
              </div>

              <Link href="/market">
                <Button className="w-full bg-blue-700 hover:bg-blue-800 text-white">
                  Open Marketplace
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* AgroAnimal Card */}
          <Card className="hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-amber-100 p-3 rounded-lg">
                    <Heart className="h-6 w-6 text-amber-700" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">AgroAnimal</CardTitle>
                    <p className="text-sm text-gray-500">Livestock management</p>
                  </div>
                </div>
                <Badge className="bg-green-100 text-green-800">Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {/* Animal Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-gray-900">
                    {summary?.animals.total || 0}
                  </div>
                  <div className="text-xs text-gray-500">Total Animals</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {summary?.animals.healthy || 0}
                  </div>
                  <div className="text-xs text-gray-500">Healthy</div>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Cow #A001 - Vaccinated</span>
                  <span className="text-green-600">✓</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">5 calves entered pasture</span>
                  <span className="text-gray-400">2h ago</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Health check reminder</span>
                  <span className="text-yellow-600">!</span>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
                <div className="text-sm text-amber-900">
                  <Calendar className="h-4 w-4 inline mr-2" />
                  2 animals due for vaccination next week
                </div>
              </div>

              <Link href="/animal">
                <Button className="w-full bg-amber-700 hover:bg-amber-800 text-white">
                  Manage Livestock
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Soil Monitoring Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Soil Conditions (7-Day Trend)</CardTitle>
                <div className="flex space-x-2">
                  <Button 
                    size="sm" 
                    variant={selectedSoilMetric === "moisture" ? "default" : "outline"}
                    className={`text-xs transition-all duration-200 ${
                      selectedSoilMetric === "moisture" 
                        ? "bg-green-700 hover:bg-green-800" 
                        : "hover:bg-green-50 hover:text-green-700 hover:border-green-300"
                    }`}
                    onClick={() => setSelectedSoilMetric("moisture")}
                  >
                    Moisture
                  </Button>
                  <Button 
                    size="sm" 
                    variant={selectedSoilMetric === "ph" ? "default" : "outline"}
                    className={`text-xs transition-all duration-200 ${
                      selectedSoilMetric === "ph" 
                        ? "bg-green-700 hover:bg-green-800" 
                        : "hover:bg-green-50 hover:text-green-700 hover:border-green-300"
                    }`}
                    onClick={() => setSelectedSoilMetric("ph")}
                  >
                    pH
                  </Button>
                  <Button 
                    size="sm" 
                    variant={selectedSoilMetric === "nitrogen" ? "default" : "outline"}
                    className={`text-xs transition-all duration-200 ${
                      selectedSoilMetric === "nitrogen" 
                        ? "bg-green-700 hover:bg-green-800" 
                        : "hover:bg-green-50 hover:text-green-700 hover:border-green-300"
                    }`}
                    onClick={() => setSelectedSoilMetric("nitrogen")}
                  >
                    NPK
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {soilReadings.length > 0 ? (
                <SoilChart readings={soilReadings.slice(-7)} metric={selectedSoilMetric} />
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-500">
                  No soil data available
                </div>
              )}
            </CardContent>
          </Card>

          {/* Weather Widget */}
          <WeatherWidget />
        </div>

        {/* Bottom Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Field Management */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Field Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Field A - Tomatoes</div>
                    <div className="text-sm text-gray-500">2.5 hectares</div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Healthy</Badge>
                </div>
                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Field B - Corn</div>
                    <div className="text-sm text-gray-500">3.2 hectares</div>
                  </div>
                  <Badge className="bg-yellow-100 text-yellow-800">Needs Water</Badge>
                </div>
                <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Field C - Wheat</div>
                    <div className="text-sm text-gray-500">1.8 hectares</div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">Optimal</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Activities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <Droplets className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Irrigation Completed</div>
                    <div className="text-sm text-gray-500">Field A irrigated automatically</div>
                    <div className="text-xs text-gray-400">2 hours ago</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <Store className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Sale Completed</div>
                    <div className="text-sm text-gray-500">50kg tomatoes sold to buyer</div>
                    <div className="text-xs text-gray-400">5 hours ago</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="bg-amber-100 p-2 rounded-lg">
                    <Heart className="h-4 w-4 text-amber-600" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">Vaccination Reminder</div>
                    <div className="text-sm text-gray-500">3 cattle due for vaccination</div>
                    <div className="text-xs text-gray-400">1 day ago</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {/* Start Irrigation */}
                <Dialog open={irrigationDialogOpen} onOpenChange={setIrrigationDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full justify-start">
                      <div className="bg-blue-100 p-2 rounded-lg mr-3">
                        <Droplets className="h-4 w-4 text-blue-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium text-gray-900">Start Irrigation</div>
                        <div className="text-sm text-gray-500">Manual irrigation control</div>
                      </div>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Start Manual Irrigation</DialogTitle>
                      <DialogDescription>
                        Select a field and set irrigation duration to start manual watering.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="field">Select Field</Label>
                        <Select value={selectedField} onValueChange={setSelectedField}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a field" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="field_a">Field A - Tomatoes</SelectItem>
                            <SelectItem value="field_b">Field B - Corn</SelectItem>
                            <SelectItem value="field_c">Field C - Wheat</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="duration">Duration (minutes)</Label>
                        <Input
                          id="duration"
                          type="number"
                          placeholder="30"
                          value={irrigationDuration}
                          onChange={(e) => setIrrigationDuration(e.target.value)}
                        />
                      </div>
                      <Button 
                        onClick={handleStartIrrigation}
                        disabled={startIrrigationMutation.isPending}
                        className="w-full"
                      >
                        {startIrrigationMutation.isPending ? "Starting..." : "Start Irrigation"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                {/* List Produce */}
                <Button variant="outline" className="w-full justify-start" onClick={handleListProduce}>
                  <div className="bg-green-100 p-2 rounded-lg mr-3">
                    <Plus className="h-4 w-4 text-green-600" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-gray-900">List Produce</div>
                    <div className="text-sm text-gray-500">Add to marketplace</div>
                  </div>
                </Button>

                {/* View Reports */}
                <Button variant="outline" className="w-full justify-start" onClick={handleViewReports}>
                  <div className="bg-purple-100 p-2 rounded-lg mr-3">
                    <BarChart3 className="h-4 w-4 text-purple-600" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium text-gray-900">View Reports</div>
                    <div className="text-sm text-gray-500">Detailed analytics</div>
                  </div>
                </Button>

                {/* Schedule Task */}
                <Dialog open={taskDialogOpen} onOpenChange={setTaskDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full justify-start">
                      <div className="bg-orange-100 p-2 rounded-lg mr-3">
                        <CalendarPlus className="h-4 w-4 text-orange-600" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium text-gray-900">Schedule Task</div>
                        <div className="text-sm text-gray-500">Add farm activity</div>
                      </div>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Schedule Farm Task</DialogTitle>
                      <DialogDescription>
                        Create a new farm task with details and schedule it for completion.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="task-title">Task Title</Label>
                        <Input
                          id="task-title"
                          placeholder="Apply fertilizer to Field A"
                          value={taskTitle}
                          onChange={(e) => setTaskTitle(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-description">Description</Label>
                        <Textarea
                          id="task-description"
                          placeholder="Describe the task details..."
                          value={taskDescription}
                          onChange={(e) => setTaskDescription(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-category">Category</Label>
                        <Select value={taskCategory} onValueChange={setTaskCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="soil">Soil Management</SelectItem>
                            <SelectItem value="irrigation">Irrigation</SelectItem>
                            <SelectItem value="fertilizer">Fertilizer</SelectItem>
                            <SelectItem value="pest">Pest Control</SelectItem>
                            <SelectItem value="harvest">Harvest</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="task-date">Due Date (Optional)</Label>
                        <Input
                          id="task-date"
                          type="date"
                          value={taskDate}
                          onChange={(e) => setTaskDate(e.target.value)}
                        />
                      </div>
                      <Button 
                        onClick={handleScheduleTask}
                        disabled={scheduleTaskMutation.isPending}
                        className="w-full"
                      >
                        {scheduleTaskMutation.isPending ? "Scheduling..." : "Schedule Task"}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <MobileNav />
    </div>
  );
}
