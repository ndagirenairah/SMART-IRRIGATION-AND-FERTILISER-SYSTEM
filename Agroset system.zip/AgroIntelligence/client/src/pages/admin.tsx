import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  Users, 
  DollarSign, 
  CreditCard, 
  Activity, 
  Shield, 
  Settings as SettingsIcon, 
  FileText,
  Eye,
  Edit,
  CheckCircle,
  XCircle,
  Calendar
} from 'lucide-react';
import { User, Payment, Subscription, AdminLog, SystemSetting } from '@shared/schema';

interface AdminStats {
  totalUsers: number;
  totalPayments: number;
  totalRevenue: number;
  activeSubscriptions: number;
  recentActivity: number;
}

interface AdminData {
  stats: AdminStats;
  recentLogs: AdminLog[];
}

export default function AdminPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authToken, setAuthToken] = useState<string>('');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [editingUser, setEditingUser] = useState<Partial<User>>({});
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Check if already authenticated
  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (token) {
      setAuthToken(token);
      setIsAuthenticated(true);
    }
  }, []);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string }) => {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
        headers: { 'Content-Type': 'application/json' }
      });
      if (!response.ok) throw new Error('Login failed');
      return response.json();
    },
    onSuccess: (data: any) => {
      setAuthToken(data.token);
      setIsAuthenticated(true);
      localStorage.setItem('adminToken', data.token);
      toast({ title: 'Login successful', description: 'Welcome to admin panel' });
    },
    onError: () => {
      toast({ title: 'Login failed', description: 'Invalid credentials', variant: 'destructive' });
    },
  });

  // Fetch admin dashboard data
  const { data: adminData, isLoading: adminLoading } = useQuery<AdminData>({
    queryKey: ['/api/admin/dashboard'],
    queryFn: async () => {
      const response = await fetch('/api/admin/dashboard', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch dashboard data');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch users
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const response = await fetch('/api/admin/users', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch payments
  const { data: payments, isLoading: paymentsLoading } = useQuery<Payment[]>({
    queryKey: ['/api/admin/payments'],
    queryFn: async () => {
      const response = await fetch('/api/admin/payments', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch payments');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch subscriptions
  const { data: subscriptions, isLoading: subscriptionsLoading } = useQuery<Subscription[]>({
    queryKey: ['/api/admin/subscriptions'],
    queryFn: async () => {
      const response = await fetch('/api/admin/subscriptions', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch subscriptions');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch admin logs
  const { data: logs, isLoading: logsLoading } = useQuery<AdminLog[]>({
    queryKey: ['/api/admin/logs'],
    queryFn: async () => {
      const response = await fetch('/api/admin/logs', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch logs');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch system settings
  const { data: systemSettings, isLoading: settingsLoading } = useQuery<SystemSetting[]>({
    queryKey: ['/api/admin/settings'],
    queryFn: async () => {
      const response = await fetch('/api/admin/settings', {
        headers: { 'Authorization': `Basic ${authToken}` }
      });
      if (!response.ok) throw new Error('Failed to fetch settings');
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, updates }: { userId: number; updates: Partial<User> }) => {
      const response = await fetch(`/api/admin/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(updates),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Basic ${authToken}`
        }
      });
      if (!response.ok) throw new Error('Failed to update user');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/dashboard'] });
      setSelectedUser(null);
      toast({ title: 'Success', description: 'User updated successfully' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to update user', variant: 'destructive' });
    },
  });

  // Update system setting mutation
  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: string }) => {
      const response = await fetch(`/api/admin/settings/${key}`, {
        method: 'PUT',
        body: JSON.stringify({ value }),
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Basic ${authToken}`
        }
      });
      if (!response.ok) throw new Error('Failed to update setting');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/settings'] });
      toast({ title: 'Success', description: 'System setting updated successfully' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to update setting', variant: 'destructive' });
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(loginForm);
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    setIsAuthenticated(false);
    setAuthToken('');
    setLoginForm({ email: '', password: '' });
  };

  const formatCurrency = (amount: number | string) => {
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const formatDate = (date: string | Date) => {
    return new Intl.DateTimeFormat('en-UG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(new Date(date));
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">
              <Shield className="w-8 h-8 mx-auto mb-2" />
              Admin Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
                {loginMutation.isPending ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              System Administration
            </h1>
            <p className="text-gray-600">Manage users, payments, and system settings</p>
          </div>
          <Button onClick={handleLogout} variant="outline">
            Logout
          </Button>
        </div>

        {/* Stats Overview */}
        {adminData && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="text-sm text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold">{adminData.stats.totalUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <CreditCard className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="text-sm text-gray-600">Total Payments</p>
                    <p className="text-2xl font-bold">{adminData.stats.totalPayments}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <DollarSign className="w-5 h-5 text-yellow-500" />
                  <div>
                    <p className="text-sm text-gray-600">Total Revenue</p>
                    <p className="text-2xl font-bold">{formatCurrency(adminData.stats.totalRevenue)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-purple-500" />
                  <div>
                    <p className="text-sm text-gray-600">Active Subscriptions</p>
                    <p className="text-2xl font-bold">{adminData.stats.activeSubscriptions}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-600">Recent Activity</p>
                    <p className="text-2xl font-bold">{adminData.stats.recentActivity}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content */}
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="settings">System Settings</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="logs">Activity Logs</TabsTrigger>
          </TabsList>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <p>Loading users...</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Farm Size</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users?.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>{user.id}</TableCell>
                          <TableCell>{user.firstName} {user.lastName}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.location || 'Not specified'}</TableCell>
                          <TableCell>{user.farmSize ? `${user.farmSize} acres` : 'Not specified'}</TableCell>
                          <TableCell>{formatDate(user.createdAt)}</TableCell>
                          <TableCell>
                            <Badge variant={user.subscriptionRequired ? 'destructive' : 'default'}>
                              {user.subscriptionRequired ? 'Trial Ended' : 'Trial Active'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedUser(user);
                                  setEditingUser(user);
                                }}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  updateUserMutation.mutate({
                                    userId: user.id,
                                    updates: { subscriptionRequired: !user.subscriptionRequired }
                                  });
                                }}
                              >
                                {user.subscriptionRequired ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Payment Management</CardTitle>
              </CardHeader>
              <CardContent>
                {paymentsLoading ? (
                  <p>Loading payments...</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>User ID</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payments?.map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell className="font-mono">{payment.transactionId}</TableCell>
                          <TableCell>{payment.userId}</TableCell>
                          <TableCell>{formatCurrency(payment.amount)}</TableCell>
                          <TableCell>
                            <Badge variant={payment.status === 'COMPLETED' ? 'default' : payment.status === 'PENDING' ? 'secondary' : 'destructive'}>
                              {payment.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{payment.description}</TableCell>
                          <TableCell>{formatDate(payment.createdAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Subscriptions Tab */}
          <TabsContent value="subscriptions">
            <Card>
              <CardHeader>
                <CardTitle>Subscription Management</CardTitle>
              </CardHeader>
              <CardContent>
                {subscriptionsLoading ? (
                  <p>Loading subscriptions...</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>User ID</TableHead>
                        <TableHead>Plan</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Start Date</TableHead>
                        <TableHead>End Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subscriptions?.map((sub) => (
                        <TableRow key={sub.id}>
                          <TableCell>{sub.id}</TableCell>
                          <TableCell>{sub.userId}</TableCell>
                          <TableCell className="capitalize">{sub.planType}</TableCell>
                          <TableCell>
                            <Badge variant={sub.status === 'active' ? 'default' : 'secondary'}>
                              {sub.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{formatDate(sub.startDate)}</TableCell>
                          <TableCell>{formatDate(sub.endDate)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
                <p className="text-sm text-gray-600">Configure system-wide settings and parameters</p>
              </CardHeader>
              <CardContent>
                {settingsLoading ? (
                  <p>Loading settings...</p>
                ) : (
                  <div className="space-y-6">
                    {systemSettings?.map((setting) => (
                      <div key={setting.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-semibold">{setting.key}</h4>
                            <p className="text-sm text-gray-600">{setting.description}</p>
                            <Badge variant="outline" className="mt-1">{setting.category}</Badge>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                          {setting.key === 'maintenance_mode' ? (
                            <div className="flex items-center space-x-2">
                              <Button
                                variant={setting.value === 'true' ? 'destructive' : 'default'}
                                size="sm"
                                onClick={() => updateSettingMutation.mutate({
                                  key: setting.key,
                                  value: setting.value === 'true' ? 'false' : 'true'
                                })}
                                disabled={updateSettingMutation.isPending}
                              >
                                {setting.value === 'true' ? 'Disable Maintenance' : 'Enable Maintenance'}
                              </Button>
                              <span className="text-sm text-gray-600">
                                Currently: {setting.value === 'true' ? 'ON' : 'OFF'}
                              </span>
                            </div>
                          ) : (
                            <div className="flex gap-2">
                              <Input
                                value={setting.value}
                                onChange={(e) => {
                                  updateSettingMutation.mutate({
                                    key: setting.key,
                                    value: e.target.value
                                  });
                                }}
                                className="max-w-xs"
                              />
                            </div>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 mt-2">
                          Last updated: {formatDate(setting.updatedAt)} by {setting.updatedBy}
                        </div>
                      </div>
                    ))}
                    
                    {/* Quick Actions */}
                    <div className="border-t pt-6">
                      <h4 className="font-semibold mb-4">Quick System Actions</h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Button 
                          variant="outline" 
                          className="flex flex-col items-center p-4 h-auto"
                          onClick={() => {
                            queryClient.invalidateQueries();
                            toast({ title: 'Cache Cleared', description: 'System cache has been refreshed' });
                          }}
                        >
                          <Activity className="w-6 h-6 mb-2" />
                          Refresh Cache
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          className="flex flex-col items-center p-4 h-auto"
                          onClick={() => {
                            updateSettingMutation.mutate({
                              key: 'maintenance_mode',
                              value: 'true'
                            });
                          }}
                        >
                          <Shield className="w-6 h-6 mb-2" />
                          Maintenance Mode
                        </Button>

                        <Button 
                          variant="outline" 
                          className="flex flex-col items-center p-4 h-auto"
                          onClick={() => {
                            queryClient.invalidateQueries({ queryKey: ['/api/admin/dashboard'] });
                            toast({ title: 'Data Refreshed', description: 'Dashboard data updated' });
                          }}
                        >
                          <FileText className="w-6 h-6 mb-2" />
                          Refresh Data
                        </Button>

                        <Button 
                          variant="outline" 
                          className="flex flex-col items-center p-4 h-auto"
                          onClick={() => {
                            toast({ title: 'System Check', description: 'All systems operational', });
                          }}
                        >
                          <CheckCircle className="w-6 h-6 mb-2" />
                          System Check
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Monitoring Tab */}
          <TabsContent value="monitoring">
            <Card>
              <CardHeader>
                <CardTitle>System Monitoring</CardTitle>
                <p className="text-sm text-gray-600">Real-time system status and performance metrics</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* System Health */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">Database Status</p>
                            <p className="text-2xl font-bold text-green-600">Healthy</p>
                          </div>
                          <CheckCircle className="w-8 h-8 text-green-600" />
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">API Status</p>
                            <p className="text-2xl font-bold text-green-600">Online</p>
                          </div>
                          <Activity className="w-8 h-8 text-green-600" />
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">Payment Gateway</p>
                            <p className="text-2xl font-bold text-green-600">Active</p>
                          </div>
                          <CreditCard className="w-8 h-8 text-green-600" />
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* User Activity */}
                  <div>
                    <h4 className="font-semibold mb-4">User Activity Overview</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 border rounded-lg">
                        <p className="text-2xl font-bold">{adminData?.stats.totalUsers || 0}</p>
                        <p className="text-sm text-gray-600">Total Users</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <p className="text-2xl font-bold">{adminData?.stats.activeSubscriptions || 0}</p>
                        <p className="text-sm text-gray-600">Active Subscribers</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <p className="text-2xl font-bold">{formatCurrency(adminData?.stats.totalRevenue || 0)}</p>
                        <p className="text-sm text-gray-600">Total Revenue</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <p className="text-2xl font-bold">{adminData?.stats.recentActivity || 0}</p>
                        <p className="text-sm text-gray-600">Recent Activities</p>
                      </div>
                    </div>
                  </div>

                  {/* System Actions */}
                  <div>
                    <h4 className="font-semibold mb-4">System Administration</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" className="flex flex-col items-center p-6 h-auto">
                            <XCircle className="w-8 h-8 mb-2 text-orange-500" />
                            <span>Reset All Sessions</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Reset All User Sessions</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will log out all users from the system. They will need to log in again.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => {
                              toast({ title: 'Sessions Reset', description: 'All user sessions have been terminated' });
                            }}>
                              Reset Sessions
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>

                      <Button 
                        variant="outline" 
                        className="flex flex-col items-center p-6 h-auto"
                        onClick={() => {
                          queryClient.invalidateQueries();
                          toast({ title: 'System Refreshed', description: 'All data has been reloaded' });
                        }}
                      >
                        <Activity className="w-8 h-8 mb-2 text-blue-500" />
                        <span>Refresh All Data</span>
                      </Button>

                      <Button 
                        variant="outline" 
                        className="flex flex-col items-center p-6 h-auto"
                        onClick={() => {
                          toast({ 
                            title: 'System Backup', 
                            description: 'Backup process initiated successfully' 
                          });
                        }}
                      >
                        <FileText className="w-8 h-8 mb-2 text-green-500" />
                        <span>Create Backup</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Logs Tab */}
          <TabsContent value="logs">
            <Card>
              <CardHeader>
                <CardTitle>System Activity Logs</CardTitle>
              </CardHeader>
              <CardContent>
                {logsLoading ? (
                  <p>Loading logs...</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Timestamp</TableHead>
                        <TableHead>Admin</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Target</TableHead>
                        <TableHead>Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {logs?.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell>{formatDate(log.timestamp)}</TableCell>
                          <TableCell>{log.adminEmail}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{log.action}</Badge>
                          </TableCell>
                          <TableCell>{log.targetType} {log.targetId && `#${log.targetId}`}</TableCell>
                          <TableCell>{log.description}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* User Edit Dialog */}
        {selectedUser && (
          <AlertDialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Edit User: {selectedUser.firstName} {selectedUser.lastName}</AlertDialogTitle>
                <AlertDialogDescription>
                  Update user information and manage their account status.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      value={editingUser.firstName || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, firstName: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      value={editingUser.lastName || ''}
                      onChange={(e) => setEditingUser({ ...editingUser, lastName: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={editingUser.email || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={editingUser.location || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, location: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="farmSize">Farm Size (acres)</Label>
                  <Input
                    id="farmSize"
                    type="number"
                    step="0.1"
                    value={editingUser.farmSize || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, farmSize: e.target.value })}
                  />
                </div>
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => {
                    if (selectedUser) {
                      updateUserMutation.mutate({
                        userId: selectedUser.id,
                        updates: editingUser
                      });
                    }
                  }}
                  disabled={updateUserMutation.isPending}
                >
                  {updateUserMutation.isPending ? 'Updating...' : 'Save Changes'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </div>
  );
}