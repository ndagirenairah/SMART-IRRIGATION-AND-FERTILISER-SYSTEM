import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Sprout, 
  TrendingUp, 
  Store, 
  Heart, 
  Droplets, 
  BarChart3, 
  Smartphone,
  Wifi,
  Users,
  ArrowRight,
  CheckCircle,
  Star
} from "lucide-react";

export default function Welcome() {
  const [hoveredFeature, setHoveredFeature] = useState<string | null>(null);

  const features = [
    {
      id: "agrosoil",
      title: "AgroSoil",
      description: "Smart soil monitoring with 7-in-1 NPK sensors, AI-powered fertilizer recommendations, and automated irrigation management.",
      icon: TrendingUp,
      color: "from-green-600 to-emerald-600",
      bgColor: "bg-green-50 border-green-200",
      highlights: ["Real-time soil monitoring", "AI fertilizer recommendations", "Automated irrigation control", "Multi-field management"]
    },
    {
      id: "agromarket",
      title: "AgroMarket",
      description: "Comprehensive marketplace for buying and selling agricultural produce with real-time pricing in Uganda Shillings.",
      icon: Store,
      color: "from-blue-600 to-indigo-600",
      bgColor: "bg-blue-50 border-blue-200",
      highlights: ["Buy & sell produce", "Real-time market prices", "Location-based deals", "Quality certifications"]
    },
    {
      id: "agroanimal",
      title: "AgroAnimal",
      description: "Advanced livestock management with electronic ear tags, health tracking, and comprehensive animal data management.",
      icon: Heart,
      color: "from-amber-600 to-orange-600",
      bgColor: "bg-amber-50 border-amber-200",
      highlights: ["Electronic ear tags", "Health monitoring", "Vaccination tracking", "Breeding records"]
    }
  ];

  const stats = [
    { value: "10,000+", label: "Active Farmers", icon: Users },
    { value: "50,000+", label: "Monitored Fields", icon: BarChart3 },
    { value: "95%", label: "Yield Improvement", icon: TrendingUp },
    { value: "24/7", label: "Support Available", icon: Smartphone }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-lg border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
                <Sprout className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                AgroSet
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="hover:bg-green-50 hover:border-green-300">
                  Login
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-200">
              <Star className="h-3 w-3 mr-1" />
              Uganda's #1 Smart Agriculture Platform
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                Revolutionize
              </span>
              <br />
              <span className="text-gray-900">Your Farm Management</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Comprehensive 3-in-1 agricultural technology platform designed specifically for Ugandan farmers. 
              Monitor soil conditions, manage livestock, and access the marketplace - all in one powerful solution.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/login">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-lg px-8 py-3">
                Start Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 hover:bg-green-50 hover:border-green-300">
              Watch Demo
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white/60 backdrop-blur-sm rounded-xl p-6 border border-green-100 shadow-sm">
                <div className="flex items-center justify-center mb-3">
                  <div className="p-2 rounded-lg bg-green-100">
                    <stat.icon className="h-6 w-6 text-green-700" />
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete Agricultural Solution
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Three powerful modules working together to transform your farming operations
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Card 
                key={feature.id}
                className={`agro-card transition-all duration-300 cursor-pointer ${
                  hoveredFeature === feature.id ? "shadow-2xl scale-105" : "hover:shadow-xl"
                } ${feature.bgColor}`}
                onMouseEnter={() => setHoveredFeature(feature.id)}
                onMouseLeave={() => setHoveredFeature(null)}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${feature.color} shadow-lg`}>
                      <feature.icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl">{feature.title}</CardTitle>
                      <Badge variant="secondary" className="mt-1">
                        Premium Module
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    {feature.description}
                  </p>
                  
                  <div className="space-y-3">
                    {feature.highlights.map((highlight, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{highlight}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 pt-4 border-t border-gray-200">
                    <Link href="/login">
                      <Button 
                        className={`w-full bg-gradient-to-r ${feature.color} hover:opacity-90 transition-all duration-200`}
                      >
                        Explore {feature.title}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-green-600 to-emerald-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Farm?
          </h2>
          <p className="text-xl text-green-100 mb-8 leading-relaxed">
            Join thousands of Ugandan farmers already using AgroSet to increase yields, 
            reduce costs, and modernize their agricultural operations.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="bg-white text-green-700 hover:bg-gray-50 text-lg px-8 py-3">
                Start Your Free Trial
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg px-8 py-3 border-white text-white hover:bg-white/10"
            >
              Contact Sales
            </Button>
          </div>

          <div className="mt-8 flex items-center justify-center space-x-2 text-green-100">
            <CheckCircle className="h-5 w-5" />
            <span>Free 30-day trial • No credit card required • Cancel anytime</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600">
                  <Sprout className="h-5 w-5 text-white" />
                </div>
                <span className="text-lg font-bold">AgroSet</span>
              </div>
              <p className="text-gray-400 max-w-md">
                Empowering Ugandan farmers with smart technology for sustainable agriculture 
                and improved livelihoods.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/agrosoil" className="hover:text-white">AgroSoil</Link></li>
                <li><Link href="/agromarket" className="hover:text-white">AgroMarket</Link></li>
                <li><Link href="/agroanimal" className="hover:text-white">AgroAnimal</Link></li>
                <li><Link href="/pricing" className="hover:text-white">Pricing</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/documentation" className="hover:text-white">Documentation</Link></li>
                <li><Link href="/training" className="hover:text-white">Training</Link></li>
                <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
                <li><Link href="/help" className="hover:text-white">Help Center</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 AgroSet. All rights reserved. Made for Ugandan farmers.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}