import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  Sprout, 
  GraduationCap, 
  PlayCircle, 
  Clock, 
  Users, 
  Award,
  ArrowLeft,
  CheckCircle,
  BookOpen,
  Video,
  Calendar,
  MapPin,
  Star,
  Download,
  ExternalLink
} from "lucide-react";

export default function Training() {
  const [activeTab, setActiveTab] = useState("courses");

  const courses = [
    {
      title: "AgroSet Fundamentals",
      description: "Complete introduction to smart farming with AgroSet platform",
      duration: "4 hours",
      level: "Beginner",
      modules: 8,
      progress: 0,
      price: "Free",
      instructor: "Dr. Sarah Nakato",
      rating: 4.9,
      students: 1250,
      category: "Foundation"
    },
    {
      title: "Soil Science & Analytics",
      description: "Deep dive into soil monitoring, analysis, and AI recommendations",
      duration: "6 hours",
      level: "Intermediate",
      modules: 12,
      progress: 0,
      price: "UGX 85,000",
      instructor: "Prof. James Okello",
      rating: 4.8,
      students: 890,
      category: "AgroSoil"
    },
    {
      title: "Digital Marketing for Farmers",
      description: "Maximize your sales through AgroMarket and digital channels",
      duration: "3 hours",
      level: "Beginner",
      modules: 6,
      progress: 0,
      price: "UGX 60,000",
      instructor: "Mary Atukunda",
      rating: 4.7,
      students: 720,
      category: "AgroMarket"
    },
    {
      title: "Livestock Management Systems",
      description: "Advanced animal tracking, health monitoring, and breeding records",
      duration: "5 hours",
      level: "Intermediate",
      modules: 10,
      progress: 0,
      price: "UGX 95,000",
      instructor: "Dr. Peter Ssemakula",
      rating: 4.9,
      students: 640,
      category: "AgroAnimal"
    }
  ];

  const workshops = [
    {
      title: "IoT Sensor Installation Workshop",
      date: "July 20, 2025",
      time: "9:00 AM - 4:00 PM",
      location: "Makerere University, Kampala",
      instructor: "Technical Team",
      capacity: 50,
      registered: 38,
      price: "UGX 45,000",
      type: "Hands-on"
    },
    {
      title: "Cooperative Training Program",
      date: "July 25, 2025",
      time: "2:00 PM - 6:00 PM",
      location: "Gulu Agricultural College",
      instructor: "Dr. Sarah Nakato",
      capacity: 100,
      registered: 67,
      price: "Free",
      type: "Group Training"
    },
    {
      title: "Advanced Analytics Masterclass",
      date: "August 2, 2025",
      time: "10:00 AM - 3:00 PM",
      location: "Virtual Session",
      instructor: "Data Science Team",
      capacity: 200,
      registered: 145,
      price: "UGX 75,000",
      type: "Virtual"
    }
  ];

  const certifications = [
    {
      name: "AgroSet Certified User",
      description: "Basic platform proficiency certification",
      requirements: "Complete fundamentals course + exam",
      duration: "2 weeks",
      fee: "UGX 25,000",
      validity: "2 years"
    },
    {
      name: "Smart Farming Specialist",
      description: "Advanced IoT and analytics certification",
      requirements: "Complete 3 specialist courses + project",
      duration: "6 weeks",
      fee: "UGX 150,000",
      validity: "3 years"
    },
    {
      name: "AgroSet Trainer",
      description: "Qualified to train other farmers",
      requirements: "All certifications + teaching module",
      duration: "8 weeks",
      fee: "UGX 200,000",
      validity: "Lifetime"
    }
  ];

  const resources = [
    {
      title: "Best Practices Guide",
      type: "PDF Guide",
      size: "2.4 MB",
      downloads: 3200,
      category: "General"
    },
    {
      title: "Soil Analysis Handbook",
      type: "PDF Guide",
      size: "5.1 MB",
      downloads: 2800,
      category: "AgroSoil"
    },
    {
      title: "Market Price Trends",
      type: "Excel Sheet",
      size: "1.2 MB",
      downloads: 1950,
      category: "AgroMarket"
    },
    {
      title: "Animal Health Calendar",
      type: "PDF Calendar",
      size: "3.8 MB",
      downloads: 1600,
      category: "AgroAnimal"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm border-b border-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/welcome">
              <button className="flex items-center space-x-2 group">
                <ArrowLeft className="h-5 w-5 text-gray-600 group-hover:text-green-700 transition-colors" />
                <div className="flex items-center space-x-2">
                  <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
                    <Sprout className="h-5 w-5 text-white" />
                  </div>
                  <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                    AgroSet
                  </span>
                </div>
              </button>
            </Link>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="hover:bg-green-50 hover:border-green-300">
                  Login
                </Button>
              </Link>
              <Link href="/login">
                <Button className="bg-green-600 hover:bg-green-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 shadow-lg">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
              Training Center
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Master smart farming techniques with our comprehensive training programs designed for Ugandan farmers
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-700">50+</div>
              <div className="text-sm text-gray-600">Training Modules</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-700">5,000+</div>
              <div className="text-sm text-gray-600">Trained Farmers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-700">95%</div>
              <div className="text-sm text-gray-600">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="px-4 sm:px-6 lg:px-8 pb-20">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
            <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto">
              <TabsTrigger value="courses">Courses</TabsTrigger>
              <TabsTrigger value="workshops">Workshops</TabsTrigger>
              <TabsTrigger value="certifications">Certificates</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            {/* Online Courses */}
            <TabsContent value="courses" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Online Courses</h2>
                <p className="text-lg text-gray-600">Learn at your own pace with expert-led courses</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {courses.map((course, index) => (
                  <Card key={index} className="agro-card hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-4">
                        <Badge variant="outline">{course.category}</Badge>
                        <div className="text-right">
                          <div className="font-bold text-green-700">{course.price}</div>
                        </div>
                      </div>
                      <CardTitle className="text-xl mb-2">{course.title}</CardTitle>
                      <p className="text-gray-600 text-sm">{course.description}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{course.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <BookOpen className="h-4 w-4" />
                            <span>{course.modules} modules</span>
                          </div>
                        </div>
                        <Badge variant={course.level === "Beginner" ? "default" : "secondary"}>
                          {course.level}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center space-x-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{course.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="h-4 w-4" />
                            <span>{course.students}</span>
                          </div>
                        </div>
                        <span className="text-gray-600">by {course.instructor}</span>
                      </div>

                      {course.progress > 0 && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{course.progress}%</span>
                          </div>
                          <Progress value={course.progress} className="h-2" />
                        </div>
                      )}

                      <div className="flex space-x-2">
                        <Button 
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          disabled={course.progress > 0}
                        >
                          {course.progress > 0 ? "Continue" : "Enroll Now"}
                        </Button>
                        <Button variant="outline" size="sm">
                          Preview
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Workshops */}
            <TabsContent value="workshops" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Live Workshops</h2>
                <p className="text-lg text-gray-600">Hands-on training sessions across Uganda</p>
              </div>

              <div className="space-y-6">
                {workshops.map((workshop, index) => (
                  <Card key={index} className="agro-card">
                    <CardContent className="p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-3">
                            <Badge className={`${workshop.type === "Virtual" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}`}>
                              {workshop.type}
                            </Badge>
                            <h3 className="text-xl font-semibold text-gray-900">{workshop.title}</h3>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <Calendar className="h-4 w-4" />
                              <span>{workshop.date}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Clock className="h-4 w-4" />
                              <span>{workshop.time}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <MapPin className="h-4 w-4" />
                              <span>{workshop.location}</span>
                            </div>
                          </div>
                          
                          <div className="mt-3 flex items-center justify-between">
                            <span className="text-sm text-gray-600">
                              Instructor: <span className="font-medium">{workshop.instructor}</span>
                            </span>
                            <span className="text-sm text-gray-600">
                              {workshop.registered}/{workshop.capacity} registered
                            </span>
                          </div>
                          
                          <div className="mt-2">
                            <Progress 
                              value={(workshop.registered / workshop.capacity) * 100} 
                              className="h-2" 
                            />
                          </div>
                        </div>
                        
                        <div className="lg:ml-6 text-center lg:text-right">
                          <div className="text-2xl font-bold text-green-700 mb-2">
                            {workshop.price}
                          </div>
                          <Button className="bg-green-600 hover:bg-green-700">
                            Register Now
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Certifications */}
            <TabsContent value="certifications" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Professional Certifications</h2>
                <p className="text-lg text-gray-600">Validate your expertise with industry-recognized certificates</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {certifications.map((cert, index) => (
                  <Card key={index} className="agro-card text-center">
                    <CardHeader>
                      <div className="mx-auto p-4 rounded-full bg-gradient-to-r from-green-600 to-emerald-600 w-20 h-20 flex items-center justify-center mb-4">
                        <Award className="h-10 w-10 text-white" />
                      </div>
                      <CardTitle className="text-xl">{cert.name}</CardTitle>
                      <p className="text-gray-600 text-sm">{cert.description}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Requirements:</span>
                          <span className="text-right">{cert.requirements}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Duration:</span>
                          <span>{cert.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Fee:</span>
                          <span className="font-semibold">{cert.fee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Valid for:</span>
                          <span>{cert.validity}</span>
                        </div>
                      </div>
                      
                      <Button className="w-full bg-green-600 hover:bg-green-700">
                        Start Certification
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Resources */}
            <TabsContent value="resources" className="space-y-6">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Learning Resources</h2>
                <p className="text-lg text-gray-600">Free downloads and reference materials</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {resources.map((resource, index) => (
                  <Card key={index} className="agro-card hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="p-3 rounded-lg bg-blue-100">
                            <Download className="h-6 w-6 text-blue-700" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{resource.title}</h3>
                            <div className="flex items-center space-x-3 text-sm text-gray-600 mt-1">
                              <span>{resource.type}</span>
                              <span>•</span>
                              <span>{resource.size}</span>
                              <span>•</span>
                              <span>{resource.downloads} downloads</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col items-end space-y-2">
                          <Badge variant="outline">{resource.category}</Badge>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}