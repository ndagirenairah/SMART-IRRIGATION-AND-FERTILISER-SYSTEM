import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import AgroSoil from "@/pages/agrosoil";
import AgroMarket from "@/pages/agromarket";
import AgroAnimal from "@/pages/agroanimal";
import Welcome from "@/pages/welcome";
import Login from "@/pages/login";
import Settings from "@/pages/settings";
import Pricing from "@/pages/pricing";
import Subscription from "@/pages/subscription";
import Documentation from "@/pages/documentation";
import Training from "@/pages/training";
import Contact from "@/pages/contact";
import Help from "@/pages/help";
import PaymentSuccess from "@/pages/payment-success";
import NotFound from "@/pages/not-found";
import Admin from "@/pages/admin";

function Router() {
  return (
    <Switch>
      <Route path="/welcome" component={Welcome} />
      <Route path="/login" component={Login} />
      <Route path="/" component={Dashboard} />
      <Route path="/agrosoil" component={AgroSoil} />
      <Route path="/soil" component={AgroSoil} />
      <Route path="/agromarket" component={AgroMarket} />
      <Route path="/market" component={AgroMarket} />
      <Route path="/agroanimal" component={AgroAnimal} />
      <Route path="/animal" component={AgroAnimal} />
      <Route path="/settings" component={Settings} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/subscription" component={Subscription} />
      <Route path="/payment-success" component={PaymentSuccess} />
      <Route path="/documentation" component={Documentation} />
      <Route path="/training" component={Training} />
      <Route path="/contact" component={Contact} />
      <Route path="/help" component={Help} />
      <Route path="/admin-control-panel" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
