import { Loader } from '@googlemaps/js-api-loader';

// Extend window type for Google Maps error handler
declare global {
  interface Window {
    gm_authFailure?: () => void;
  }
}

const GOOGLE_MAPS_API_KEY = 'AIzaSyB-D8j1oPOD8XADPOBVcvpqThMoZulOLaY';

let googleMapsLoader: Loader | null = null;

export const initializeGoogleMaps = () => {
  if (!googleMapsLoader) {
    googleMapsLoader = new Loader({
      apiKey: GOOGLE_MAPS_API_KEY,
      version: 'weekly',
      libraries: ['places', 'geometry'],
    });
  }
  return googleMapsLoader;
};

export const loadGoogleMaps = async (): Promise<typeof google.maps> => {
  try {
    const loader = initializeGoogleMaps();
    
    // Don't override existing gm_authFailure handler
    if (!window.gm_authFailure) {
      window.gm_authFailure = () => {
        throw new Error('Google Maps API authentication failed. Please check your API key or enable the Maps JavaScript API.');
      };
    }
    
    const google = await loader.load();
    return google;
  } catch (error) {
    console.error('Error loading Google Maps:', error);
    // Provide more helpful error messages
    if (error instanceof Error) {
      if (error.message.includes('ApiNotActivatedMapError') || 
          error.message.includes('API key not valid') ||
          error.message.includes('authentication failed') ||
          error.message.includes('InvalidKeyMapError')) {
        throw new Error('Google Maps API is not activated or the API key is invalid. Please enable the Maps JavaScript API in your Google Cloud Console.');
      }
    }
    throw new Error('Google Maps failed to load. The service may be unavailable.');
  }
};

export interface LocationData {
  lat: number;
  lng: number;
  address?: string;
  placeId?: string;
}

export const getCurrentLocation = (): Promise<LocationData> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (error) => {
        reject(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000, // 5 minutes
      }
    );
  });
};

export const geocodeAddress = async (address: string): Promise<LocationData | null> => {
  try {
    const google = await loadGoogleMaps();
    const geocoder = new google.maps.Geocoder();
    
    return new Promise((resolve, reject) => {
      geocoder.geocode({ address }, (results, status) => {
        if (status === 'OK' && results && results[0]) {
          const result = results[0];
          resolve({
            lat: result.geometry.location.lat(),
            lng: result.geometry.location.lng(),
            address: result.formatted_address,
            placeId: result.place_id,
          });
        } else {
          reject(new Error(`Geocoding failed: ${status}`));
        }
      });
    });
  } catch (error) {
    console.error('Error geocoding address:', error);
    return null;
  }
};

export const reverseGeocode = async (lat: number, lng: number): Promise<string | null> => {
  try {
    const google = await loadGoogleMaps();
    const geocoder = new google.maps.Geocoder();
    
    return new Promise((resolve, reject) => {
      geocoder.geocode(
        { location: { lat, lng } },
        (results, status) => {
          if (status === 'OK' && results && results[0]) {
            resolve(results[0].formatted_address);
          } else {
            reject(new Error(`Reverse geocoding failed: ${status}`));
          }
        }
      );
    });
  } catch (error) {
    console.error('Error reverse geocoding:', error);
    return null;
  }
};

export const calculateDistance = (
  point1: LocationData,
  point2: LocationData
): number => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (point2.lat - point1.lat) * (Math.PI / 180);
  const dLng = (point2.lng - point1.lng) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(point1.lat * (Math.PI / 180)) *
      Math.cos(point2.lat * (Math.PI / 180)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in kilometers
};