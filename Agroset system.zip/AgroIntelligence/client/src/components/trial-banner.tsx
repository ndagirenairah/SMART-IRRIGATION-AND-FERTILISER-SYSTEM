import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Crown, AlertTriangle } from "lucide-react";
import { Link } from "wouter";

interface TrialStatus {
  isTrialActive: boolean;
  trialEndDate: string;
  requiresSubscription: boolean;
  hasActiveSubscription: boolean;
  subscriptionType?: string;
  daysRemaining: number;
}

export default function TrialBanner() {
  const [showBanner, setShowBanner] = useState(false);

  const { data: trialStatus, isLoading } = useQuery<TrialStatus>({
    queryKey: ["/api/user/trial-status"],
    refetchInterval: 60000, // Check every minute
  });

  useEffect(() => {
    if (trialStatus && !isLoading) {
      // Show banner if trial is active with less than 7 days remaining, or if subscription is required
      const shouldShow = (trialStatus.isTrialActive && trialStatus.daysRemaining <= 7) || 
                        trialStatus.requiresSubscription || 
                        !trialStatus.hasActiveSubscription;
      setShowBanner(shouldShow);
    }
  }, [trialStatus, isLoading]);

  if (isLoading || !trialStatus || !showBanner) {
    return null;
  }

  // Trial expired, subscription required
  if (!trialStatus.isTrialActive && trialStatus.requiresSubscription && !trialStatus.hasActiveSubscription) {
    return (
      <Card className="bg-red-50 border-red-200 p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <div>
              <h3 className="font-semibold text-red-800">Free Trial Expired</h3>
              <p className="text-sm text-red-600">
                Your trial ended on {new Date(trialStatus.trialEndDate).toLocaleDateString()}. 
                Subscribe to continue using AgroSet.
              </p>
            </div>
          </div>
          <Link href="/subscription">
            <Button className="bg-red-600 hover:bg-red-700 text-white">
              Subscribe Now
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  // Trial active but ending soon
  if (trialStatus.isTrialActive && trialStatus.daysRemaining <= 7) {
    return (
      <Card className="bg-yellow-50 border-yellow-200 p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Clock className="h-6 w-6 text-yellow-600" />
            <div>
              <h3 className="font-semibold text-yellow-800">Free Trial Ending Soon</h3>
              <p className="text-sm text-yellow-600">
                {trialStatus.daysRemaining} days remaining in your free trial. 
                Subscribe to keep your data and continue farming smart.
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="border-yellow-300 text-yellow-700">
              {trialStatus.daysRemaining} days left
            </Badge>
            <Link href="/subscription">
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <Crown className="h-4 w-4 mr-2" />
                Choose Plan
              </Button>
            </Link>
          </div>
        </div>
      </Card>
    );
  }

  // Has active subscription - show success banner occasionally
  if (trialStatus.hasActiveSubscription) {
    return (
      <Card className="bg-green-50 border-green-200 p-3 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Crown className="h-5 w-5 text-green-600" />
            <div>
              <h3 className="font-medium text-green-800">
                {trialStatus.subscriptionType?.toUpperCase()} Plan Active
              </h3>
              <p className="text-xs text-green-600">
                Enjoying full access to all AgroSet features
              </p>
            </div>
          </div>
          <Link href="/subscription">
            <Button variant="outline" size="sm" className="border-green-300 text-green-700 hover:bg-green-100">
              Manage Plan
            </Button>
          </Link>
        </div>
      </Card>
    );
  }

  return null;
}