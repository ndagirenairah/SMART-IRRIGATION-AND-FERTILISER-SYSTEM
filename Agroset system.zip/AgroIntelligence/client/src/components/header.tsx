import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Bell, User, Sprout, Settings, LogOut, Edit, ChevronDown, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import type { User as UserType, Notification } from "@shared/schema";
import NotificationCenter from "@/components/notification-center";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const profileEditSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  fullName: z.string().optional(),
  phone: z.string().optional(),
  location: z.string().optional(),
});

type ProfileEditData = z.infer<typeof profileEditSchema>;

export default function Header() {
  const [location, navigate] = useLocation();
  const [showProfileEdit, setShowProfileEdit] = useState(false);
  const { toast } = useToast();
  
  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/user"],
  });

  const { data: notifications } = useQuery<Notification[]>({
    queryKey: ["/api/notifications", "unread=true"],
  });

  const unreadCount = notifications?.length || 0;

  const form = useForm<ProfileEditData>({
    resolver: zodResolver(profileEditSchema),
    defaultValues: {
      username: user?.username || "",
      email: user?.email || "",
      fullName: "",
      phone: "",
      location: "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileEditData) => {
      return apiRequest("PUT", "/api/user/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      setShowProfileEdit(false);
      form.reset();
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmitProfile = (data: ProfileEditData) => {
    updateProfileMutation.mutate(data);
  };

  const handleLogout = () => {
    // Clear any local storage/session data
    localStorage.removeItem('user');
    sessionStorage.clear();
    
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    
    // Redirect to welcome page
    navigate("/welcome");
  };

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    // Support both long and short route formats
    if (path === "/agrosoil" && (location.startsWith("/soil") || location.startsWith("/agrosoil"))) return true;
    if (path === "/agromarket" && (location.startsWith("/market") || location.startsWith("/agromarket"))) return true;
    if (path === "/agroanimal" && (location.startsWith("/animal") || location.startsWith("/agroanimal"))) return true;
    return false;
  };

  return (
    <header className="bg-white/90 backdrop-blur-md shadow-lg border-b border-green-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center space-x-2 group">
                <div className="p-2 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 group-hover:from-green-700 group-hover:to-emerald-700 transition-all duration-300 shadow-lg">
                  <Sprout className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold bg-gradient-to-r from-green-700 to-emerald-700 bg-clip-text text-transparent">
                  AgroSet
                </span>
              </Link>
            </div>
            <nav className="hidden md:ml-8 md:flex md:space-x-2">
              <Link href="/" className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                isActive("/") 
                  ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 shadow-md" 
                  : "text-gray-600 hover:text-green-700 hover:bg-green-50/80 hover:shadow-sm"
              }`}>
                Dashboard
              </Link>
              <Link href="/agrosoil" className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                isActive("/agrosoil") 
                  ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 shadow-md" 
                  : "text-gray-600 hover:text-green-700 hover:bg-green-50/80 hover:shadow-sm"
              }`}>
                AgroSoil
              </Link>
              <Link href="/agromarket" className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                isActive("/agromarket") 
                  ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 shadow-md" 
                  : "text-gray-600 hover:text-green-700 hover:bg-green-50/80 hover:shadow-sm"
              }`}>
                AgroMarket
              </Link>
              <Link href="/agroanimal" className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                isActive("/agroanimal") 
                  ? "bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 shadow-md" 
                  : "text-gray-600 hover:text-green-700 hover:bg-green-50/80 hover:shadow-sm"
              }`}>
                AgroAnimal
              </Link>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            {/* Notification Center */}
            <NotificationCenter />
            
            {/* Profile Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="flex items-center space-x-3 bg-white/60 backdrop-blur-sm rounded-xl px-3 py-2 border border-green-100 shadow-sm hover:shadow-md transition-all duration-200 hover:bg-white/80"
                >
                  <div className="h-8 w-8 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-md">
                    <span className="text-sm font-bold text-white">
                      {user?.username?.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <span className="text-sm font-medium text-gray-700">
                    {user?.username || "Loading..."}
                  </span>
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-white/95 backdrop-blur-md border-green-100">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.username}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setShowProfileEdit(true)} className="cursor-pointer">
                  <Edit className="mr-2 h-4 w-4" />
                  <span>Edit Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/settings")} className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600 focus:text-red-600">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Profile Edit Dialog */}
      <Dialog open={showProfileEdit} onOpenChange={setShowProfileEdit}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>
              Update your profile information
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitProfile)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Your username" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="your.email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your full name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input placeholder="+256 701 234 567" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="Kampala, Uganda" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowProfileEdit(false)}
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-green-600 hover:bg-green-700"
                  disabled={updateProfileMutation.isPending}
                >
                  <Save className="h-4 w-4 mr-2" />
                  {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </header>
  );
}
