import { Link, useLocation } from "wouter";
import { Home, TrendingUp, Store, Heart } from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    // Support both long and short route formats
    if (path === "/soil" && (location.startsWith("/soil") || location.startsWith("/agrosoil"))) return true;
    if (path === "/market" && (location.startsWith("/market") || location.startsWith("/agromarket"))) return true;
    if (path === "/animal" && (location.startsWith("/animal") || location.startsWith("/agroanimal"))) return true;
    return false;
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around py-2">
        <Link href="/" className={`flex flex-col items-center py-2 px-3 ${
          isActive("/") ? "text-agro-primary" : "text-gray-500"
        }`}>
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Dashboard</span>
        </Link>
        <Link href="/soil" className={`flex flex-col items-center py-2 px-3 ${
          isActive("/soil") ? "text-agro-primary" : "text-gray-500"
        }`}>
          <TrendingUp className="h-5 w-5" />
          <span className="text-xs mt-1">Soil</span>
        </Link>
        <Link href="/market" className={`flex flex-col items-center py-2 px-3 ${
          isActive("/market") ? "text-agro-primary" : "text-gray-500"
        }`}>
          <Store className="h-5 w-5" />
          <span className="text-xs mt-1">Market</span>
        </Link>
        <Link href="/animal" className={`flex flex-col items-center py-2 px-3 ${
          isActive("/animal") ? "text-agro-primary" : "text-gray-500"
        }`}>
          <Heart className="h-5 w-5" />
          <span className="text-xs mt-1">Animals</span>
        </Link>
      </div>
    </nav>
  );
}
