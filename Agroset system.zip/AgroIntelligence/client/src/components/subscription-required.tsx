import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Clock, CheckCircle, ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface SubscriptionRequiredProps {
  title?: string;
  message?: string;
  trialEndDate?: string;
}

export default function SubscriptionRequired({ 
  title = "Subscription Required",
  message = "Your free trial has ended. Subscribe to continue accessing AgroSet features.",
  trialEndDate 
}: SubscriptionRequiredProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-red-200 shadow-lg">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto mb-4 p-4 rounded-full bg-red-100">
            <Clock className="h-12 w-12 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">{title}</CardTitle>
          <p className="text-gray-600 mt-2">{message}</p>
          {trialEndDate && (
            <p className="text-sm text-gray-500 mt-1">
              Trial ended: {new Date(trialEndDate).toLocaleDateString()}
            </p>
          )}
        </CardHeader>
        
        <CardContent>
          {/* Benefits Preview */}
          <div className="mb-8">
            <h3 className="font-semibold text-gray-800 mb-4 text-center">
              Continue enjoying these powerful features:
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm text-green-800">Real-time soil monitoring</span>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm text-green-800">AI-powered recommendations</span>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm text-green-800">Smart irrigation controls</span>
              </div>
              <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm text-green-800">Market price tracking</span>
              </div>
            </div>
          </div>

          {/* Pricing Preview */}
          <div className="bg-gradient-to-r from-green-100 to-emerald-100 rounded-lg p-6 mb-6">
            <div className="text-center">
              <Crown className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-bold text-green-800 text-lg">Premium Plan</h3>
              <p className="text-3xl font-bold text-green-700 my-2">
                UGX 10,000<span className="text-lg font-normal">/month</span>
              </p>
              <p className="text-sm text-green-600">
                Full access to all agricultural tools
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Link href="/subscription">
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white text-lg py-3">
                <Crown className="h-5 w-5 mr-2" />
                Choose Your Plan
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </Link>
            
            <Link href="/welcome">
              <Button variant="outline" className="w-full border-gray-300 text-gray-600 hover:bg-gray-50">
                Back to Welcome
              </Button>
            </Link>
          </div>

          {/* Support Contact */}
          <div className="mt-8 pt-6 border-t text-center text-sm text-gray-500">
            <p>Need help? Contact our support team</p>
            <p className="font-medium text-green-600">support@agroset.com</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}