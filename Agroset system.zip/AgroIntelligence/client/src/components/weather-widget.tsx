import { Sun, CloudRain, Cloud, CloudSnow } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface WeatherData {
  current: {
    temperature: number;
    condition: string;
    humidity: number;
    icon: string;
  };
  forecast: Array<{
    day: string;
    high: number;
    low: number;
    condition: string;
    precipitationChance: number;
    icon: string;
  }>;
}

export default function WeatherWidget() {
  // Mock weather data - in a real app, this would come from a weather API
  const weatherData: WeatherData = {
    current: {
      temperature: 28,
      condition: "Partly Cloudy",
      humidity: 65,
      icon: "partly-cloudy",
    },
    forecast: [
      {
        day: "Today",
        high: 28,
        low: 18,
        condition: "Partly cloudy",
        precipitationChance: 30,
        icon: "partly-cloudy",
      },
      {
        day: "Tomorrow",
        high: 25,
        low: 16,
        condition: "Light rain",
        precipitationChance: 70,
        icon: "rain",
      },
      {
        day: "Friday",
        high: 30,
        low: 20,
        condition: "Sunny",
        precipitationChance: 5,
        icon: "sunny",
      },
      {
        day: "Saturday",
        high: 27,
        low: 19,
        condition: "Cloudy",
        precipitationChance: 20,
        icon: "cloudy",
      },
      {
        day: "Sunday",
        high: 26,
        low: 17,
        condition: "Light rain",
        precipitationChance: 60,
        icon: "rain",
      },
    ],
  };

  const getWeatherIcon = (iconType: string, size: "sm" | "lg" = "sm") => {
    const iconSize = size === "lg" ? "h-8 w-8" : "h-5 w-5";
    
    switch (iconType) {
      case "sunny":
        return <Sun className={`${iconSize} text-yellow-500`} />;
      case "rain":
        return <CloudRain className={`${iconSize} text-blue-600`} />;
      case "cloudy":
        return <Cloud className={`${iconSize} text-gray-500`} />;
      case "partly-cloudy":
        return <Sun className={`${iconSize} text-yellow-500`} />;
      default:
        return <Sun className={`${iconSize} text-yellow-500`} />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Weather & Environment</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Current Weather */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="bg-blue-50 p-4 rounded-xl">
            {getWeatherIcon(weatherData.current.icon, "lg")}
          </div>
          <div>
            <div className="text-2xl font-bold text-gray-900">
              {weatherData.current.temperature}°C
            </div>
            <div className="text-gray-600">{weatherData.current.condition}</div>
            <div className="text-sm text-gray-500">
              Humidity: {weatherData.current.humidity}%
            </div>
          </div>
        </div>

        {/* 5-Day Forecast */}
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">5-Day Forecast</h4>
          {weatherData.forecast.map((day, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {getWeatherIcon(day.icon)}
                <div>
                  <div className="font-medium">{day.day}</div>
                  <div className="text-xs text-gray-500">{day.condition}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium">
                  {day.high}°/{day.low}°
                </div>
                <div className="text-xs text-blue-600">
                  {day.precipitationChance}% rain
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
