import { useEffect, useRef, useState } from 'react';
import { loadGoogleMaps, LocationData } from '@/utils/maps';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Search, Crosshair } from 'lucide-react';

// Extend window type for Google Maps error handler
declare global {
  interface Window {
    gm_authFailure?: () => void;
  }
}

interface MapComponentProps {
  onLocationSelect?: (location: LocationData) => void;
  initialLocation?: LocationData;
  height?: string;
  width?: string;
  showSearchBox?: boolean;
  showCurrentLocationButton?: boolean;
  markers?: LocationData[];
  className?: string;
}

export function MapComponent({
  onLocationSelect,
  initialLocation,
  height = '400px',
  width = '100%',
  showSearchBox = true,
  showCurrentLocationButton = true,
  markers = [],
  className = '',
}: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const [searchValue, setSearchValue] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [manualLat, setManualLat] = useState('');
  const [manualLng, setManualLng] = useState('');

  // Default location - Kampala, Uganda
  const defaultLocation = {
    lat: 0.3476,
    lng: 32.5825,
  };

  useEffect(() => {
    // Set up global error handler for Google Maps API errors
    const originalGoogleMapsCallback = window.gm_authFailure;
    window.gm_authFailure = () => {
      console.error('Google Maps authentication failure detected');
      setError('Google Maps API authentication failed. Please use manual coordinates.');
      setIsLoading(false);
    };

    initializeMap();

    // Cleanup
    return () => {
      if (originalGoogleMapsCallback) {
        window.gm_authFailure = originalGoogleMapsCallback;
      } else {
        delete window.gm_authFailure;
      }
    };
  }, []);

  useEffect(() => {
    if (mapInstanceRef.current && markers.length > 0) {
      addMarkers(markers);
    }
  }, [markers]);

  const initializeMap = async () => {
    try {
      setIsLoading(true);
      setError(null); // Clear any previous errors
      
      const google = await loadGoogleMaps();
      
      if (!mapRef.current) {
        setIsLoading(false);
        return;
      }

      const mapOptions: google.maps.MapOptions = {
        center: initialLocation || defaultLocation,
        zoom: initialLocation ? 15 : 10,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        streetViewControl: false,
        mapTypeControl: true,
        fullscreenControl: true,
        zoomControl: true,
      };

      // Add a timeout to detect API errors
      const errorTimeout = setTimeout(() => {
        // If we're still loading after 3 seconds, there's likely an API issue
        if (isLoading) {
          setError('Google Maps is taking too long to load. Please use manual coordinates.');
          setIsLoading(false);
        }
      }, 3000);

      const map = new google.maps.Map(mapRef.current, mapOptions);
      mapInstanceRef.current = map;

      // Listen for successful map load
      map.addListener('tilesloaded', () => {
        clearTimeout(errorTimeout);
        if (isLoading) {
          setIsLoading(false);
        }
      });

      // Listen for map errors
      map.addListener('idle', () => {
        clearTimeout(errorTimeout);
        if (isLoading) {
          setIsLoading(false);
        }
      });

      // Add click listener
      map.addListener('click', (event: google.maps.MapMouseEvent) => {
        if (event.latLng && onLocationSelect) {
          const location: LocationData = {
            lat: event.latLng.lat(),
            lng: event.latLng.lng(),
          };
          onLocationSelect(location);
          addMarker(location);
        }
      });

      // Add initial marker if location provided
      if (initialLocation) {
        addMarker(initialLocation);
      }

      setIsLoading(false);
    } catch (err) {
      console.error('Error initializing map:', err);
      let errorMessage = 'Google Maps is currently unavailable. Please use manual coordinates.';
      
      if (err instanceof Error) {
        if (err.message.includes('Google Maps API') || 
            err.message.includes('authentication') ||
            err.message.includes('API key')) {
          errorMessage = 'Google Maps API is not properly configured. Please use manual coordinates.';
        }
      }
      
      setError(errorMessage);
      setIsLoading(false);
    }
  };

  const addMarker = (location: LocationData) => {
    if (!mapInstanceRef.current) return;

    new google.maps.Marker({
      position: { lat: location.lat, lng: location.lng },
      map: mapInstanceRef.current,
      title: location.address || 'Selected Location',
    });
  };

  const addMarkers = (locations: LocationData[]) => {
    if (!mapInstanceRef.current) return;

    locations.forEach((location) => {
      addMarker(location);
    });
  };

  const searchLocation = async () => {
    if (!searchValue.trim() || !mapInstanceRef.current) return;

    try {
      const google = await loadGoogleMaps();
      const geocoder = new google.maps.Geocoder();

      geocoder.geocode({ address: searchValue }, (results, status) => {
        if (status === 'OK' && results && results[0]) {
          const location = results[0].geometry.location;
          const locationData: LocationData = {
            lat: location.lat(),
            lng: location.lng(),
            address: results[0].formatted_address,
            placeId: results[0].place_id,
          };

          mapInstanceRef.current?.setCenter(location);
          mapInstanceRef.current?.setZoom(15);
          addMarker(locationData);

          if (onLocationSelect) {
            onLocationSelect(locationData);
          }
        } else {
          setError('Location not found');
        }
      });
    } catch (err) {
      console.error('Error searching location:', err);
      setError('Search failed');
    }
  };

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location: LocationData = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };

        if (mapInstanceRef.current) {
          mapInstanceRef.current.setCenter(location);
          mapInstanceRef.current.setZoom(15);
          addMarker(location);
        }

        if (onLocationSelect) {
          onLocationSelect(location);
        }
      },
      (error) => {
        console.error('Error getting location:', error);
        setError('Unable to get current location');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000,
      }
    );
  };

  const handleManualLocation = () => {
    const lat = parseFloat(manualLat);
    const lng = parseFloat(manualLng);
    
    if (isNaN(lat) || isNaN(lng)) {
      setError('Please enter valid latitude and longitude values');
      return;
    }
    
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      setError('Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180');
      return;
    }
    
    const location: LocationData = {
      lat,
      lng,
      address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`
    };
    
    if (onLocationSelect) {
      onLocationSelect(location);
    }
    
    // Clear the error since we successfully set a location
    setError(null);
    setManualLat('');
    setManualLng('');
  };

  if (error) {
    return (
      <div 
        className={`${className} bg-yellow-50 border border-yellow-200 rounded-lg p-6`}
        style={{ height, width }}
      >
        <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
          <div className="p-3 rounded-full bg-yellow-100">
            <svg className="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <div>
            <h3 className="font-semibold text-gray-800 mb-2">Map Not Available</h3>
            <p className="text-yellow-700 mb-4 text-sm">{error}</p>
          </div>
          
          {/* Manual coordinate input fallback */}
          <div className="w-full max-w-sm space-y-3">
            <div className="text-left">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Manual Location Entry
              </label>
              <div className="flex space-x-2">
                <input
                  type="number"
                  placeholder="Latitude"
                  step="any"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  value={manualLat}
                  onChange={(e) => setManualLat(e.target.value)}
                />
                <input
                  type="number"
                  placeholder="Longitude"
                  step="any"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  value={manualLng}
                  onChange={(e) => setManualLng(e.target.value)}
                />
              </div>
            </div>
            <button
              onClick={handleManualLocation}
              className="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm font-medium"
            >
              Set Location
            </button>
          </div>
          
          <div className="text-xs text-gray-500 mt-2">
            <p>Example coordinates for Uganda:</p>
            <p>Kampala: 0.3476, 32.5825</p>
          </div>
          
          <button 
            onClick={initializeMap}
            className="text-sm text-blue-600 hover:text-blue-800 underline"
          >
            Try loading map again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`} style={{ height, width }}>
      {/* Search Box */}
      {showSearchBox && (
        <div className="absolute top-3 left-3 right-3 z-10 flex gap-2">
          <div className="flex-1 flex">
            <Input
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search for a location..."
              className="rounded-r-none"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  searchLocation();
                }
              }}
            />
            <Button
              onClick={searchLocation}
              className="rounded-l-none px-3"
              variant="outline"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
          {showCurrentLocationButton && (
            <Button
              onClick={getCurrentLocation}
              variant="outline"
              className="px-3"
            >
              <Crosshair className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg z-20">
          <div className="text-center text-gray-600">
            <div className="animate-spin h-8 w-8 border-4 border-green-600 border-t-transparent rounded-full mx-auto mb-2"></div>
            <p>Loading map...</p>
          </div>
        </div>
      )}

      {/* Map Container */}
      <div
        ref={mapRef}
        className="w-full h-full rounded-lg"
        style={{ height, width }}
      />
    </div>
  );
}

interface LocationPickerProps {
  onLocationSelect: (location: LocationData) => void;
  initialLocation?: LocationData;
  placeholder?: string;
  className?: string;
}

export function LocationPicker({
  onLocationSelect,
  initialLocation,
  placeholder = "Select location on map",
  className = "",
}: LocationPickerProps) {
  const [selectedLocation, setSelectedLocation] = useState<LocationData | null>(initialLocation || null);
  const [showMap, setShowMap] = useState(false);
  const [showManualInput, setShowManualInput] = useState(false);
  const [manualLat, setManualLat] = useState('');
  const [manualLng, setManualLng] = useState('');

  const handleLocationSelect = (location: LocationData) => {
    setSelectedLocation(location);
    onLocationSelect(location);
    setShowMap(false);
  };

  const handleManualLocationSubmit = () => {
    const lat = parseFloat(manualLat);
    const lng = parseFloat(manualLng);
    
    if (isNaN(lat) || isNaN(lng)) {
      alert('Please enter valid latitude and longitude values');
      return;
    }
    
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      alert('Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180');
      return;
    }
    
    const location: LocationData = {
      lat,
      lng,
      address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`
    };
    
    setSelectedLocation(location);
    onLocationSelect(location);
    setShowManualInput(false);
    setManualLat('');
    setManualLng('');
  };

  return (
    <div className={className}>
      <Button
        variant="outline"
        onClick={() => setShowMap(true)}
        className="w-full justify-start text-left"
      >
        <MapPin className="h-4 w-4 mr-2" />
        {selectedLocation?.address || placeholder}
      </Button>

      {/* Manual Input Button */}
      <Button
        variant="ghost"
        onClick={() => setShowManualInput(true)}
        className="w-full mt-2 text-sm text-gray-600"
      >
        Or enter coordinates manually
      </Button>

      {/* Map Modal */}
      {showMap && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg max-w-2xl w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Select Location</h3>
              <Button variant="outline" onClick={() => setShowMap(false)}>
                Close
              </Button>
            </div>
            <MapComponent
              onLocationSelect={handleLocationSelect}
              initialLocation={selectedLocation || undefined}
              height="400px"
            />
          </div>
        </div>
      )}

      {/* Manual Input Modal */}
      {showManualInput && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Enter Coordinates</h3>
              <Button variant="outline" onClick={() => setShowManualInput(false)}>
                Close
              </Button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Latitude
                </label>
                <input
                  type="number"
                  placeholder="e.g., 0.3476"
                  step="any"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  value={manualLat}
                  onChange={(e) => setManualLat(e.target.value)}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Longitude
                </label>
                <input
                  type="number"
                  placeholder="e.g., 32.5825"
                  step="any"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  value={manualLng}
                  onChange={(e) => setManualLng(e.target.value)}
                />
              </div>
              
              <div className="text-xs text-gray-500">
                <p>Example coordinates for Uganda:</p>
                <p>Kampala: 0.3476, 32.5825</p>
                <p>Entebbe: 0.0564, 32.4634</p>
              </div>
              
              <div className="flex space-x-2">
                <Button
                  onClick={handleManualLocationSubmit}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  Set Location
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowManualInput(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}