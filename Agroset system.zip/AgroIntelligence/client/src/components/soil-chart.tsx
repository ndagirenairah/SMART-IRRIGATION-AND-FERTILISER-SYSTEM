import { useEffect, useRef } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import type { SoilReading } from "@shared/schema";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface SoilChartProps {
  readings: SoilReading[];
  metric: 'moisture' | 'ph' | 'nitrogen' | 'phosphorus' | 'potassium' | 'temperature';
}

export default function SoilChart({ readings, metric }: SoilChartProps) {
  const chartData = {
    labels: readings.map(reading => 
      new Date(reading.timestamp).toLocaleDateString('en-US', { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      })
    ).reverse(),
    datasets: [
      {
        label: getMetricLabel(metric),
        data: readings.map(reading => parseFloat(reading[metric] as string)).reverse(),
        borderColor: '#059669',
        backgroundColor: 'rgba(5, 150, 105, 0.1)',
        tension: 0.4,
        fill: true,
        pointBackgroundColor: '#059669',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4,
        pointHoverRadius: 6,
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#059669',
        borderWidth: 1,
      }
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: '#6B7280',
          font: {
            size: 12,
          }
        }
      },
      y: {
        beginAtZero: false,
        grid: {
          color: 'rgba(0, 0, 0, 0.1)',
        },
        ticks: {
          color: '#6B7280',
          font: {
            size: 12,
          },
          callback: function(value: any) {
            return value + getMetricUnit(metric);
          }
        }
      }
    },
    interaction: {
      intersect: false,
      mode: 'index' as const,
    },
  };

  return (
    <div className="h-64 w-full">
      <Line data={chartData} options={options} />
    </div>
  );
}

function getMetricLabel(metric: string): string {
  const labels = {
    moisture: 'Soil Moisture',
    ph: 'pH Level',
    nitrogen: 'Nitrogen',
    phosphorus: 'Phosphorus',
    potassium: 'Potassium',
    temperature: 'Temperature',
  };
  return labels[metric as keyof typeof labels] || metric;
}

function getMetricUnit(metric: string): string {
  const units = {
    moisture: '%',
    ph: '',
    nitrogen: '%',
    phosphorus: '%',
    potassium: '%',
    temperature: '°C',
  };
  return units[metric as keyof typeof units] || '';
}
