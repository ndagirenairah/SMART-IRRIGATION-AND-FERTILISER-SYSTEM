import OpenAI from "openai";

// Use environment variable or fallback
const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY || "default_key",
  dangerouslyAllowBrowser: true
});

export async function generateSoilRecommendations(soilData: {
  nitrogen: string;
  phosphorus: string;
  potassium: string;
  calcium: string;
  moisture: string;
  ph: string;
  conductivity: string;
  temperature: string;
}) {
  try {
    const prompt = `As an agricultural expert, analyze this soil data and provide specific recommendations:
    
Soil Data:
- Nitrogen: ${soilData.nitrogen}%
- Phosphorus: ${soilData.phosphorus}%
- Potassium: ${soilData.potassium}%
- Calcium: ${soilData.calcium}%
- Moisture: ${soilData.moisture}%
- pH: ${soilData.ph}
- Conductivity: ${soilData.conductivity} mS/cm
- Temperature: ${soilData.temperature}°C

Please provide a JSON response with recommendations for fertilizer application, irrigation needs, and general soil management. Format:
{
  "fertilizer": "specific fertilizer recommendation with amounts",
  "irrigation": "irrigation timing and amount recommendation", 
  "general": "general soil management advice",
  "priority": "low|medium|high|critical"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating AI recommendations:", error);
    throw new Error("Failed to generate AI recommendations");
  }
}

export async function generateMarketAnalysis(productName: string, location: string) {
  try {
    const prompt = `As a market analysis expert, provide insights for selling ${productName} in ${location}. 

Please provide a JSON response with market analysis including current trends, pricing suggestions, best selling times, and demand forecast. Format:
{
  "currentTrend": "market trend description",
  "suggestedPrice": "price range recommendation",
  "bestSellingTime": "optimal timing for sales",
  "demandForecast": "demand prediction for next 30 days",
  "marketTips": "practical selling tips"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating market analysis:", error);
    throw new Error("Failed to generate market analysis");
  }
}

export async function generateAnimalHealthAdvice(animalData: {
  type: string;
  breed?: string;
  age?: number;
  weight?: string;
  symptoms?: string;
}) {
  try {
    const prompt = `As a veterinary expert, provide health advice for this animal:

Animal Details:
- Type: ${animalData.type}
- Breed: ${animalData.breed || "Unknown"}
- Age: ${animalData.age || "Unknown"} years
- Weight: ${animalData.weight || "Unknown"} kg
- Symptoms/Concerns: ${animalData.symptoms || "General health checkup"}

Please provide a JSON response with health recommendations. Format:
{
  "assessment": "general health assessment",
  "recommendations": "specific care recommendations",
  "vaccinations": "vaccination schedule recommendations",
  "nutrition": "feeding and nutrition advice",
  "warnings": "any warning signs to watch for"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Error generating animal health advice:", error);
    throw new Error("Failed to generate animal health advice");
  }
}
