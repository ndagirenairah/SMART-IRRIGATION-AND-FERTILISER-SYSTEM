import { useEffect } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

// Custom hook to handle trial expiration responses
export function useTrialHandler() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleApiResponse = (response: Response, data: any) => {
    // Check for trial expiration response (402 Payment Required)
    if (response.status === 402 && data.redirectTo === "/subscription") {
      toast({
        title: "Free Trial Expired",
        description: "Your trial has ended. Please subscribe to continue using AgroSet.",
        variant: "destructive",
        duration: 5000,
      });
      
      // Redirect to subscription page
      navigate("/subscription");
      return false;
    }
    
    return true;
  };

  return { handleApiResponse };
}

// Function to wrap API requests with trial checking
export async function apiRequestWithTrialCheck(
  method: string,
  endpoint: string,
  data?: any,
  onTrialExpired?: () => void
) {
  try {
    const response = await fetch(endpoint, {
      method,
      headers: {
        "Content-Type": "application/json",
      },
      body: data ? JSON.stringify(data) : undefined,
    });

    // Check for trial expiration
    if (response.status === 402) {
      const errorData = await response.json();
      if (errorData.redirectTo === "/subscription") {
        if (onTrialExpired) {
          onTrialExpired();
        } else {
          // Default behavior - redirect to subscription
          window.location.href = "/subscription";
        }
        throw new Error("Trial expired");
      }
    }

    return response;
  } catch (error) {
    throw error;
  }
}