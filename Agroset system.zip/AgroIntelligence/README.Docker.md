# AgroSet Docker Deployment Guide

This guide explains how to deploy AgroSet using Docker with an external Neon database.

## Prerequisites

1. **Neon Database**: Create a PostgreSQL database at [console.neon.tech](https://console.neon.tech/)
2. **Server**: Ubuntu/Debian server with Docker and Docker Compose installed
3. **Domain**: Optional domain name pointing to your server

## Configuration Steps

### 1. Get Your Neon Database URL

From your Neon dashboard, copy the connection string that looks like:
```
postgresql://username:password@host.neon.database/dbname?sslmode=require
```

### 2. Configure Environment Variables

Edit `.env.production` with your actual values:

```bash
# REQUIRED: Your Neon Database URL
DATABASE_URL=postgresql://your_neon_user:your_password@your_host.neon.database/your_db?sslmode=require

# REQUIRED: API Keys
OPENAI_API_KEY=sk-your_openai_key
PESAPAL_CONSUMER_KEY=your_pesapal_consumer_key
PESAPAL_CONSUMER_SECRET=your_pesapal_consumer_secret
VITE_GOOGLE_MAPS_API_KEY=your_google_maps_api_key

# Session Security
SESSION_SECRET=your_super_secure_session_secret_here
```

### 3. Deploy

Run the deployment script:
```bash
chmod +x deploy.sh
./deploy.sh
```

## Important Notes

### Database Configuration
- **NO LOCAL POSTGRESQL**: This deployment uses your external Neon database only
- **WebSocket Disabled**: For Docker compatibility, WebSocket connections are disabled in production
- **SSL Required**: Neon requires SSL connections (`?sslmode=require`)

### Common Issues

1. **Connection Refused Error**: Make sure your DATABASE_URL points to Neon, not localhost
   ```
   # Wrong (will fail):
   DATABASE_URL=postgresql://postgres:password@localhost:5432/db
   
   # Correct (will work):
   DATABASE_URL=postgresql://user:pass@host.neon.database/db?sslmode=require
   ```

2. **Migration Errors**: Ensure your Neon database allows connections from your server's IP

3. **WebSocket Errors**: These are normal in Docker - the app falls back to HTTP connections

### Accessing Your Application

- **Main App**: `http://your-server:8080`
- **Admin Panel**: `http://your-server:8080/admin-control-panel`
- **Admin Login**: `atreavez@gmail.com` / `Hargreave@51`

### Monitoring

Check application logs:
```bash
docker-compose logs -f
```

Check container health:
```bash
docker-compose ps
```

## Security Considerations

1. Use strong, unique passwords for all services
2. Configure firewall to only allow necessary ports (80, 443, 8080)
3. Use HTTPS in production (configure reverse proxy with SSL)
4. Regularly update your environment variables
5. Monitor application logs for security issues

## Troubleshooting

### Database Connection Issues
1. Verify your Neon DATABASE_URL is correct
2. Check if your server's IP is whitelisted in Neon
3. Ensure the database exists and is accessible

### Container Issues
```bash
# Rebuild containers
docker-compose down
docker-compose up -d --build

# Check logs for specific container
docker-compose logs agroset-app

# Check database connectivity
docker-compose exec agroset-app node -e "console.log(process.env.DATABASE_URL)"
```

For additional support, check the application logs and Neon database dashboard.