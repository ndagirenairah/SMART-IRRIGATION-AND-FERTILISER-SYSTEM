#!/usr/bin/env node

/**
 * Docker Health Check Script for AgroSet
 * Performs comprehensive health checks for the containerized application
 */

import http from 'http';

const HEALTH_CHECK_TIMEOUT = 5000;
const MAX_RETRIES = 3;

// Health check endpoints to test
const healthChecks = [
  {
    name: 'API Health',
    path: '/api/user',
    expectedStatus: [200, 304]
  },
  {
    name: 'Database Connection',
    path: '/api/dashboard/summary',
    expectedStatus: [200, 304, 500] // 500 is ok if no data, means DB is connected
  }
];

async function performHealthCheck(check) {
  return new Promise((resolve) => {
    const options = {
      hostname: 'localhost',
      port: 6000,
      path: check.path,
      method: 'GET',
      timeout: HEALTH_CHECK_TIMEOUT
    };

    const req = http.request(options, (res) => {
      const isHealthy = check.expectedStatus.includes(res.statusCode);
      resolve({
        name: check.name,
        path: check.path,
        status: res.statusCode,
        healthy: isHealthy
      });
    });

    req.on('error', () => {
      resolve({
        name: check.name,
        path: check.path,
        status: 0,
        healthy: false,
        error: 'Connection failed'
      });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({
        name: check.name,
        path: check.path,
        status: 0,
        healthy: false,
        error: 'Timeout'
      });
    });

    req.end();
  });
}

async function runHealthChecks() {
  console.log('🏥 Running AgroSet health checks...');
  
  const results = await Promise.all(
    healthChecks.map(check => performHealthCheck(check))
  );

  let allHealthy = true;
  
  for (const result of results) {
    const status = result.healthy ? '✅' : '❌';
    console.log(`${status} ${result.name}: ${result.status || result.error}`);
    
    if (!result.healthy) {
      allHealthy = false;
    }
  }

  if (allHealthy) {
    console.log('🎉 All health checks passed!');
    process.exit(0);
  } else {
    console.log('⚠️  Some health checks failed');
    process.exit(1);
  }
}

// Run health checks
runHealthChecks().catch((error) => {
  console.error('❌ Health check failed:', error.message);
  process.exit(1);
});