#!/usr/bin/env node

/**
 * Simple AgroSet Startup Script for Neon Database
 * Skips migrations and starts directly - for testing with Neon
 */

// Force production environment settings for Docker compatibility
process.env.NODE_ENV = 'production';
process.env.DISABLE_WEBSOCKET = 'true';

console.log('🌱 Starting AgroSet with Neon database...');

// Validate DATABASE_URL
if (!process.env.DATABASE_URL) {
  console.error('❌ DATABASE_URL environment variable is required');
  process.exit(1);
}

const dbUrl = process.env.DATABASE_URL;
console.log('Using DATABASE_URL:', dbUrl.replace(/:[^:@]*@/, ':***@'));

// Check if DATABASE_URL is pointing to localhost (wrong configuration)
if (dbUrl.includes('localhost') || dbUrl.includes('127.0.0.1')) {
  console.error('❌ ERROR: DATABASE_URL is pointing to localhost instead of Neon database!');
  process.exit(1);
}

// Set NODE_ENV to production if not set
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'production';
}

console.log('✅ Database URL validated - connecting to Neon');
console.log('🚀 Starting AgroSet server...');

// Start the application directly
try {
  await import('./dist/index.js');
} catch (error) {
  console.error('❌ Failed to start AgroSet:', error.message);
  process.exit(1);
}