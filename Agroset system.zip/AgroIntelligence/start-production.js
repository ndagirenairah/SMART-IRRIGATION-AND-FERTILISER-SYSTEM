#!/usr/bin/env node

/**
 * AgroSet Production Startup Script
 * Handles database migrations and server startup for Docker deployment
 */

import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('🌱 Starting AgroSet in production mode...');

try {
  // Verify DATABASE_URL is set
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is required');
  }
  
  // Wait for database to be ready (especially for internal PostgreSQL)
  console.log('⏳ Waiting for database to be ready...');
  const maxRetries = 30;
  let retries = 0;
  
  while (retries < maxRetries) {
    try {
      console.log(`Attempt ${retries + 1}/${maxRetries} - Testing database connection...`);
      await new Promise(async (resolve, reject) => {
        try {
          const pg = await import('pg');
          const { Client } = pg.default || pg;
          const client = new Client({
            connectionString: process.env.DATABASE_URL
          });
          
          await client.connect();
          console.log('✅ Database connection successful');
          await client.end();
          resolve();
        } catch (err) {
          reject(err);
        }
      });
      break;
    } catch (err) {
      retries++;
      if (retries >= maxRetries) {
        throw new Error(`Database connection failed after ${maxRetries} attempts: ${err.message}`);
      }
      console.log(`Database not ready, waiting 2 seconds... (${err.message})`);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }
  
  // Run database migrations/push before starting the server
  console.log('📊 Running database migrations...');
  console.log('Using DATABASE_URL:', process.env.DATABASE_URL.replace(/:[^:@]*@/, ':***@'));
  
  execSync('node_modules/.bin/drizzle-kit push', { 
    stdio: 'inherit',
    cwd: __dirname,
    env: { ...process.env }
  });
  console.log('✅ Database migrations completed');

  // Start the main application
  console.log('🚀 Starting AgroSet server...');
  await import('./dist/index.js');

} catch (error) {
  console.error('❌ Failed to start AgroSet:', error.message);
  if (error.stack) {
    console.error('Stack trace:', error.stack);
  }
  process.exit(1);
}