-- AgroSet Database Initialization Script
-- This script sets up the initial database configuration

-- Create database if it doesn't exist
-- Note: This is handled by Docker Compose, but included for reference

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE agroset TO agroset;

-- Create extensions if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Set timezone
SET timezone = 'UTC';

-- Initial system settings (will be managed by Drizzle migrations)
-- The application will handle schema creation via Drizzle ORM