#!/bin/bash

# AgroSet Docker Deployment Script
# This script automates the deployment process

set -e

echo "🌱 Starting AgroSet Deployment..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p logs ssl

# Check if .env file exists
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.production .env
    echo "⚠️  Please edit .env file with your actual configuration values before continuing."
    echo "   Required variables: DATABASE_URL, OPENAI_API_KEY, PESAPAL keys, GOOGLE_MAPS_API_KEY"
    read -p "Press Enter after you've configured .env file..."
fi

# Critical check for DATABASE_URL
if [ -z "$DATABASE_URL" ]; then
    echo "❌ ERROR: DATABASE_URL environment variable is not set!"
    echo "   You must set your Neon database URL before deployment."
    echo "   Example: export DATABASE_URL='postgresql://user:pass@host.neon.database/db?sslmode=require'"
    exit 1
fi

# Validate DATABASE_URL format
if [[ "$DATABASE_URL" == *"localhost"* ]] || [[ "$DATABASE_URL" == *"127.0.0.1"* ]]; then
    echo "❌ ERROR: DATABASE_URL is pointing to localhost instead of Neon!"
    echo "   Current: $(echo $DATABASE_URL | sed 's/:.*@/:***@/')"
    echo "   Required: Neon database URL (contains .neon.database or neon.tech)"
    exit 1
fi

echo "✅ DATABASE_URL validation passed: $(echo $DATABASE_URL | sed 's/:.*@/:***@/')"

# Using external Neon database configuration
echo "🔗 Using external Neon database"
COMPOSE_FILE="docker-compose.yml"

# Clean up any orphaned containers
echo "🧹 Cleaning up orphaned containers..."
docker-compose -f $COMPOSE_FILE down --remove-orphans

# Build and start services with Docker
echo "🔨 Building Docker images..."
docker-compose -f $COMPOSE_FILE build --no-cache

if [ $? -ne 0 ]; then
    echo "❌ Docker build failed"
    exit 1
fi

echo "🚀 Starting services with Docker..."
docker-compose -f $COMPOSE_FILE up -d

if [ $? -ne 0 ]; then
    echo "❌ Failed to start Docker services"
    exit 1
fi

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 30

# Check if application is running
echo "🔍 Checking application health..."
RETRIES=0
MAX_RETRIES=10

while [ $RETRIES -lt $MAX_RETRIES ]; do
    if curl -f http://localhost:8080/api/user > /dev/null 2>&1; then
        echo "✅ AgroSet is running successfully in Docker!"
        echo "🌐 Application is available at: http://localhost:8080"
        echo "🔐 Admin panel is available at: http://localhost:8080/admin-control-panel"
        echo "   Admin credentials: atreavez@gmail.com / Hargreave@51"
        break
    else
        RETRIES=$((RETRIES + 1))
        echo "Health check attempt $RETRIES/$MAX_RETRIES failed, waiting 10 seconds..."
        sleep 10
    fi
done

if [ $RETRIES -eq $MAX_RETRIES ]; then
    echo "❌ Application health check failed after $MAX_RETRIES attempts. Checking logs..."
    echo "📋 Container logs:"
    docker-compose -f $COMPOSE_FILE logs --tail=50 agroset-app
    echo ""
    echo "🔍 Container status:"
    docker-compose -f $COMPOSE_FILE ps
    exit 1
fi

# Show running containers
echo "📊 Running containers:"
docker-compose -f $COMPOSE_FILE ps

echo "🎉 Deployment completed!"
echo ""
echo "🌐 Access Points:"
echo "  Application: http://$(hostname -I | awk '{print $1}'):8080"
echo "  Admin Panel: http://$(hostname -I | awk '{print $1}'):8080/admin-control-panel"
echo ""
echo "Useful commands:"
echo "  View logs: docker-compose -f $COMPOSE_FILE logs -f"
echo "  Stop services: docker-compose -f $COMPOSE_FILE down"
echo "  Restart: docker-compose -f $COMPOSE_FILE restart"
echo "  Update: docker-compose -f $COMPOSE_FILE pull && docker-compose -f $COMPOSE_FILE up -d --build"
echo ""
echo "🔗 Database Info:"
echo "  Using external Neon database with WebSocket disabled"
echo "  DATABASE_URL: $(echo $DATABASE_URL | sed 's/:.*@/:***@/')"
echo ""
echo "📊 Container Status:"
docker-compose -f $COMPOSE_FILE ps
echo ""
echo "🔧 Docker Management Commands:"
echo "  View app logs: docker-compose -f $COMPOSE_FILE logs -f agroset-app"
echo "  Stop services: docker-compose -f $COMPOSE_FILE down"
echo "  Restart app: docker-compose -f $COMPOSE_FILE restart agroset-app"
echo "  Rebuild app: docker-compose -f $COMPOSE_FILE build --no-cache agroset-app"
echo "  Run migrations: docker-compose -f $COMPOSE_FILE exec agroset-app npx drizzle-kit push"
echo "  Shell access: docker-compose -f $COMPOSE_FILE exec agroset-app /bin/sh"
echo "  Check status: docker-compose -f $COMPOSE_FILE ps"