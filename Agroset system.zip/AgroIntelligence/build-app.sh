#!/bin/bash

echo "🔨 Building AgroSet Application..."
echo ""

# Set NODE_ENV to production for optimized builds
export NODE_ENV=production

echo "📦 Building frontend with Vite..."
npx vite build

if [ $? -eq 0 ]; then
    echo "✅ Frontend build completed successfully"
else
    echo "❌ Frontend build failed"
    exit 1
fi

echo ""
echo "⚙️  Building backend with esbuild..."
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist

if [ $? -eq 0 ]; then
    echo "✅ Backend build completed successfully"
else
    echo "❌ Backend build failed"
    exit 1
fi

echo ""
echo "📋 Build Summary:"
echo "  Frontend: dist/public/"
echo "  Backend: dist/index.js"
echo ""

# List the built files
echo "📁 Built files:"
ls -la dist/
echo ""
if [ -d "dist/public" ]; then
    echo "📁 Frontend assets:"
    ls -la dist/public/
fi

echo ""
echo "✅ Build completed successfully!"
echo ""
echo "🚀 To start the production server:"
echo "   export DATABASE_URL='your_neon_database_url'"
echo "   NODE_ENV=production PORT=6000 node start-neon.js"