#!/bin/bash

echo "🛑 Stopping AgroSet Application..."

# Kill process using PID file
if [ -f .agroset.pid ]; then
    PID=$(cat .agroset.pid)
    echo "Stopping process (PID: $PID)..."
    kill $PID 2>/dev/null
    sleep 5
    kill -9 $PID 2>/dev/null || true
    rm -f .agroset.pid
    echo "✅ Process stopped successfully"
else
    echo "No PID file found, attempting to kill by process name..."
fi

# Kill any remaining processes
pkill -f 'node start-neon.js' 2>/dev/null && echo "✅ Killed remaining node processes"
lsof -ti:6000 | xargs kill -9 2>/dev/null && echo "✅ Freed port 6000"

echo "🔍 Checking for remaining processes..."
REMAINING=$(ps aux | grep 'start-neon.js' | grep -v grep | wc -l)
if [ $REMAINING -eq 0 ]; then
    echo "✅ All AgroSet processes stopped successfully"
else
    echo "⚠️  Some processes may still be running:"
    ps aux | grep 'start-neon.js' | grep -v grep
fi