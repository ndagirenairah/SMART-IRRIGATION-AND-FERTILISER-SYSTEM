#!/usr/bin/env node

/**
 * Simple AgroSet Production Startup Script
 * Uses HTTP-based health check instead of direct database connection
 */

import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import http from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Force production environment settings
process.env.NODE_ENV = 'production';
process.env.DISABLE_WEBSOCKET = 'true';

console.log('🌱 Starting AgroSet in production mode...');

try {
  // Verify DATABASE_URL is set and validate it's pointing to Neon
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is required');
  }

  const dbUrl = process.env.DATABASE_URL;
  console.log('Using DATABASE_URL:', dbUrl.replace(/:[^:@]*@/, ':***@'));
  
  // Check if DATABASE_URL is pointing to localhost (wrong configuration)
  if (dbUrl.includes('localhost') || dbUrl.includes('127.0.0.1')) {
    console.error('❌ ERROR: DATABASE_URL is pointing to localhost instead of Neon database!');
    console.error('   Current URL:', dbUrl.replace(/:[^:@]*@/, ':***@'));
    console.error('   Expected format: postgresql://user:pass@host.neon.database/db?sslmode=require');
    throw new Error('Invalid DATABASE_URL - must point to external Neon database, not localhost');
  }
  
  // Validate Neon URL format
  if (!dbUrl.includes('.neon.database') && !dbUrl.includes('neon.tech')) {
    console.warn('⚠️  WARNING: DATABASE_URL does not appear to be a Neon database URL');
    console.warn('   Make sure you are using the correct Neon connection string');
  }

  // Using external Neon database - no internal database health checks needed
  console.log('🔗 Using external Neon database')
  
  // Run database migrations
  console.log('📊 Running database migrations...');
  try {
    // First try npx, then try different paths
    try {
      execSync('npx drizzle-kit push', { 
        stdio: 'inherit',
        cwd: __dirname,
        env: { ...process.env }
      });
    } catch (npxError) {
      console.log('npx failed, trying direct path...');
      execSync('./node_modules/.bin/drizzle-kit push', { 
        stdio: 'inherit',
        cwd: __dirname,
        env: { ...process.env }
      });
    }
    console.log('✅ Database migrations completed');
  } catch (error) {
    console.log('⚠️  Migration commands failed, skipping migrations...');
    console.log('Application will start without running migrations.');
    console.log('Note: Database tables may need to be created manually if this is first run');
  }

  // Start the main application
  console.log('🚀 Starting AgroSet server...');
  await import('./dist/index.js');

} catch (error) {
  console.error('❌ Failed to start AgroSet:', error.message);
  if (error.stack) {
    console.error('Stack trace:', error.stack);
  }
  process.exit(1);
}